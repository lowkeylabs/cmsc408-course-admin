"""
Utility files to support build command
"""
import os
import re
import sys
import json
import click
import shutil
import gspread
import inspect
import datetime
import frontmatter
import pandas as pd

#import numpy as np
from loguru import logger
from tabulate import tabulate
from urllib.parse import urljoin
from cnvsapi.config import config
from IPython.display import Markdown, HTML, display
from oauth2client.service_account import ServiceAccountCredentials
from googleapiclient.discovery import build
from cachetools import TTLCache, cached
from gspread.exceptions import WorksheetNotFound


#from google.auth.transport.requests import Request
from google.oauth2.service_account import Credentials

from cnvsapi.utils import as_pretty_json, extract_id, module_prefix_from_id, find_page_in_pages, \
    order_modules_by_week, get_frontpage_title, get_overview_title, get_details_title, find_assignment_in_assignments, \
    get_title, order_weeks_by_week, find_quiz_in_quizzes, find_ag_in_assignment_groups, extract_last_element, \
    clean_page_title

from cnvsapi.utils_frontpage import frontpage_from_block, front_page_html


def get_list_of_local_lecture_files():
    """ retrieves list of local lecture files """
    lecture_files = [filename for filename in os.listdir(".") if os.path.isfile(filename) and re.match(r"lecture-\d\d", filename) and os.path.splitext(filename)[1]==".qmd" ]
    logger.debug( lecture_files )
    return lecture_files

def getClient():
    """ return hardcoded client. Get more crazy if you want. """
    # create credentials object
    credential_file = os.path.join(os.path.expanduser("~"), ".gsecrets", "gsheets-credentials.json")
    if not os.path.isfile( credential_file ):
      logger.warning("Unable to connect to OUTLINE on google sheets.")
      logger.warning(f"Missing GSHEETS credential file: {credential_file}")
      logger.warning(f"You must use the google admin console to create a credential file for this platform/user.")
      sys.exit(1)

    if (0):
        # this isn't used, but is helpful if you want to look inside the json.
        with open(credential_file, 'r') as f:
        # Load the JSON data from the file into a Python object
            data = json.load(f)

        # authorize the client
        try:
            scope = config.config["application"]["google_scope"]
        except Exception as e:
            scope = ['https://spreadsheets.google.com/feeds', 'https://www.googleapis.com/auth/drive']
        creds = ServiceAccountCredentials.from_json_keyfile_name(credential_file, scope)
        client = gspread.authorize(creds)
    else:
        scope = ['https://spreadsheets.google.com/feeds', 'https://www.googleapis.com/auth/drive']
        creds = Credentials.from_service_account_file(credential_file, scopes=scope)
        client = gspread.authorize(creds)

    return client

def reformat_date(date_str):
    """ takes a date string line like "1/9" and returns with leading 0 like "01/09".
    Totally necessary for proper sorting and searching of dates.
    """
    try:
        [mon,day] = date_str.split("/")
    except ValueError:
        return date_str
    return f"{int(mon):02d}/{int(day):02d}"

#import google.auth
#from google.auth.transport.requests import Request
#from google.oauth2.service_account import Credentials
#from googleapiclient.discovery import build

# Function to copy a Google Sheet to a specific folder
def copy_google_sheet(sheet_id, folder_id, confirm=False):
    # Authenticate using the service account credentials
    credential_file = os.path.join(os.path.expanduser("~"), ".gsecrets", "gsheets-credentials.json")
    if not os.path.isfile( credential_file ):
      logger.warning("Missing credential file:",credential_file)
      sys.exit(1)
    
    creds = Credentials.from_service_account_file(credential_file, scopes=['https://www.googleapis.com/auth/drive'])

    # Create the Drive API service
    drive_service = build('drive', 'v3', credentials=creds)

    # Retrieve the metadata of the original Google Sheet
    try:
        sheet_metadata = drive_service.files().get(fileId=sheet_id).execute()
        logger.debug( f"source file: {sheet_metadata["name"]}" )
        logger.trace( sheet_metadata )
    except Exception as e:
        logger.warning( "Can't access --original-id.  Verify that email in .gsecrets can share the file.")
        sys.exit(1)

    # retrive receiving folder info
    try:
        folder_metadata = drive_service.files().get(fileId=folder_id,fields='id, name, mimeType, parents').execute()
        logger.trace( folder_metadata )
    except Exception as e:
        logger.warning( "Can't access --folder-id.  Verify that email in .gsecrets can share the file.")
        sys.exit(1)

    # Create a copy of the Google Sheet
    new_sheet_id = None
    copied_sheet = None
    if confirm:
        copied_sheet = drive_service.files().copy(fileId=sheet_id, body={
            'name': f"Copy of {sheet_metadata['name']}",
            'parents': [folder_id]
            },
            fields='id, name, mimeType, webViewLink, parents, createdTime, modifiedTime, owners, permissions, description, starred, trashed, version'
        ).execute()

        new_sheet_id = copied_sheet['id']

    if (0):
        # Retrieve the owner of the folder
        folder_metadata = drive_service.files().get(fileId=folder_id, fields='owners').execute()
        folder_owner_email = folder_metadata['owners'][0]['emailAddress']

        # Assign the ownership of the copied sheet to the folder owner
        permission = {
            'type': 'user',
            'role': 'owner',
            'emailAddress': folder_owner_email
        }

        drive_service.permissions().create(
            fileId=new_sheet_id,
            body=permission,
            transferOwnership=True,
            fields='id'
        ).execute()

    # Return the ID of the copied Google Sheet
    return copied_sheet

def get_spreadsheet_key():
    return config.outline_gsheet_key

cache = TTLCache( maxsize=100, ttl=60 )

@cached(cache,key=lambda *args, **kwargs: "outline_df")
def load_course_outline_df():
    """ load course outline tab and return a dataframe """
    worksheet_name = "Outline"
    client = getClient()
    spreadsheet_key = get_spreadsheet_key()
    sheet = client.open_by_key(spreadsheet_key).worksheet(worksheet_name)
    outline = sheet.get_all_values()
    logger.trace(f"{outline}")
    outline = outline[3:len(outline)]
    outline_df = pd.DataFrame( outline[1:],columns=outline[0])
    logger.trace(f"outline_df: {outline_df}")
    return outline_df


@cached(cache,key=lambda *args, **kwargs: "summary")
def load_course_summary():
    """Load course summary tab and return a data frame."""
    worksheet_name = "Course Summary"
    spreadsheet_key = get_spreadsheet_key()
    client = getClient()
    sheet = client.open_by_key(spreadsheet_key).worksheet(worksheet_name)
    all_rows = sheet.get_all_values()
    all_rows = all_rows[3:len(all_rows)]
    # now pick just the first 6 columns

    df = pd.DataFrame(all_rows)
    df = df.iloc[:, :6]
    df.columns=["Module","Week","Date","Day","Lectures","Deliverables/Notes"]
    df = df.reset_index(drop=True)
    logger.trace(f"\n{df}")
    return df


@cached(cache,key=lambda *args, **kwargs: "overviews")
def load_course_overviews():
    """Load course overviews tab and return a data frame."""
    worksheet_name = "Overviews"
    spreadsheet_key = get_spreadsheet_key()
    client = getClient()
    sheet = client.open_by_key(spreadsheet_key).worksheet(worksheet_name)
    all_rows = sheet.get_all_values()
    all_rows = all_rows[3:len(all_rows)]
    df = pd.DataFrame(all_rows[1:],columns=all_rows[0])
    #df = df.iloc[:, :3]
    df = df.reset_index(drop=True)
    logger.trace(f"\n{df}")
    return df

@cached(cache,key=lambda *args, **kwargs: "lectures")
def load_lectures_df():
    """Load lectures tab and return a data frame. It might not exist! """
    worksheet_name = "Lectures"
    spreadsheet_key = get_spreadsheet_key()
    client = getClient()
    try:
        sheet = client.open_by_key(spreadsheet_key).worksheet(worksheet_name)
    except WorksheetNotFound:
        logger.debug(f"Worksheet '{worksheet_name}' not found in the spreadsheet.")
        return None  # or return an empty DataFrame: pd.DataFrame()
    all_rows = sheet.get_all_values()
    all_rows = all_rows[3:len(all_rows)]
    df = pd.DataFrame(all_rows[1:],columns=all_rows[0])
#    df = df.iloc[:, :3]
    df = df.reset_index(drop=True)
    logger.trace(f"\n{df}")
    return df

@cached(cache,key=lambda *args, **kwargs: "notes")
def load_course_notes_df():
    """Load notes tab and return a data frame."""
    worksheet_name = "Notes"
    spreadsheet_key = get_spreadsheet_key()
    client = getClient()
    sheet = client.open_by_key(spreadsheet_key).worksheet(worksheet_name)
    all_rows = sheet.get_all_values()
    all_rows = all_rows[3:len(all_rows)]
    df = pd.DataFrame(all_rows[1:],columns=all_rows[0])
#    df = df.iloc[:, :3]
    df = df.reset_index(drop=True)
    logger.trace(f"\n{df}")
    return df


@cached(cache,key=lambda *args, **kwargs: "quizzes")
def load_course_quizzes_df():
    """Load quizzes tab and return a data frame."""
    worksheet_name = "Quizzes"
    spreadsheet_key = get_spreadsheet_key()
    client = getClient()
    sheet = client.open_by_key(spreadsheet_key).worksheet(worksheet_name)
    all_rows = sheet.get_all_values()
    all_rows = all_rows[3:len(all_rows)]
    df = pd.DataFrame(all_rows[1:],columns=all_rows[0])
#    df = df.iloc[:, :3]
    df = df.reset_index(drop=True)
    logger.trace(f"\n{df}")
    return df

@cached(cache,key=lambda *args, **kwargs: "homeworks")
def load_course_homeworks_df():
    """Load homeworks tab and return a data frame."""
    worksheet_name = "Homeworks"
    spreadsheet_key = get_spreadsheet_key()
    client = getClient()
    sheet = client.open_by_key(spreadsheet_key).worksheet(worksheet_name)
    all_rows = sheet.get_all_values()
    all_rows = all_rows[3:len(all_rows)]
    df = pd.DataFrame(all_rows[1:],columns=all_rows[0])
#    df = df.iloc[:, :3]
    df = df.reset_index(drop=True)
    logger.trace(f"\n{df}")
    return df


@cached(cache,key=lambda *args, **kwargs: "projects")
def load_course_projects_df():
    """Load projects tab and return a data frame."""
    worksheet_name = "Projects"
    spreadsheet_key = get_spreadsheet_key()
    client = getClient()
    sheet = client.open_by_key(spreadsheet_key).worksheet(worksheet_name)
    all_rows = sheet.get_all_values()
    all_rows = all_rows[3:len(all_rows)]
    df = pd.DataFrame(all_rows[1:],columns=all_rows[0])
#    df = df.iloc[:, :3]
    df = df.reset_index(drop=True)
    logger.trace(f"\n{df}")
    return df

@cached(cache,key=lambda *args, **kwargs: "surveys")
def load_course_surveys_df():
    """Load projects tab and return a data frame."""
    worksheet_name = "Surveys"
    spreadsheet_key = get_spreadsheet_key()
    client = getClient()
    sheet = client.open_by_key(spreadsheet_key).worksheet(worksheet_name)
    all_rows = sheet.get_all_values()
    all_rows = all_rows[3:len(all_rows)]
    df = pd.DataFrame(all_rows[1:],columns=all_rows[0])
#    df = df.iloc[:, :3]
    df = df.reset_index(drop=True)
    logger.trace(f"\n{df}")
    return df

@cached(cache,key=lambda *args, **kwargs: "discussions")
def load_course_discussions_df():
    """Load discussions tab and return a data frame."""
    worksheet_name = "Discussions"
    spreadsheet_key = get_spreadsheet_key()
    client = getClient()
    sheet = client.open_by_key(spreadsheet_key).worksheet(worksheet_name)
    all_rows = sheet.get_all_values()
    all_rows = all_rows[3:len(all_rows)]
    df = pd.DataFrame(all_rows[1:],columns=all_rows[0])
#    df = df.iloc[:, :3]
    df = df.reset_index(drop=True)
    logger.trace(f"\n{df}")
    return df


@cached(cache,key=lambda *args, **kwargs: "assignment_groups")
def load_assignment_groups_df():
    """Load assignment groups tab and return data frame."""
    worksheet_name = "Assignment Groups"
    spreadsheet_key = get_spreadsheet_key()
    client = getClient()
    sheet = client.open_by_key(spreadsheet_key).worksheet(worksheet_name)
    all_rows = sheet.get_all_values()
    all_rows = all_rows[3:len(all_rows)]
    df = pd.DataFrame(all_rows[1:],columns=all_rows[0])
#    df = df.iloc[:, :3]
    df = df.reset_index(drop=True)
    logger.trace(f"\n{df}")
    return df


@cached(cache,key=lambda *args, **kwargs: "resources")
def load_course_resources():
    """ Load course resources tab and return a data frame. """
    worksheet_name = "Resources"
    spreadsheet_key = get_spreadsheet_key()
    client = getClient()
    df = None
    try:
        sheet = client.open_by_key(spreadsheet_key).worksheet(worksheet_name)
        all_rows = sheet.get_all_values()
        all_rows = all_rows[3:len(all_rows)]
        df = pd.DataFrame(all_rows[1:],columns=all_rows[0])
        df = df.iloc[:, :6]
        df = df.reset_index(drop=True)
        logger.trace(f"\n{df}")
    except Exception as e:
        logger.error( e )
    return df

def retry_loop( max_retries, func ):
    """ Try/catch the load for three times """
    for retry in range(max_retries):
        try:
            result = func()  # Call the provided function
            return result    # Return the result if successful
        except Exception as e:
            logger.debug(f"Attempt {retry + 1} failed: {e}")
    
    logger.error("All attempts failed. Returning None.")
    logger.error("Check permissions verify file shares are still active.  Look in .gsecrets for email to use.")
    sys.exit(1)

def load_calendar( lecture_id, n_rows = 8 ):
    """ load course outline, use this to pull n_rows starting with lecture_id from course summary """

    outline_df = retry_loop( 3, load_course_outline_df)

    logger.debug(f"outline_df: {outline_df}")
    lecture_date = reformat_date( outline_df[outline_df['Lecture ID']==str(lecture_id)]["Date"].to_list()[0] )

    df = retry_loop( 3, load_course_summary )

    cmp = df["Date"].apply(reformat_date)

    df = df[ cmp>=lecture_date ].head( n_rows )
    return df

def extract_outline( week=None ):
    """ load course outline and extract lecture content """
    df = retry_loop(3,load_course_outline_df)
    df = df[df["week_id"].notna() & (df["week_id"] != "") & (df["Module"]!="")]
    if not week==None:
        df = df[ df['week_id']==week ]
    return df

def extract_lectures( week=None ):
    """ load course outline and extract lecture content """
    lecture_df = retry_loop(3,load_lectures_df)
    if not week==None:
        lecture_df = lecture_df[ lecture_df['week_id']==week ]
    return lecture_df

def extract_notes( week=None ):
    """ load course notes  """
    lecture_df = retry_loop(3,load_course_notes_df)
    return lecture_df

def extract_assignment_groups( week=None ):
    """ load assignment groups from outline  """
    df = retry_loop(3,load_assignment_groups_df)
    df = df[(df["id"].notna()) & (df["id"]!="") & (df["name"] != "") & (df["position"]!="")]
    return df

def extract_quizzes( week=None):
    """ load course outline and extract quiz content """
    df = retry_loop(3,load_course_quizzes_df)
    df = df[(df["id"].notna()) & (df["id"]!="") & (df["week_id"] != "") ]
    if not week==None:
        df = df[ df['week_id']==week]
    return df

def extract_homeworks( week=None):
    """ load homework content """
    def to_int( s ):
        return None if s=='' else int(s)
    homework_df = retry_loop(3,load_course_homeworks_df)
    if not week==None:
        homework_df = homework_df[ homework_df['week_id']==week]
    return homework_df

def extract_projects( week=None):
    """ load course projects """
    df = retry_loop(3,load_course_projects_df)
    df = df[(df["id"].notna()) & (df["id"]!="") & (df["week_id"] != "") ]
    if not week==None:
        df = df[ df['week_id']==week]
    return df

def extract_surveys( week=None ):
    """ load course surveys """
    df = retry_loop(3,load_course_surveys_df)
    df = df[(df["id"].notna()) & (df["id"]!="") & (df["week_id"] != "") ]
    if not week==None:
        df = df[ df['week_id']==week]
    return df

def extract_discussions( week=None ):
    """ load course discussions """
    df = retry_loop(3,load_course_discussions_df)
    df = df[df["week_id"].notna() & (df["week_id"] != "")]
    if not week==None:
        df = df[ df['week_id']==week]
    return df

def extract_weeks():
    """ load course outline and extract class meeting content """
    outline_df = retry_loop(3,load_course_outline_df)
    logger.trace(outline_df)
    df = outline_df.groupby('WK').first().reset_index()
    df = df.sort_values(by="WK").reset_index()
    return df

def extract_overviews():
    overviews_df = retry_loop(3,load_course_overviews)
    return overviews_df

def extract_resources():
    df = retry_loop(3,load_course_resources)
    df = df[ (df["week_id"] != "")&(df["type"] != "")&(df["title"] != "")&(df["content"] != "") ]
    return df.copy()

def extract_weekly_resources( week = None ):
    df = retry_loop(3,load_course_resources)
    df_filtered = df[ (df["week_id"] != "")&(df["type"] != "")&(df["title"] != "")&(df["content"] != "") ]
    # filter to specific week
    if not week is None:
        df_filtered = df_filtered[ df_filtered['week_id'] == week]
    return df_filtered


def extract_week_module_items( week = None ):
    items = []
    return_key = None
    if not week is None:
        module_items = config.get_module_items()
        for module_key in module_items.keys():
            if f"Week {week} -" in f"{module_items[module_key]['name']}":
                for item_key in module_items[module_key]['module_items'].keys():
                    item = module_items[module_key]['module_items'][item_key]
                    items.append( item )
    return return_key, items

def find_name_in_module_items( module_items, name ):
    logger.debug(f"searching for '{name}' in module_items")
    if (not module_items is None) and (not name is None):
        logger.debug(f"---> searching for '{name}' in module_items")
        for module_key in module_items.keys():
            for item_key in module_items[module_key]['module_items'].keys():
                item = module_items[module_key]['module_items'][item_key]
                if name.lower() in f"{module_items[module_key]['module_items'][item_key]['title']}".lower():
                    return module_items[module_key]
    return None


def extract_week_resource_items( week = None ):
    """ Extract resources from Canvas modules items list """
    items = []
    return_key = None
    header_pos = -1
    if not week is None:
        module_items = config.get_module_items()
        for module_key in module_items.keys():
            if f"Week {week} -" in f"{module_items[module_key]['name']}":
                resource_flag = False
                for item_key in module_items[module_key]['module_items'].keys():
                    item = module_items[module_key]['module_items'][item_key]
                    resource_flag = resource_flag and not (item['type'] == 'SubHeader')
                    if resource_flag:
                        return_key = module_key
                        items.append( item )
                    if resource_flag or (item['type'] == 'SubHeader') and (f"Week {week} - Resources".lower() == item['title'].lower()):
                        resource_flag = True
                        header_pos = item['position']
                        return_key = module_key
    return return_key, header_pos, items


def add_lecture_file_names( lecture_df ):
    """ Add lecture filename column to data frame"""
    def clean_title( s ):
        s = s.replace(' ', '-')
        s = re.sub(r'[^\w\s-]', '-', s)
        s = re.sub(r'-+', '-', s)
        return s.lower().rstrip("-")
    def newid( s ):
        r = int(s)
        return f"{r:02d}"
    
    old_chained_assignment = pd.options.mode.chained_assignment
#    pd.options.mode.chained_assignment = None
    new_df = lecture_df.copy()
#    try:
    new_df["basename"] = "lecture-" + lecture_df["id"].apply( newid )
#    logger.debug( new_df )
    #    lecture_df["filename"] = lecture_df["basename"] + "-" + lecture_df["Lecture Title / Topics"].apply( clean_title ) + ".qmd"
    new_df["filename"] = new_df["basename"] + ".qmd"
    new_df["html_filename"] = new_df["basename"] + ".html"
 #   finally:
 #       pd.options.mode.chained_assignment = old_chained_assignment
    return new_df

def get_lecture_df():
    """ Filter out lecture rows from"""
    return add_lecture_file_names( extract_lectures())

def create_qmd_file( filename ):
    logger.info(f"Creating file: {filename}")
    try:
        template_qmd_file = config.lecture_slides_template
    except KeyError:
        click.echo(f"Missing [lecture][template_qmd_file]")
        sys.exit()
    except FileNotFoundError:
        click.echo(f"Missing template file: {template_qmd_file}")
        sys.exit()
    except Exception as e:
        click.echo(f"Exception: {e}")
        sys.exit()
    shutil.copy(template_qmd_file, filename)

def rename_qmd_file( oldname, filename ):
    logger.info(f"renaming from {oldname} to {filename}")
    os.rename( oldname, filename )

def sync_yaml_header( filename, row ):
    logger.info(f"syncing yaml header for: {filename}")
    # Load the file with front matter
    with open(filename, "r",encoding='utf-8') as file:
        content = frontmatter.loads(file.read())

    # Update the variables in the YAML header
    content['title'] = row['title']
    content['lecture-id'] = int(row['id'])
    content['date'] = row["calendar_date"]

    logger.debug(f"{content['title']} :: {content['lecture-id']} :: {content['date']}")

    content.content = re.sub(r'lecture_id = \d+',rf"lecture_id = {content['lecture-id']}",content.content)

    # Write the updated content back to the file
    with open(filename, "w", encoding='utf-8') as file:
        file.write(frontmatter.dumps(content))

def sync_canvas( row ):
    """ sync canvas lectures with lecture slides """
    logger.info(f"Syncing file to canvas lecture names. Lecture: {row['Lecture ID']}")
    logger.debug(f"course id: {config.course_id}")
    config.config["course"][str(config.course_id)]["pages_slideframe_root"] = "https://lowkeylabs.github.io/cmsc508-fa2023-admin/"
    pages = config.config["course"][str(config.course_id)]["pages"]
    for page in pages.keys():
        fields = page.lower().split("-")
        if row['Lecture ID']==str(fields[1]) and fields[0]=="lecture" and fields[2]=="slides":
            logger.success(f"{os.path.splitext(row['filename'])[0]} :: {page}")
            pages[page]["slideframe"] = config.config["course"][str(config.course_id)]["pages_slideframe_root"]+os.path.splitext(row['filename'])[0]+".html"
    config.save()
    

def sync_files_and_lectures_and_canvas():
    # load lecture data frame
    logger.info(f"config file: {config.config_file_name}" )
    lecture_df = get_lecture_df()
    # Get a list of all filenames in the directory that match 
    lecture_files = [filename for filename in os.listdir(".") if os.path.isfile(filename) and re.match(r"lect\d\d", filename) and os.path.splitext(filename)[1]==".qmd" ]
    # merge old_lecture_file names into data frame
    lecture_df["oldname"] = None
    for filename in lecture_files:
        base = filename[:6]
        lecture_df.loc[lecture_df["basename"] == base, "oldname"] = filename
    # at this stage, we've got old and new filenames, or missing files. Loop and update
    logger.debug(lecture_df[["filename","oldname"]])
    for index,row in lecture_df.iterrows():
        if row['oldname'] is None:
            create_qmd_file( row['filename'])
        elif row["oldname"]==row["filename"]:
            pass
        else:
            rename_qmd_file(row['oldname'],row['filename'])
        sync_yaml_header( row['filename'],row )
#        sync_canvas( row )
    return 0


def build_lecture_files_from_outline(include_lectures=None,exclude_lectures=None):
    """ Build lecture files from google sheets outline """

    # Verify that all connections in config file are established.
    config.lecture_slides_template
    config.canvas_endpoint
    config.lecture_slides_endpoint
    config.outline_gsheet_key

    lectures_df = get_lecture_df()
    # build list of files to be created.
    for index,row in lectures_df.iterrows():

        lecture_id = int(row["id"])

        add_lecture = True
        if not include_lectures is None:
            add_lecture = lecture_id in include_lectures
        if not exclude_lectures is None:
            add_lecture = not lecture_id in exclude_lectures

        logger.debug(f"Add? {add_lecture} LectureID: {lecture_id} \nInclude: {include_lectures}\nExclude:{exclude_lectures}" )
        if add_lecture:
            logger.debug( row )
            if not os.path.exists( row["filename"]):
                create_qmd_file( row["filename"] )
                sync_yaml_header( row['filename'],row )
                click.echo(f"Added lecture: {row['filename']} - Wk {row["week_id"]} - {row["calendar_date"]} - {row['title']}")
            else:
                click.echo(f"Lecture already exists: {row['filename']} - Wk {row["week_id"]} - {row["calendar_date"]} - {row['title']}")


def build_lecture_headers_from_outline(include_lectures=None,exclude_lectures=None):
    """ Freshen lecture YAML headers from outline """

    # Verify that all connections in config file are established.
    config.lecture_slides_template
    config.canvas_endpoint
    config.lecture_slides_endpoint
    config.outline_gsheet_key

    lectures_df = get_lecture_df()
    # build list of files to be created.
    for index,row in lectures_df.iterrows():

#        lecture_id = index
        lecture_id = int(row["id"])

        add_lecture = True
        if not include_lectures is None:
            add_lecture = lecture_id in include_lectures
        if not exclude_lectures is None:
            add_lecture = not lecture_id in exclude_lectures

        if add_lecture:
            if os.path.exists( row["filename"] ):
                sync_yaml_header( row['filename'],row )
                click.echo(f"Syncing YAML header: {row['filename']} - Wk {row["week_id"]} - {row["calendar_date"]} - {row['title']}")
            else:
                click.echo(f"Missing lecture file: {row['filename']}. Try 'build lecture-files-from-outline' ")

def upcoming_calendar( lecture_id, n_rows=8 ):
    """ return snip from upcoming calendar.
    startWeek - the beginning week,
    nRows the number of rows to select.
    """
   
    # Load calendar from google sheets and select the appropriate rows.
    config.log_level="WARNING"

    table = load_calendar( lecture_id, n_rows )

    table_text = tabulate(
            table, 
            headers=["Module","Week","Date","Day","Lectures","Deliverables/Notes"],
            tablefmt="html",
            showindex=False,
            colalign=('center','center','center','center','left','left')
            )
    table_style = """
    <style></style>
    """
    table_html = f"{table_style}<div class='upcoming-calendar'>{table_text}</div>"
    # Display the styled table
    text = display(HTML(table_html))
    return text

def get_current_week_from_lecture_id( lecture_id ):
    
    table = load_calendar( lecture_id, 1 )

    return table["Week"].to_list()[0]

def create_slide_iframe( lecture_url ):
    return f"""<div class="dp-embed-wrapper">
    <iframe style="width: 900px; height: 500px;" 
    src="{lecture_url}" 
    allowfullscreen="allowfullscreen" allow="geolocation *; microphone *; camera *; midi *; encrypted-media *; autoplay *; clipboard-write *; display-capture *">
    </iframe>
    </div>
    """


def create_gslide_iframe( lecture_url ):
    return f"""<div class="dp-embed-wrapper">
    <iframe style="width: 900px; height: 545px;"
    src="https://docs.google.com/presentation/d/{lecture_url}/preview"
    allowfullscreen="allowfullscreen" allow="geolocation *; microphone *; camera *; midi *; encrypted-media *; autoplay *; clipboard-write *; display-capture *">
    </iframe>
    </div>
    """


def create_kaltura_iframe( kaltura_url ):
    return f"""<div class="dp-embed-wrapper">
    <iframe style="width: 608px; height: 402px;"
    src="{kaltura_url}"
    allowfullscreen="allowfullscreen" allow="geolocation *; microphone *; camera *; midi *; encrypted-media *; autoplay *; clipboard-write *; display-capture *">
    </iframe>
    </div>
    """

def create_gdoc_iframe( sheet_id, title=None, description=None ):
    result = []
    if description:
        result.append( f'<p>{description}</p>' )
    result.append(f"""
    <div class="dp-embed-wrapper">
    <iframe style="width: 900px; height: 750px;" 
    """)
    if title:
        result.append(f'title="{title}"')
    result.append(f"""src="https://docs.google.com/document/d/{sheet_id}/preview" 
    allowfullscreen="allowfullscreen" allow="geolocation *; microphone *; camera *; midi *; 
    encrypted-media *; autoplay *; clipboard-write *; display-capture *"></iframe>
    </div>
    """)
    return "\n".join( result )


def create_url_iframe( url, width=900, height=750 ):
    return f"""<div class="dp-embed-wrapper">
    <iframe style="width: {width}px; height: {height}px;" 
    src="{url}" 
    width={width} height={height}
    allowfullscreen="allowfullscreen" allow="geolocation *; microphone *; camera *; midi *;
    encrypted-media *; autoplay *; clipboard-write *; display-capture *">
    </iframe>
    </div>
    """

def create_url_link( url,title=None,description=None ):
    d = description
    if d:
        d = d.strip()
    s = f"""
    <p>
    <a href="{url}">{d if d else (title if title else url)}</a>
    </p>
    """
    logger.trace( s )
    return s
    

def create_youtube_iframe( youtube_id, title=None, description=None, width=640, height=480 ):
    """ Create youtube frame. Set add_dp_wrapper to False to not add dp-wrapper, for adding later. """
    result = []
    if description:
        result.append( f'<p>{description}</p>')
    result.append(f"""<div class="dp-embed-wrapper">
            <iframe class="lti-embed" style="width: {width}px; height: {height}px;"
    """)
    result.append(f"""
            src="https://www.youtube-nocookie.com/embed/{youtube_id}?feature=oembed&amp;rel=0" 
            width={width} height={height} allowfullscreen="allowfullscreen" webkitallowfullscreen="webkitallowfullscreen" mozallowfullscreen="mozallowfullscreen"
            allow="geolocation *; microphone *; camera *; midi *; encrypted-media *; autoplay *; clipboard-write *; display-capture *"></iframe>
        </div>
    """)
    return "\n".join( result )


def build_canvas_modules_from_outline( include_weeks=None, exclude_weeks=None):
    """ Build canvas modules from course outline
    """
    logger.debug("building canvas modules from outline")

    # Verify that all connections in config file are established.
    config.canvas_endpoint
    lecture_slides_endpoint = config.lecture_slides_endpoint
    config.outline_gsheet_key

    pages = config.get_pages()
    assignments = config.get_assignments()

    def add_module_page( m,title,**kwargs ):
        page = find_page_in_pages( pages, title )
        if page is None:
            logger.success(f"\t{title} (creating page)")
            page = config.create_page(title, **kwargs )
        else:
            logger.success(f"\t{title} (reusing page)")
        return config.create_module_item(m["id"],type="Page",title=page["title"],page_url=page["url"],indent=kwargs.get("indent",0), published=kwargs.get("published",False) )
    
    def add_module_subheader( m, title, **kwargs ):
        logger.success(f"\t{title} (creating subheader)")
        return config.create_module_item(m["id"],type="SubHeader",title=title,indent=0, published=kwargs.get("published",True))
    
    def add_module_slides_page(m,title,row,**kwargs):
        """ Add slides page """
        page = find_page_in_pages( pages, title )
        if page is None:
            logger.success(f"\t{title} (creating slides)")
            page = config.create_page(title,body=create_slide_iframe( os.path.join( lecture_slides_endpoint, row["html_filename"]) ))
        else:
            logger.success(f"\t{title} (reusing slides)")
        return  config.create_module_item(m["id"],type="Page",title=page["title"],page_url=page["url"],indent=kwargs.get("indent",0), published=kwargs.get("published",True))

    def add_module_video_page(m,title,row,**kwargs):
        page = find_page_in_pages( pages, title )
        if page is None:
            logger.success(f"\t{title} (creating video)")
            page = config.create_page(title)
        else:
            logger.success(f"\t{title} (reusing video)")
        return  config.create_module_item(m["id"],type="Page",title=page["title"],page_url=page["url"],indent=kwargs.get("indent",0), published=kwargs.get("published",False))

#due_at=row['DateCanvas'],unlock_at=row['canvas_unlock_at'],lock_at=row['canvas_lock_at']


    def add_homework_page(m,title,row,**kwargs):
        assignment = find_assignment_in_assignments( assignments, title=title )
        if assignment is None:
            logger.success(f"\t{title} (creating assignment)")
            assignment = config.create_assignment(title,due_at=row['DateCanvas'],unlock_at=row['canvas_unlock_at'],lock_at=row['canvas_lock_at'],description=create_gdoc_iframe( row["Homework doc ID"]))
        else:
            logger.success(f"\t{title} (reusing assignment)")
            logger.debug( as_pretty_json(assignment) )
            assignment = config.edit_assignment( assignment["id"],name=row['HW+Title'],due_at=row['DateCanvas'],unlock_at=row['canvas_unlock_at'],lock_at=row['canvas_lock_at'], description=create_gdoc_iframe( row["Homework doc ID"]) )
        return config.create_module_item(m["id"],type="Assignment",title=assignment["name"],content_id=assignment["id"],indent=kwargs.get("indent",0))

    def add_project_page(m,title,row,**kwargs):
        assignment = find_assignment_in_assignments( assignments, title=title )
        if assignment is None:
            logger.success(f"\t{title} (creating project)")
            assignment = config.create_assignment(title,due_at=row['DateCanvas'],unlock_at=row['canvas_unlock_at'],lock_at=row['canvas_lock_at'],description=create_gdoc_iframe( row["Project doc ID"]))
        else:
            logger.success(f"\t{title} (reusing project)")
            logger.debug( as_pretty_json(assignment) )
            assignment = config.edit_assignment( assignment["id"],name=row["Prj+Title"],due_at=row['DateCanvas'],unlock_at=row['canvas_unlock_at'],lock_at=row['canvas_lock_at'], description=create_gdoc_iframe( row["Project doc ID"]) )
        return config.create_module_item(m["id"],type="Assignment",title=assignment["name"],content_id=assignment["id"],indent=kwargs.get("indent",0))


    def add_quiz_page(m,title,row,**kwargs):
        description = f"""
<p>This is a placeholder.  You can edit this quiz directly, or delete it and use another.</p>
<p>Quizzes can be created externally using <em>text2qti</em> and imported through the Settings</p>
        """
        page = find_assignment_in_assignments( assignments, title=title )
        if page is None:
            logger.success(f"\t{title} (creating quiz)")
            page = config.create_quiz(title,due_at=row['DateCanvas'],unlock_at=row['canvas_unlock_at'],lock_at=row['canvas_lock_at'],description=description)
            page["quiz_id"] = page["id"]
            page["name"] = page["title"]
        else:
            logger.success(f"\t{title} (reusing quiz)")
        logger.debug(f"{page}")
        return config.create_module_item(m["id"],type="Quiz",title=page["name"],content_id=page["quiz_id"],indent=kwargs.get("indent",0))
    
    def edit_quiz_page( m, row, **kwargs ):
        logger.success(f"\t{row['Quiz+Title']}")

        quiz = config.edit_quiz( row['Quiz Canvas ID'], due_at=row['DateCanvas'],unlock_at=row['canvas_unlock_at'],lock_at=row['canvas_lock_at'], title=row['Quiz+Title'] )
        logger.debug( quiz )
        return config.create_module_item( m["id"],type="Quiz",title=row['Quiz+Title'],content_id=quiz['id'],indent=kwargs.get("indent",0))
    

    def edit_homework_page( m, row, **kwargs ):
        logger.success(f"\t{row['HW+Title']}")
        if row['Homework doc ID'] != "":
            description = create_gdoc_iframe( row['Homework doc ID'] )
        else:
            description = row['HW+Title']

        try:
            homework = config.edit_assignment( row['Homework Canvas ID'],name=row['HW+Title'],due_at=row['DateCanvas'],unlock_at=row['canvas_unlock_at'],lock_at=row['canvas_lock_at'], description=description )
            return  config.create_module_item(m["id"],type="Assignment",title=row['HW+Title'],content_id=homework["id"],indent=kwargs.get("indent",0))
        except Exception as e:
            logger.warning(f"Invalid Homework Canvas ID in Outline: {row['HW+Title']}. ID is ignored.")
        return None

    def edit_project_page( m, row, **kwargs ):
        logger.success(f"\t{row['Prj+Title']}")
        if row['Project doc ID'] != "":
            description = create_gdoc_iframe( row['Project doc ID'] )
        else:
            description = row['Prj+Title']

        try:
            homework = config.edit_assignment( row['Project Canvas ID'],name=row['Prj+Title'],due_at=row['DateCanvas'],unlock_at=row['canvas_unlock_at'],lock_at=row['canvas_lock_at'], description=description )
            return  config.create_module_item(m["id"],type="Assignment",title=row['Prj+Title'],content_id=homework["id"],indent=kwargs.get("indent",0))
        except Exception as e:
            logger.warning(f"Invalid Project Canvas ID in Outline: {row['Prj+Title']}.  ID is ignored.")
        return None


    def add_external_link( m, title="missing", external_url="None", **kwargs ):
        logger.success(f"\t- {title} (external link)")
        config.create_module_item( m["id"], title=title,type='ExternalUrl',external_url=external_url,new_tab=True,
                                  indent=kwargs.get('indent',1), published=kwargs.get('published',False))
        return


    def add_module_overview_and_resources( wk, week_id, week_name ):
        published = not wk in ['instructor']

        m = config.create_module( week_name, published=published )
        logger.success( f"{week_name} ({wk})" )

        try:
            overview = overview_df.loc[ overview_df['Week'] == f"{wk}", 'Overview']
            overview_body = ""
            for value in overview.values:
                overview_body = overview_body + "<p>" + value + "</p>"
            overview_body = overview_body + "<p>&nbsp</p>"
        except:
            overview_body = f"Overview missing from Overviews tab in Outline ({week_id})"

        # add temporary frontpage.  These should be freshened later
        add_module_page( m, get_frontpage_title( week_id ), indent=0, published=published,
                        body="temp page.  If you see this, try freshening front pages.")
        add_module_page( m,get_overview_title( week_id ), indent=0, published=published, body=overview_body )

        add_module_page( m, get_details_title( week_id ), indent=0, published=published, body="" )

        if wk=="instructor":
            add_module_page( m,"Instructor - Roster by roles", indent=0, published=False, body = "temp page.  If you see this, try freshening roster page." )
            add_module_page( m,"Instructor - Quick links to lecture slides", indent=0, published=False, body="temp page.  If you see this try freshening lecture summary.")

            url = urljoin("https://docs.google.com/spreadsheets/d/", config.outline_gsheet_key )
            add_external_link( m,"Edit: Outline",external_url=url, indent=0)

            url = urljoin("https://docs.google.com/document/d/", config.syllabus_gdoc_key )
            add_external_link( m,"Edit: Syllabus",external_url=url,indent=0)

            url = urljoin("https://drive.google.com/drive/folders/", config.outline_google_folder )
            add_external_link( m,"Open: Course folder",external_url=url,indent=0)

        add_module_subheader( m,f"{week_id.capitalize()} - Resources",published=published )
        add_module_page( m,f"{week_id.capitalize()} - Dummy resource",indent=1, published=published )

        return m
    
    outline_df = retry_loop(3,load_course_outline_df)
    overview_df = retry_loop(3,load_course_overviews)

    logger.debug(f"Including weeks: {include_weeks}")
    logger.debug(f"Excluding weeks: {exclude_weeks}")


    proper_order = order_modules_by_week( outline_df, prefix=['instructor','welcome'],include_weeks=include_weeks, exclude_weeks=exclude_weeks )
    logger.debug( proper_order )

    for wk in proper_order:

        rows = outline_df[ outline_df["WK"] == str(wk) ]
        logger.debug( rows )

        week_id = module_prefix_from_id( wk )
        if wk=="welcome":
            week_name = "Welcome - introduction and references"
        elif wk=='instructor':
            week_name = "Instructor - private resources and links"
        else:
            week_name = f"{week_id} - {rows['Date'].iloc[0]} to {rows["Date"].iloc[-1]} - {rows["Topic"].iloc[0]}"

        if (1):
            m = add_module_overview_and_resources( wk, week_id, week_name )

            # Add pages for weekly lectures (if necessary)

            lectures = add_lecture_file_names( extract_lectures( week=wk ) )
            if len(lectures)>0:
                add_module_subheader(m,f"{week_id} - Lectures")
                for i,lecture in lectures.iterrows():
                    add_module_slides_page( m,f"Lecture {lecture['Lecture ID']} - slides",lecture,indent=1,published=True)
                    add_module_video_page( m,f"Lecture {lecture['Lecture ID']} - video",lecture,indent=1,published=False)

            # Add pages for weekly deliverables (if necessary)

            homeworks = extract_homeworks( week=wk )
            logger.debug( homeworks )
            quizzes = extract_quizzes( week=wk )
            logger.debug( quizzes )
            projects = extract_projects( week=wk )

            if len(homeworks)>0 or len(quizzes)>0 or len(projects)>0:
                add_module_subheader(m,f"{week_id} - Deliverables")

                for i,quiz in quizzes.iterrows():
                    logger.debug( quiz )
                    if quiz['Quiz Canvas ID'] != "":
                        quiz_str = f"{quiz['Quiz+Title']}"
                        try:
                            edit_quiz_page( m, quiz, indent=1)
                        except Exception as e:
                            logger.warning(f"Quiz ID in outline {quiz['Quiz Canvas ID']} doesn't exist.  Remove value from gsheet.")
                    else:
                        quiz_str = f"{quiz['Quiz+Title']}"
                        add_quiz_page( m,quiz_str,quiz,indent=1)

                for i,homework in homeworks.iterrows():
                    logger.debug( homework )
                    if homework['Homework Canvas ID'] != "":
                        logger.debug("Using existing homework")
                        edit_homework_page( m, homework, indent=1)
                    else:
                        logger.debug("Adding new homework")
                        add_homework_page( m,f"{homework['HW+Title']}",homework,indent=1)

                for i,project in projects.iterrows():
                    logger.debug( project )
                    if project['Project Canvas ID'] != "":
                        logger.debug("Using existing project deliverable")
                        edit_project_page( m, project, indent=1)
                    else:
                        logger.debug("Adding new project deliverable")
                        add_project_page( m,f"{project['Prj+Title']}",project, indent=1)

            add_module_page( m,f"{week_id} - Complete!", published=(not wk in ['instructor']))


def build_canvas_events_from_outline( include_weeks=None, exclude_weeks=None ):
    """ Build class meeting events for calendar """

    logger.debug(f"Build canvas events from outline")
    config.canvas_endpoint
    config.outline_gsheet_key

    lectures_df = extract_lectures()
    for i,row in lectures_df.iterrows():
        title = f"{row['meeting_name']}"
        ce = dict(
                context_code="course_"+str(config.course_id),
                title=title,
                description=row['page_message'],
                start_at=row["meeting_start"],
                end_at=row["meeting_end"],
                location_name=row["meeting_location"] 
        )
        page = config.create_event( ce )
        logger.debug(f"{page}")
        logger.success(f"event: {title}")
    return

def build_canvas_frontpages_from_modules( include_weeks=None, exclude_weeks=None, additional_weeks_to_show=None, set_current_week=None ):
    """ build canvas frontpage from module items """

    def use_week_number( week_number ):
        use_week = True
        if not include_weeks is None:
            use_week = False
            use_week = week_number in include_weeks
        if not exclude_weeks is None:
            use_week = not week_number in exclude_weeks
        return use_week

    def key_to_block_id( key ):
        ids = ["activities","deliverables","resources"]
        for id in ids:
            if id in key.lower():
                return id
        return "unclassified"
    
    def find_key_and_page( title ):
        """ return the key and page object given a page title """
        # This routine scans the local pages variable
        logger.debug(f"{title}")
        page = None
        for key, value in pages.items():
            if ('title' in value) and (value['title'].lower() == title.lower()):
                page = value
                break
        if page is None:
            key = None
        return key, page
    
    def get_week_from_outline( outline_df, today=None ):
        """ given a outline dataframe determine the current week of the semester """
        outline_df['DateCanvas'] = pd.to_datetime( outline_df['DateCanvas'] )
        logger.debug(f"outline\n{outline_df}")
        if today:
            today_date = datetime.datetime.date( today )
        else:
            today_date = datetime.datetime.date(datetime.datetime.now())
        today_row = outline_df[outline_df['DateCanvas'].dt.date == today_date]
        logger.debug( today_row.size )
        if today_row.size==0:
            wk = 0
        else:
            wk = int(today_row["WK"].iloc[0])
        if not set_current_week is None:
            wk = int(set_current_week)
        logger.debug(f"Current week: {wk}")
        return wk
    

    def bullets_to_block( week_id, week_name, bullets ):
        """ convert bullet dictionary into frontpage html page """
        logger.debug(f"{week_id} {week_name}")

        # create interim *block* dictionary containing html codes
        block = {}
        for key in bullets.keys():
            logger.debug(key)
            if key.lower() in ["getting started","overview"]:
                block["overview"] = []

                block["overview"].append(f'<h3 style="text-align:center;">Overview</h3>')
                gs_id,gs_page = find_key_and_page(f"{module_prefix_from_id(week_id)} - Getting started")
                if not gs_id:
                    gs_id,gs_page = find_key_and_page( get_overview_title(module_prefix_from_id(week_id)) )
                gs_text = "getting started text"
                logger.debug(f"gs_id: {gs_id}  {gs_page}")
                if gs_id:
                    page = config.get_page( gs_page["page_id"])
                    gs_text = page["body"]
                logger.debug(gs_text)
                block["overview"].append(f"<p>{gs_text}</p>")
#            elif ("activities" in key.lower()) or ("deliverables" in key.lower()) or ("resources" in key.lower()):
            elif "details" in key.lower():
                block["details"] = []
                ## add code to pull details page contents and append it here.
                gs_text = ""
                gs_id,gs_page = find_key_and_page(f"{get_details_title( module_prefix_from_id(week_id))}")
                if gs_id:
                    page = config.get_page( gs_page["page_id"])
                    gs_text = page["body"]
                    # ignore details if it contains nothing, or the dummy string used when page was created
                    if (not gs_text=="") and (not "BLANK:" in gs_text):
                        block["details"].append(f"{gs_text}")
            else:     
                if len(bullets[key]) > 0 :
                    ## block_id = key_to_block_id( key )
                    block_id = key.lower()
                    h2 = key
                    block[block_id] = []

                    logger.debug(f"Adding key {block_id}")
                    block[block_id].append(f'<h3>{h2}</h3>')
                    block[block_id].append("<ul>")
    #                logger.debug(bullets[key])
                    for bullet in bullets[key]:
                        title = bullet["title"]
                        # remove any "respondus" stuff bolted onto end of quiz title
                        if title.startswith( "Quiz" ):
                            chunks = title.split(" - ",3)
                            title = chunks[0] + " - " + chunks[1] + " (respondus)"
                        logger.debug( title )
                        if block_id=="resources":
                            logger.debug( title )
                            try:
                                chunks = title.split("-",1)
                                if "resource" in chunks[0].lower():
                                    title = chunks[1]
                                chunks = title.split("-",1)
                                if "week" in chunks[0].lower():
                                    title = chunks[1]
                                title = title.strip()
                            except:
                                title = bullet["title"]
                        block[block_id].append(f"<li><a href=\"{bullet["html_url"]}\" target=\"_blank\">{title}</a></li>")
                    block[block_id].append("</ul>")
        return block
    

    ## Main function entry point

    # verify canvas endpoint
    config.canvas_endpoint
    outline_df = retry_loop(3,load_course_outline_df)
    current_week = get_week_from_outline( outline_df )

    logger.debug(f"Including weeks: {include_weeks}")
    logger.debug(f"Excluding weeks: {exclude_weeks}")

    if additional_weeks_to_show is None:
        additional_weeks_to_show = config.get_course_attribute( "frontpage_additional_weeks" )
        if additional_weeks_to_show is None:
            additional_weeks_to_show = 99
        

    modules = config.get_module_items()
    pages = config.get_pages()

    # make initial front pages (if they don't already exist), so that the index has something to connect to

    logger.info("Building temporary front pages.")
    for module_id in [ module_id for module_id in modules.keys()]:
        week_number = extract_id( modules[module_id]["name"] )
        s = get_frontpage_title( module_prefix_from_id(week_number) )
        key,page = find_key_and_page( s )
        if page is None:
            logger.debug(f"creating temporary page: {s}")
            if not page:
                page = config.create_page( title=s, body="temp page.  If you see this, try rebuiling front pages", published=True)

    pages = config.get_pages()
#    resources = extract_resources()
#    lectures = extract_lectures()


    # Loop over modules, building front pages.
    # Assumes all front pages already exist so that the footer index can be properly displayed.
    for module_id in [ module_id for module_id in modules.keys()]:

        week_number = extract_id( modules[module_id]["name"] )
        if week_number:
            logger.debug(f"week_number: {week_number} use_week_number: {use_week_number( week_number )}")
            if use_week_number( week_number ):

                if modules[module_id]['published']:
                    logger.success(f"Assembling frontpage for week: {week_number}")
                else:
                    logger.success(f"Assembling frontpage for week: {week_number}. Not used because module not published in Canvas. ")

                logger.debug(f"Using week number: {week_number}, module_id: {module_id}")

                module = modules[module_id]["module_items"]
                logger.trace(module)
                
                # build dictionary with elements representing subheaders
                subheader = "unclassified"
                bullets = {}
                bullets[subheader] = []

                for key in module.keys():
                    item = module[key]
                    logger.debug(f"type: {item["type"]}\ttitle:{item["title"]}\tpublished: {item["published"]}")
                    if (("week" in item["title"].lower()) and (item["title"].lower()).endswith('getting started')) or (item["title"].lower().endswith('overview')):
                        if item["published"]:
                            bullets["overview"] = [ item ]
                    elif "complete!" in item["title"].lower():
                        if item["published"]:
                            bullets["complete"] = [ item ]
                    elif item["title"].lower()==get_frontpage_title( module_prefix_from_id(week_number) ).lower():
                        
                        logger.debug("ignoring {item['title]}")

                    elif "details" in item["title"].lower():
                        if item["published"]:
                            bullets["details"] = [item]

                    elif item["type"]=="SubHeader":
                        try:
                            subheader = item["title"].split('-', 1)[1].strip()
                        except:
                            subheader = "unclassified"
                        if not subheader in bullets.keys():
                            bullets[subheader] = []
                    else:
                        if item["published"]:
                            logger.debug(f"ADDING: {subheader} - {item['type']} - {item['title']}")
                            bullets[subheader].append( item )

                # process bullets into page

                week_name = modules[module_id]["name"]
                title = get_frontpage_title( module_prefix_from_id(week_number) )
                block = bullets_to_block( week_number, week_name, bullets )
                html_page = frontpage_from_block( week_number, week_name, block, current_week, pages, modules, additional_weeks_to_show )


                key, page = find_key_and_page( title )
                if not page:
                    page = config.create_page( title=title, body=html_page, published=True)
                page["body"] = html_page
                page["published"] = True
                try:
                    test = int(week_number)
                except ValueError:
                    test = 0
                logger.debug( module_id )
                page["front_page"] = (current_week == test) and (not module_prefix_from_id(week_number) in ['instructor'])
                if page["front_page"]:
                    logger.trace(page)
                pageobj = config.get_default_course_endpoint().get_page( page['url'] )
#                logger.debug( pageobj )
                page = config.get_python_object( pageobj.edit( wiki_page=page ) )
                


    logger.debug("Setting homepage to wiki")
    config.update_course( default_view="wiki" )

def copy_from_folder(plugin_folder, name, overwrite=False):
    # Construct the full path of the source
    source_path = os.path.join(plugin_folder, name)
    
    # Construct the destination path
    destination_path = os.path.join(os.getcwd(), name)
    
    try:
        if os.path.isdir(source_path):
            # If the source path is a directory
            if os.path.exists(destination_path):
                if overwrite:
                    shutil.rmtree(destination_path)  # Remove the existing directory
                    shutil.copytree(source_path, destination_path)
                    logger.info(f"Directory '{name}' copied successfully from '{plugin_folder}' to current directory.")
                else:
                    logger.error(f"Directory '{name}' already exists in the current directory. Use overwrite=True to replace it.")
            else:
                # Copy the directory
                shutil.copytree(source_path, destination_path)
                logger.info(f"Directory '{name}' copied successfully from '{plugin_folder}' to current directory.")
        elif os.path.isfile(source_path):
            # If the source path is a file
            if os.path.exists(destination_path) and not overwrite:
                logger.error(f"File '{name}' already exists in the current directory. Use overwrite=True to replace it.")
            else:
                # Copy the file
                shutil.copy(source_path, destination_path)
                logger.info(f"File '{name}' copied successfully from '{plugin_folder}' to current directory.")
        else:
            logger.error(f"Error: '{name}' is neither a file nor a directory in the plugin folder '{plugin_folder}'.")
    except FileNotFoundError:
        logger.error(f"Error: '{name}' was not found in the plugin folder '{plugin_folder}'.")
    except Exception as e:
        logger.error(f"An error occurred: {e}")


def copy_lecture_template_files( overwrite=False ):
    default = config.config["lecture"]["default_qmd_template"]
    template = config.config["lecture"][default]
    try:
        folder = config.config["lecture"][default+"_folder"]
    except:
        folder = None
    try:
        extras = config.config["lecture"][default+"_extras"]
    except:
        extras = None
    
    logger.debug(f"default template: {default}")
    logger.debug(f"{template}")
    logger.debug(f"{folder}")
    logger.debug(f"{extras}")
    logger.debug(f"{config.plugin_folder}")

    folder = os.path.join(config.plugin_folder,"templates") if folder is None else folder

    copy_from_folder( folder, template, overwrite )
    for file in extras:
        copy_from_folder( folder, file, overwrite )

def sync_syllabus_to_config( as_front_page=False ):
    syllabus_id = "1nOUlwdnRIXFP55BDyBX8e6ay3Xj9HB0SOLmy5DdSfFc"
    syllabus_id = config.config["course"][str(config.course_id)]["syllabus_gdoc_key"]
    syllabus_course_summary = config.config["course"][str(config.course_id)]["syllabus_course_summary"]
    if syllabus_id is None:
        syllabus_body = f"<p>Update syllabus_gdoc_key in {config.config_file_name} to connect google doc</p>"
    else:
        syllabus_body = f"""
<iframe 
  style="width: 750px; height: 750px;"
  title="CMSC408-FA2024-Syllabus" 
  src="https://docs.google.com/document/d/{syllabus_id}/preview" 
  allowfullscreen="allowfullscreen"
  allow="geolocation *; microphone *; camera *; midi *; encrypted-media *; autoplay *; clipboard-write *; display-capture *">
</iframe>
"""
    config.update_course( syllabus_body=syllabus_body )
    config.update_course_settings( syllabus_course_summary=syllabus_course_summary )
    safp = "syllabus" if as_front_page else "wiki"
    config.update_course( default_view=safp )

def freshen_overview_pages( include_weeks=None, exclude_weeks=None ):
    """ Freshen overview pages """

    logger.debug(f"Freshen overview pages from Overview tab in outline")
    config.canvas_endpoint
    config.outline_gsheet_key

    logger.debug(f"Including weeks: {include_weeks}")
    logger.debug(f"Excluding weeks: {exclude_weeks}")

    outline_df = extract_outline()
    weeks_list = order_weeks_by_week( outline_df, prefix=['instructor','welcome'],include_weeks=include_weeks, exclude_weeks=exclude_weeks )
    
    overview_df = extract_overviews()
    pages = config.get_pages()
    logger.debug(f"{[key for key in pages.keys()]}")

    for i,df in overview_df.iterrows():

        if df['id'].lower() in weeks_list:
            page = create_or_replace_page( pages, get_title( "overview", id=df['id']) )
            title = page['title']
            body = df['overview']
            page_body = config.get_page( page['url'] )['body']
            if not body in page_body:
                logger.debug(f'freshening: {title}')
                page = config.edit_page( page['url'],title = title, body=body, published=True )
            else:
                logger.debug(f'no changes: {title}')


def freshen_canvas_resource_pages( include_weeks=None, exclude_weeks=None ):
    """ Freshen resources pages (docstring) """
    current_function = inspect.currentframe().f_code.co_name
    docstring = globals()[current_function].__doc__
    logger.debug( docstring )

    config.canvas_endpoint
    config.outline_gsheet_key

    pages = config.get_pages()
    resources_df = extract_resources()

    outline_df = extract_outline()
    weeks_list = order_weeks_by_week( outline_df, prefix=['instructor','welcome'],include_weeks=include_weeks, exclude_weeks=exclude_weeks )

    page_bundles = {}

    # Pre-build list of page bundles
    if len(resources_df)>0:
        for i,row in resources_df.iterrows():
            # skip if row id doesn't begin with 'page-'
            page_url = row['week_id'].lower()
            if not page_url.startswith( 'resource' ):
                continue
            logger.debug(f"Found bundle: {page_url}")
            bundle = page_bundles.setdefault( page_url, [] )
            bundle.append( row )

    # Add single resources pages next
    if len(resources_df)>0:

        for i,row in resources_df.iterrows():

            # Skip week if not in list of links to process
            if not (row['week_id'].lower() in weeks_list):
                continue

            # don't create pages for external links
            if row['type'] in ['external-url']:
                continue

            bundle = page_bundles.setdefault( row['title'], [] )
            bundle.append( row )


    # Given the list of page bundles, make'em!
    if page_bundles:
        for page_url,bundle in page_bundles.items():


            logger.debug( page_url )
            logger.debug( bundle[0]['type'])
            logger.debug( len(bundle) )

            size = dict(width=640,height=480)
            if len(bundle)>1:
                size = dict(width=320,height=240)

            if bundle[0]['type']=="page":
                continue

            logger.debug( bundle[0]['title'] )
            page = create_or_replace_page( pages, bundle[0]['title'] )
            if page:

                page_items = []
                page_items.append( f'<div id="dp-wrapper" class="dp-wrapper">') # dp-wrapper

                for i,row in enumerate( bundle ):

                    if i>0:
                        page_items.append("<p>&nbsp;</p>")
                    if len(bundle)>1:
                        s = f"<h2>{extract_last_element(row['displayed'])}</h2>"
                        logger.debug(s)
                        page_items.append(s)


                    logger.debug(f'"{row['type']}" - "{page['title']}" - "{row['displayed']}"')
                    if row['type']=="page-gdoc":
                        page_items.append( create_gdoc_iframe( row['content'] ) )
                    elif row['type']=="page-iframe":
                        page_items.append( create_url_iframe( row['content'] ) )
                    elif row['type']=="page-slides":
                        page_items.append( create_slide_iframe( row['content'] ) )
                    elif row['type']=="page-youtube":
                        page_items.append( create_youtube_iframe( row['content'], **size ))
                    elif row['type']=="external-url":
                        logger.debug( row['type'])
                        page_items.append( create_url_link( row['content'],title=row['displayed'],description=row['description'] ) )
                    else:
                        logger.debug( row )
                        page_items.append( f"{row}" )

                page_items.append("</div>") # dp-wrapper
                page_body = "\n".join( page_items )

                page = config.edit_page( page['url'], body=page_body, published=True )

    else:
        logger.debug('No page bundles found.')

    return

    # Process regular pages



def freshen_resourcesx( include_weeks=None, exclude_weeks=None ):
    """ Freshen resources pages
    This is a little tricky.  Some resources are pages, and others are module_items.
    - Start by updating module items
    - 
    """

    def process_module( module, resources_df, pages ):

        # Gather resource module items for current week

        logger.debug(f"Processing module: {module['name']}")
        logger.trace( module )
        logger.trace( resources_df )
        logger.trace( [pages[key]['url'] for key in pages.keys()] ) 

        deleted_count = 0
        added_count = 0

        module_key = module['id']
        logger.success(f"module: {module['name']}")

        # build list of module_items to delete
        items = []
        for key in module['module_items']:
            items.append( module['module_items'][key] )
        sorted_items = sorted(items, key=lambda x: x["position"])
        
        index_to_remove = next((i for i, item in enumerate(sorted_items) if item["type"] == "SubHeader" and item["title"].endswith("- Resources")), None)
        sorted_items = sorted_items[ index_to_remove+1:]
        index_to_remove = next((i for i, item in enumerate(sorted_items) if item["type"] == "SubHeader"), None)
        sorted_items = sorted_items[ :index_to_remove ]

        # delete module items and attached pages
        for item in sorted_items:
            config.delete_module_item( module_key, item['id'] )
            # do not delete pages
#            if item['type']=="Page":
#                config.delete_page( item['page_url'])
            deleted_count = deleted_count + 1

        pages = config.get_pages()

        # Add new resource items
        for index, row in resources_df.iterrows():

            if row['Type'] in ['page-gdoc','external-url','page-iframe','page-slides','page','page-youtube']:
                pass
            
            if row['Type'] in ["page-gdoc","page-iframe","page-slides","page-youtube"]:
                logger.debug(f"{row['Type']} - {row['Title']}")
                page = find_page_in_pages( pages, row['Title'])
                if page is None:
                    if row['Type']=="page-gdoc":
                        page_body = create_gdoc_iframe( row['Content'], title=row['Title'], description=row['Description'] )
                    elif row['Type']=="page-iframe":
                        page_body = create_url_iframe( row['Content'] )
                    elif row['Type']=="page-slides":
                        page_body = create_slide_iframe( row['Content'] )
                    elif row['Type']=="page-youtube":
                        page_body = create_youtube_iframe( row['Content'], title=row['Title'], description=row['Description'] )
                    else:
                        page_body = f"{row}"
                    page = config.create_page(row['Title'],body=page_body)
                else:
                    logger.warning(f"Duplicate page name: \"{row['Title']}\" in resources.  Using existing url {page['url']}")
                config.create_module_item( module_key,type="Page",title=page["title"],page_url=page["url"],indent=1,published=True )
                added_count = added_count + 1
                logger.success(f"resource:\t{row['Title']}")

            elif row['Type']=="page":
                logger.debug(f"{row['Type']} - {row['Title']}")
                page = config.get_page( row['Content'] )
                if page is None:
                    logger.warning(f"Resource URL not found: {row['Content']} for title: {row['Title']}")
                else:
                    logger.debug( f"{';'.join([ key for key in page.keys()])}" )
                    logger.debug(f"{[ page[key] for key in ['url','title']]}")
                    config.create_module_item( module_key,type="Page",title=row["Title"],page_url=page["url"],indent=1,published=True )
                    added_count = added_count + 1
                    logger.success(f"resource:\t{row['Title']} (url:{page['url']})")

            elif row['Type']=="external-url":
                logger.debug(f"{row['Type']} - {row['Title']}")
                config.create_module_item( module_key,title=row['Title'],type='ExternalUrl',external_url=row['Content'],new_tab=True,indent=1, published=True)
                added_count = added_count + 1

            else:
                pass

            # Now, renumber the positions to get everything arranged properly

        # get newly added module items from Canvas
        module_items = config.get_module_items( for_module_id=module_key )

        # Convert into a list for later use
        mi = []
        for item_key in module_items[module_key]['module_items'].keys():
            item = module_items[module_key]['module_items'][item_key]
            mi.append( item )
        
        # identify blocks of new resources added
        resource_header_pos = 0
        for idx,mod in enumerate( mi ):
            if mod['title'].endswith('- Resources'):
                resource_header_pos = idx
        complete_mi_pos = len(mi) - added_count - 1

        # Move block of new resources to just after header
        first_part = mi[:resource_header_pos+1]
        middle_part = mi[resource_header_pos+1: complete_mi_pos+1]
        last_part = mi[complete_mi_pos+1:]
        logger.debug(f"rhp: {resource_header_pos} cmp: {complete_mi_pos}\n---first\n{as_pretty_json(first_part)}\n---middle\n{as_pretty_json(middle_part)}\n---last\n{as_pretty_json(last_part)}")
        new_order = first_part + last_part + middle_part

        # reassign order
        for idx,mod in enumerate(new_order):
            config.edit_module_item( mod['module_id'],mod['id'], position=idx+1 )

        return added_count,deleted_count

    logger.debug(f"Freshen overview pages from Overview tab in outline")
    logger.debug(f"Including weeks: {include_weeks}")
    logger.debug(f"Excluding weeks: {exclude_weeks}")

    config.canvas_endpoint
    config.outline_gsheet_key

    logger.debug("get extract_weekly_resources")
    resources_df = extract_weekly_resources()
    logger.trace(f"\n{resources_df}")

    logger.debug("get pages")
    pages = config.get_pages()
    logger.trace(f"Pages: {[key for key in pages.keys()]}")

    logger.debug("get extracting weeks from outline")
    weeks = extract_weeks()
    logger.trace(f"Weeks dataframe from Outline\n{weeks}")

    module_items = config.get_module_items()
    module_names = [extract_id(module_items[key]['name']) for key in module_items.keys()]
    logger.debug(f"Module names: {module_names}" )

    deleted_count = 0
    added_count = 0

    for key in module_items.keys():
        
        module_id = extract_id(module_items[key]['name'])

        do_week = True
        if not include_weeks is None:
            do_week = False
            do_week = module_id in include_weeks
        if not exclude_weeks is None:
            do_week = not module_id in exclude_weeks

        if do_week:
            logger.debug(f"processing: {module_id}")

            ac, dc = process_module( module_items[key], resources_df[ resources_df["Week"].str.lower()==module_id ], pages )

            deleted_count += dc
            added_count += ac

    if (added_count + deleted_count > 0) :
        logger.success(f"Items deleted: {deleted_count}\nItems added: {added_count}")
    else:
        logger.success(f"No changes made.")

    return


def freshen_canvas_details_pages( include_weeks=None, exclude_weeks=None ):
    """ Freshen details pages """

    logger.debug(f"Freshen details from Overview tab in outline")
    config.canvas_endpoint
    config.outline_gsheet_key

    logger.debug(f"Including weeks: {include_weeks}")
    logger.debug(f"Excluding weeks: {exclude_weeks}")

    outline_df = extract_outline()
    weeks_list = order_weeks_by_week( outline_df, prefix=['instructor','welcome'],include_weeks=include_weeks, exclude_weeks=exclude_weeks )
    
    pages = config.get_pages()
    logger.debug(f"{[key for key in pages.keys()]}")

    for id in weeks_list:

        logger.debug( id )
        page = create_or_replace_page( pages, get_title( "details", id=id) )
        title = page['title']
        body = f"details page for {title}"
        page_body = config.get_page( page['url'] )['body']
        if not body in page_body:
            logger.debug(f'freshening: {title}')
            page = config.edit_page( page['url'],title = title, body=body, published=True )
        else:
            logger.debug(f'no changes: {title}')


def freshen_details_pagesx( include_weeks=None, exclude_weeks=None ):
    """ Freshen details pages """

    logger.debug(f"Freshen details pages")
    config.canvas_endpoint
    config.outline_gsheet_key

    outline_df = retry_loop(3,load_course_outline_df)
    overview_df = retry_loop(3,load_course_overviews)

    logger.debug(f"Including weeks: {include_weeks}")
    logger.debug(f"Excluding weeks: {exclude_weeks}")

    pages = config.get_pages()
    logger.debug(f"{[key for key in pages.keys()]}")

    weeks = extract_weeks()
    logger.debug(f"\n{weeks}")

    module_items = config.get_module_items()
    module_names = [extract_id(module_items[key]['name']) for key in module_items.keys()]
    logger.debug( module_names )


    # make initial details pages if they don't already exist

    logger.info("Building details pages.")
    for module_id in [ module_id for module_id in module_items.keys()]:
        week_number = extract_id( module_items[module_id]["name"] )
        s = get_details_title( module_prefix_from_id(week_number) )
        page = find_page_in_pages( pages, s )
        if page is None:
            logger.debug(f"creating details page: {s}")
            if not page:
                page = config.create_page( title=s, body=f"BLANK: {s}", published=True)
        # verify page is in module items
        module_item = find_name_in_module_items( module_items, s )
        logger.debug( module_item )
        if module_item is None:
            logger.info(f"Adding details to week {week_number}/{module_id}: {s}")
#            gradescope_page = update_gradescope_page( module_item, gradescope_title, row, owner_url )
#            mi = config.create_module_item(module_item["id"],type="Page",title=gradescope_page["name"],content_id=gradescope_page["id"],indent=1)
            mi = config.create_module_item(module_id,type="Page",title=page["title"],page_url=page["url"],indent=0, published=True )
            pass
        else:
#            gradescope_page = update_gradescope_page( module_item, gradescope_title, row, owner_url )
            logger.info(f"Found details in week {week_number}: {s}")
            pass

    return
    pages = config.get_pages()

    for key in module_items.keys():
        
        module_id = extract_id(module_items[key]['name'])
        week_id = module_prefix_from_id( module_id )

        do_week = True
        if not include_weeks is None:
            do_week = False
            do_week = module_id in include_weeks
        if not exclude_weeks is None:
            do_week = not module_id in exclude_weeks

        if do_week:

            logger.debug(f"{module_id}")

            details_body = ""
            if (0):
                try:
                    overview = overview_df.loc[ overview_df['Week'].str.lower()==module_id , 'Overview']
                    overview_body = ""
                    for value in overview.values:
                        overview_body = overview_body + "<p>" + value + "</p>"
                    overview_body = overview_body + "<p>&nbsp</p>"
                except:
                    overview_body = f"Missing details tab in outline ({module_id})"

            gs_page = find_page_in_pages( pages, get_details_title( week_id ) )
            if gs_id:
                url = gs_page["url"]
                page={}
#                page["body"] = details_body
                page["published"] = True

                pageobj = config.get_default_course_endpoint().get_page( url )
                logger.debug( pageobj )
                page = config.get_python_object( pageobj.edit( wiki_page=page ) )
                found = True
            if not found:
                logger.success(f"Details page in canvas not found for {week_id}.  Try using create-modules-from-outline.")
            else:
                logger.success(f"overview: {gs_page['title']}")


def sync_canvas_roster_from_source():
    """ sync a canvas page named roster-by-role """
    def assign_pronouns( user ):
        pronouns = "none"
        if 'pronouns' in user.keys():
            pronouns = user['pronouns']
        return pronouns
    
    def get_body_from_roster( roster ):
        body = []
        no_access_flag = False
        for role in roster:
            body.append(f"<h2>{role['name']}</h2>")
            body.append("<div style='display:flex;flex-wrap:wrap'>")
            for sort_name in role['users'].keys():
                user = role['users'][sort_name]
                if not "@vcu.edu" in user["email"].lower():
                    no_access_flag = True
                logger.debug(f"{as_pretty_json(user)}")
                body.append("<div style='text-align:center; width:120px; font-size:10pt'>")
                body.append(f"<img src='{user['image_url']}'><br/><a href='mailto:{user['email']}'><b>{sort_name}</b></a><br/>{user['enrollment_state']}<br/>{user.get('pronouns','')}")
                body.append("</div>")
            body.append("</div>")
        body = "\n".join( body )
        if no_access_flag:
            body = "<p><b>The user creating this page doesn't have access to SIS variables. Consider elevation to Teacher role.</b></p><p>This page is missing headshots and email addresses.</p>" + body
        return body
    
    roster = config.get_roster_by_roles()
#    logger.debug( f"{as_pretty_json(roster)}" )
    page_name = "Instructor - Roster by roles"
    root_url = 'instructor-roster-by-roles'
    pages = config.get_pages()
    logger.debug( f"{[pages[key]['url'] for key in pages.keys()]}" )

    roster_body = get_body_from_roster( roster )

    page_url = None
    for key in pages.keys():
        if root_url in pages[key]['url']:
            page_url = pages[key]['url']
    if page_url is None:
        page = config.create_page(page_name,body=roster_body)
    else:
        logger.debug(f"{page_url}")
        page = config.edit_page( page_url, title=page_name, body=roster_body )
    return page

def find_quiz_in_modules( module_items, quiz_id ):
    """ Search for quiz_id in module items """
    for module_key in module_items.keys():
        for item_key in module_items[module_key]['module_items'].keys():
            item = module_items[module_key]['module_items'][item_key]
            if item["type"]=="Quiz":
                if str(quiz_id)==str(item["content_id"]):
                    return True
    return False

def find_module_for_week( module_items, week_id ):
    """ Search for quiz_id in module items """
    for module_key in module_items.keys():
        if f"Week {week_id} - ".lower() in module_items[module_key]["name"].lower():
            return module_items[module_key]["id"]
    return None

def freshen_quizzes_from_outline( include_weeks=None, exclude_weeks=None ):
    """ Freshen quizzes
    """

    config.canvas_endpoint
    config.outline_gsheet_key

    quizzes = extract_quizzes( )
    logger.debug( f"\n{ quizzes[['WK','Quiz ID','Quiz description','Quiz Canvas ID']]}" )

    logger.info("Loading modules and items from Canvas.")
    modules = config.get_module_items()
    canvas_quizzes = config.get_quizzes()

    for key in canvas_quizzes.keys():
#        logger.debug(f"{key} - {canvas_quizzes[key]['title']}")
        pass

    for idx, row in quizzes.iterrows():
        msg = f"{row['Quiz+Title']}  due at:{row['DateCanvas']}"
        logger.debug( msg )
        logger.trace( row )
        if row['Quiz Canvas ID']!="":
            quiz = config.edit_quiz( row['Quiz Canvas ID'], due_at=row['DateCanvas'],unlock_at=row['canvas_unlock_at'],lock_at=row['canvas_lock_at'], title=row['Quiz+Title'] )
            ##
            ## check to see if this module is associated with an module-item.  If not, add a module item to appropriate week.
            if not find_quiz_in_modules( modules, row['Quiz Canvas ID'] ):
                logger.info(f"Not found in module list: {row['Quiz+Title']}")
                # decide which week to stick it in and create new module item
                module_id = find_module_for_week( modules, row["WK"] )
                if not module_id is None:
                    logger.info(f"Creating module item in week {row["WK"]} for {row['Quiz+Title']}")
                    config.create_module_item( module_id,type="Quiz",title=row['Quiz+Title'],content_id=quiz['id'],indent=1)

            logger.success(msg)
        else:
            logger.warning(f"Missing quiz ID: {row['Quiz+Title']}.  Update outline.")


def freshen_homeworks_from_outline( include_weeks=None, exclude_weeks=None ):
    """ Freshen homework and gradescopes
    """

    def create_header( row, owner_url ):
        if "https://" in row['Homework Repo Invite']:
            url = f"<a href='{row['Homework Repo Invite']}'>{row['Homework Repo Invite']}</a>"
        else:
            url = f"(Gradescope link not available yet)"
        header = f"""<p>This is a gradescope submission page.</p>
<p>Homework repo invite: {url}</p>
<p>Original assignment: <a href="{owner_url}">{row["HW+Title"]}</a></p>
<p>REMEMBER - you are uploading a) your repo from this page AND b) your <a href="{owner_url}">report HTML here.</a>
        """
        return header

    def update_gradescope_page(m,title,row,owner_url,**kwargs):
        assignment = find_assignment_in_assignments( assignments, title=title )
        if assignment is None:
            logger.success(f"assignment: {title} (creating assignment)")
            assignment = config.create_assignment(title,due_at=row['DateCanvas'],unlock_at=row['canvas_unlock_at'],lock_at=row['canvas_lock_at'],description=create_header( row,owner_url ))
        else:
            logger.success(f"assignment: {title} (reusing assignment)")
            logger.debug( as_pretty_json(assignment) )
            assignment = config.edit_assignment( assignment["id"],name=title,due_at=row['DateCanvas'],unlock_at=row['canvas_unlock_at'],lock_at=row['canvas_lock_at'],description=create_header( row,owner_url ) )
        return assignment

    config.canvas_endpoint
    config.outline_gsheet_key
    # get assignments from Canvas
    logger.debug("extracting assignments from canvas")
    assignments = config.get_assignments()

    logger.debug('extracting homeworks from outline')
    homeworks = extract_homeworks( )
    logger.trace( homeworks )

    logger.debug('extracting module_items from canvas')
    module_items = config.get_module_items()


    for i,row in homeworks.iterrows():
        logger.debug( row )
        owner_url = None
        if row['Homework Canvas ID'] != "":
            assignment = None
            if row['Homework doc ID'] != "":
                description = create_gdoc_iframe( row['Homework doc ID'] )
                if (not row["Homework Repo Invite"] in [""]) and ("https://" in row["Homework Repo Invite"]):
                    description = f"<p>Homework repo invite: <a href='{row['Homework Repo Invite']}'>{row['Homework Repo Invite']}</a></p>\n"+description
            else:
                description = row['HW+Title']
            try:
                assignment = config.edit_assignment( int(row['Homework Canvas ID']) ,name=row['HW+Title'],due_at=row['DateCanvas'],unlock_at=row['canvas_unlock_at'],lock_at=row['canvas_lock_at'], description=description )
                owner_url = assignment["html_url"]
                logger.success(f"assignment: {row['HW+Title']}  due: {row['DateCanvas']}  {row['Homework doc ID']}")
            except Exception as e:
                logger.warning(f"Unable to update: {row}\n{e}")

            if not row["Homework Repo Invite"]=="":
                gradescope_title = row["HW+Title"] + " (Gradescope)"
                assignment = find_assignment_in_assignments( assignments, title=gradescope_title )
                if assignment is None:
                    module_item = find_name_in_module_items( module_items, row['HW+Title'] )
                    if not module_item is None:
                        gradescope_page = update_gradescope_page( module_item, gradescope_title, row, owner_url )
                        mi = config.create_module_item(module_item["id"],type="Assignment",title=gradescope_page["name"],content_id=gradescope_page["id"],indent=1)
                    else:
                        gradescope_page = update_gradescope_page( module_item, gradescope_title, row, owner_url )
                else:
                    module_item = find_name_in_module_items( module_items, gradescope_title )
                    gradescope_page = update_gradescope_page( module_item, gradescope_title, row, owner_url )
        else:
            logger.warning(f"Unable to update. Add a Canvas ID to Outline: {row['HW+Title']}")


def create_or_replace_page( pages, title ):
    """ returns a canvas page object, either found or created """
    page = find_page_in_pages( pages, title )
    if page is None:
        logger.success(f"{title} (creating)")
        page = config.create_page( title )
    else:
        logger.success(f"{title} (reusing)")
    return page

def create_or_replace_quiz( quizzes, title=None, id=None, assignment_group = None ):
    """ returns a canvas quiz object, either found or created """
    quiz = find_quiz_in_quizzes( quizzes, title=title, id=id )
    ag = assignment_group+": " if assignment_group else ""
    if quiz is None:
        logger.success(f"{ag}{title} (creating)")
        quiz = config.create_quiz( title )
    else:
        logger.success(f"{ag}{title} (reusing)")
    return quiz


def create_or_replace_assignment( assignments, title=None, id=None, assignment_group=None ):
    """ returns a canvas assignment object, either found or created """
    assignment = find_assignment_in_assignments( assignments, title=title, id=id )
    ag = assignment_group+": " if assignment_group else ""
    if assignment is None:
        logger.success(f"{ag}{title} (creating)")
        assignment = config.create_assignment(title)
    else:
        logger.success(f"{ag}{title} (reusing)")
    return assignment

def create_or_replace_assignment_group( assignment_groups, name=None, id=None ):
    """ returns a canvas assignment group object, either found or created """
    ag = find_ag_in_assignment_groups( assignment_groups, name=name, id=id )
    if ag is None:
        logger.debug(f"{name} - creating assignment group")
        ag = config.create_assignment_group(name=name)
    else:
        logger.debug(f"{ag['name']} - reusing assignment group")
    return ag

def freshen_lectures_from_outlinex( include_weeks=None, exclude_weeks=None ):
    """ Freshen lecture pages in Canvas from data in outline """
    # Verify that all connections in config file are established.
    config.canvas_endpoint
    lecture_slides_endpoint = config.lecture_slides_endpoint
    config.outline_gsheet_key

    logger.debug( "get outline" )
    outline_df = retry_loop(3,load_course_outline_df)
    logger.trace( outline_df )

    logger.info(f"use_outline_lectures_tab: {config.use_outline_lectures_tab}")
    lectures_df = None
    if config.use_outline_lectures_tab:
        logger.debug( "get lecture tab, if it exists" )
        lectures_df = retry_loop(3, load_lectures_df )
        if lectures_df is None:
            logger.warning(f"Missing lectures tab in workbook.")
            logger.warning(f"Either add Lectures tab or set flag in .cnvsapi to false.")
            sys.exit(1)
        else:
            logger.info("lectures tab found")

    logger.debug("get pages")
    pages = config.get_pages()
    logger.trace(f"Pages: {[key for key in pages.keys()]}")

    logger.debug(f"Including weeks: {include_weeks}")
    logger.debug(f"Excluding weeks: {exclude_weeks}")


    proper_order = order_modules_by_week( outline_df, prefix=['instructor','welcome'],include_weeks=include_weeks, exclude_weeks=exclude_weeks )
    logger.debug( proper_order )

    for wk in proper_order:

        rows = outline_df[ outline_df["WK"] == str(wk) ]
        if rows.empty:
            continue

        week_id = module_prefix_from_id( wk )
        if wk=="welcome":
            week_name = "Welcome - introduction and references"
        elif wk=='instructor':
            week_name = "Instructor - private resources and links"
        else:
            week_name = f"{week_id} - {rows['Date'].iloc[0]} to {rows["Date"].iloc[-1]} - {rows["Topic"].iloc[0]}"

        if (1):
            logger.debug(week_name)
            lectures = add_lecture_file_names( extract_lectures( week=wk ) )
            logger.debug( lectures )
            if len(lectures)>0:
                for i,lecture in lectures.iterrows():
#                    add_module_slides_page( m,f"Lecture {lecture['Lecture ID']} - slides",lecture,indent=1,published=True)
#                    add_module_video_page( m,f"Lecture {lecture['Lecture ID']} - video",lecture,indent=1,published=False)    
                    title = f"Lecture {lecture['Lecture ID']} - slides"
                    page = find_page_in_pages( pages, title )
                    if page:

                        if lectures_df is None:
                            # Default logic - create page contents using quarto slides
                            filename = os.path.join( lecture_slides_endpoint, lecture['html_filename'])
                            logger.success(f"{page['url']} :  {title}   {filename}")
                            page = config.edit_page( page['url'],title = title, body=create_slide_iframe( filename ))
                        else:
                            row = lectures_df.loc[lectures_df["Lecture ID"].astype(str) == str(lecture['Lecture ID'])]
                            if not row.empty:
                                row = row.iloc[0].to_dict()
                                logger.debug( row )
                                body = None
                                if "page-gslide" in row["Type"]:
                                    body = create_gslide_iframe( row['Content'] )
                                elif "page-gdoc" in row["Type"]:
                                    body = create_gdoc_iframe( row['Content'] )
                                elif "page-slide" in row["Type"]:
                                    body = create_slide_iframe( row['Content'] )
                                else:
                                    logger.warning(f"Code doesn't recogize {row['Type']}.  Edit Lectures tab in Outline.")
                                if not body is None:
                                    page = config.edit_page( page['url'],title = title, body=body )


def freshen_lecture_videos_from_outline( include_weeks=None, exclude_weeks=None ):
    """ Amend the lecture video page body with zoom URL or Kaltura link as appropriate """

    logger.debug(f"freshen lecture videos from outline")

    # Verify that all connections in config file are established.
    config.canvas_endpoint
    lecture_slides_endpoint = config.lecture_slides_endpoint
    config.outline_gsheet_key

    logger.debug( "get outline" )
    outline_df = retry_loop(3,load_course_outline_df)
    logger.trace( outline_df )

    logger.debug( "get videos" )
    videos_df = retry_loop(3,load_course_videos_df)
    logger.trace( videos_df )


    logger.debug("get pages")
    pages = config.get_pages()
    logger.trace(f"Pages: {[key for key in pages.keys()]}")

    logger.debug(f"Including weeks: {include_weeks}")
    logger.debug(f"Excluding weeks: {exclude_weeks}")


    proper_order = order_modules_by_week( outline_df, prefix=['instructor','welcome'],include_weeks=include_weeks, exclude_weeks=exclude_weeks )
    logger.debug( proper_order )

    for wk in proper_order:

        rows = outline_df[ outline_df["WK"] == str(wk) ]
        if rows.empty:
            continue

        week_id = module_prefix_from_id( wk )
        if wk=="welcome":
            week_name = "Welcome - introduction and references"
        elif wk=='instructor':
            week_name = "Instructor - private resources and links"
        else:
            week_name = f"{week_id} - {rows['Date'].iloc[0]} to {rows["Date"].iloc[-1]} - {rows["Topic"].iloc[0]}"

        if (1):
            logger.debug(week_name)
            lectures = add_lecture_file_names( extract_lectures( week=wk ) )
            logger.debug( lectures )
            if len(lectures)>0:
                for i,lecture in lectures.iterrows():
#                    add_module_slides_page( m,f"Lecture {lecture['Lecture ID']} - slides",lecture,indent=1,published=True)
#                    add_module_video_page( m,f"Lecture {lecture['Lecture ID']} - video",lecture,indent=1,published=False)    
                    title = f"Lecture {lecture['Lecture ID']} - video"
                    body = lecture['page_message']
                    
                    row = videos_df[ videos_df["lecture_id"] == lecture['Lecture ID']]
                    logger.debug( row )
                    if not row is None:

                        zoom_lecture_url = row["zoom_lecture_url"].iloc[0].strip()
                        kaltura_lecture_url = row["kaltura_lecture_url"].iloc[0].strip()

                        if not zoom_lecture_url=="":
                            body = zoom_lecture_url
                            msg = "using zoom_lecture_url from Videos tab"

                        if not kaltura_lecture_url =="":
                            logger.debug( f"kaltura_lecture_url: '{kaltura_lecture_url}'")

                            body = create_kaltura_iframe( kaltura_lecture_url )
                            msg = "using kaltura_url from videos tab"

                    # add code to insert Kaltura URL as they are created.  check outline

                    page = find_page_in_pages( pages, get_title('lecture_video'),id=wk )
                    if page:
                        #filename = os.path.join( lecture_slides_endpoint, lecture['html_filename'])
                        logger.success(f"{page['url']} :  {title} : {msg}")
                        page = config.edit_page( page['url'],title = title, body=body, published=True )


def freshen_canvas_lectures_summary_page():
    """ Freshen canvas page with lecture links """

    def styleblock():
        block = """
        <style>
            .fp-container{
                width:100%;
                display: flex;
                flex-wrap: nowrap;
                flex-direction: row;
                gap: 10px;
                justify-content: flex-start;
                overflow-x: auto;
                margin-bottom: 20px;
                }
            .fp-lecture-button-available {
                display: inline-block;
                flex: 0 0 auto;
                width: 80px;
                background-color: lightgray;
                padding: 10px 20px;
                border: 2px solid black;
                border-radius: 5px;
                color: white;
                text-align: center;
                cursor: pointer;
                transition: background-color 0.3s;                     
            }
            .fp-lecture-button-available:hover {
                background-color:darkgray;
            }
            .fp-button-text {
                font-size: 18pt;
            }
            .fp-day {
                display:inline-block;
                width: 100px;
            }
            .no-decorator,
            .no-decorator:visited,
            .no-decorator:active {
                text-decoration: none ! important;
                color: none;
            }
            .no-decorator:hover{
                background-color: lightgray;
            }
            .fp-lecture-title {
                text-decorator: none;
            }
            .fp-lecture-title:hover {
                text-decorator: underline;
            }
        }
        </style>
        <script>
            document.addEventListener("DOMContentLoaded", function() {
                // Select the block with the id "myblock"
                console.log("Hello world from my script!")
                var myBlock = document.getElementById("myblock");
                if (myBlock) {
                    // Find all <span> elements with the class "external_link_icon" within the block
                    var spans = myBlock.getElementsByClassName("external_link_icon");
                    // Convert the HTMLCollection to an array and remove each element
                    Array.from(spans).forEach(function(span) {
                        span.parentNode.removeChild(span);
                    });
                    console.log('Removed external_link_icon spans from #myblock');
                } else {
                    console.log('#myblock not found');
                }
            });
        </script>
        """
        return block

    def get_body_from_lectures( lecture_df ):
        body = []
        body.append( styleblock() )
        body.append("<div class='fp-container'>")
        for index,row in lectures_df.iterrows():

            url = urljoin(config.lecture_slides_endpoint, row["html_filename"] )
            display_name = " " + row['id'] + " "
            title = row['title']
    
            body.append("<div class='fp-lecture-button-available'>")
            body.append(f"<a class='no-decorator' href='{url}'>")
            body.append("<span class='fp-button-text'>")
            body.append(f"{display_name}")
            body.append("</span>")
            body.append(f"</a>")
            body.append("</div>")

        body.append("</div>")
        body = "\n".join( body )
        return body

    def get_body_from_lectures_2( lecture_df ):
        body = []
        body.append( styleblock() )
        body.append("<ol>")
        for index,row in lectures_df.iterrows():

            url = urljoin(config.lecture_slides_endpoint, row["html_filename"] )
            display_name = "Lecture " + row['id']
            title = row['title']
    
            body.append(f"<li><span class='fp-day'>{row['calendar_dow']} {row['calendar_date_words']}</span> - <span class='fp-lecture-title'><a class='no-decorator' href='{url}'>{title}</a></span></li>")
            body.append("</div>")

        body.append("</ol")
        body = "\n".join( body )
        return body


    logger.info(f"freshen lecture summary pages")

    # Verify that all connections in config file are established.

    config.canvas_endpoint
    config.lecture_slides_endpoint
    config.outline_gsheet_key

    # Get receiving page.  Create it if it doesn't exist.
    page_name = "Instructor - Quick links to lecture slides"
    page = config.find_page( page_name )
    if page is None:
        logger.debug(f"page {page_name} doesn't exist.  Creating.")
        page = config.create_page( title=page_name,body="Temporary body.  Run freshen-canvas-lectures-summary-page to rebuild.",published=False)
        logger.trace( as_pretty_json( page ))

    # Build list of lectures and lecture URLs
    lectures_df = get_lecture_df()

    # build body page
    page_body = ""
#    page_body = page_body + get_body_from_lectures( lectures_df )
    page_body = page_body + "\n<hr>\n"
    page_body = page_body + get_body_from_lectures_2( lectures_df )

    page = config.edit_page( page['url'], body=page_body, published=False )



if __name__=="__main__":
#    build_lecture_files_from_outline()

#    master_sheet_id = "1cp9-7bAWZtcCDUfXEY5eD1Bg5SejFI-dqCjG0Mj1rXE"
#    folder_id = "1AQdw-gm-l_LEUMRr2ToQtJRtqB_SX0UF"
#    x = copy_google_sheet(master_sheet_id, folder_id )
#    print( f"{x}")
    pass
    

def freshen_lectures_from_outline( include_weeks=None, exclude_weeks=None ):
    """ Freshen lecture pages from lectures tab """
    config.canvas_endpoint
    lecture_slides_endpoint = config.lecture_slides_endpoint
    config.outline_gsheet_key

    pages = config.get_pages()
    lectures_df = get_lecture_df()

    outline_df = extract_outline()
    weeks_list = order_weeks_by_week( outline_df, prefix=['instructor','welcome'],include_weeks=include_weeks, exclude_weeks=exclude_weeks )

    if len(lectures_df)>0:

        for i,lecture in lectures_df.iterrows():

            if lecture['week_id'] in weeks_list:

                lecture_page = create_or_replace_page( pages, get_title( "lecture_slide", id=lecture['id']) )
                video_page = create_or_replace_page( pages, get_title( "lecture_video", id=lecture['id']) )

                if lecture_page:
                    content_type = lecture['content_type']
                    content_url = lecture['content_url']
                    title = lecture_page['title']

                    if "page-gslide" in content_type:
                        body = create_gslide_iframe( lecture['content_url'] )
                    elif "page-gdoc" in content_type:
                        body = create_gdoc_iframe( lecture['content_url'] )
                    elif "page-slide" in content_type:
                        body = create_slide_iframe( lecture['content_url'] )
                    else:
                        filename = os.path.join( lecture_slides_endpoint, lecture['html_filename'])
                        body = body=create_slide_iframe( filename )
                    lecture_page = config.edit_page( lecture_page['url'],title = title, body=body, published=True )

                if video_page:

                    title = video_page['title']
                    body = lecture['page_message']
                        
                    video_url = lecture["video_url"].strip()

                    if video_url:
                        logger.debug( f"external video_url: '{video_url}'")

                        body = create_kaltura_iframe( video_url )
                        # only update the video page if Kaltura Link exists.
                        # This ensures that if the page was updated manually, it won't be overwritten!
                    else:
                        page = config.get_page( video_page['url'],include=['body'] )
                        logger.debug( video_page )
                        logger.debug( page )
                        body = page['body']

                    if not "external_tools" in body:
                        body = lecture['page_message']

                    video_page = config.edit_page( video_page['url'],title = title, body=body, published=True )

def clean_group_list( group_string ):
    """ return list of group lists"""
    assignment_groups = config.get_assignment_groups()
    logger.debug( assignment_groups )
    temp_list = []
    for key,group in assignment_groups.items():
        temp_list.append( group['name'].lower().replace(" ", "_") )
    if group_string is None:
        logger.success(f"Missing group flag - will process all groups")
        return temp_list
    groups = group_string.split(",")
    if groups[0]=="all":
        return temp_list
    group_list = [ group for group in groups if group in temp_list ]
    if not group_list:
        logger.warning(f"No valid assignment groups: {group_string}")
        logger.warning(f"Valid list includes: {temp_list}")
    return group_list


def freshen_assignment_groups_from_outline():
    """ Freshen assignment groups by syncing with outline and pruning unused groups """

    def extract_number(title):
        try:
            match = re.search(r"(\d+)", title)
            if match:
                value = int(match.group(1))  # Convert the matched number to an integer
            else:
                raise ValueError("No numeric value found")
            return value
        except Exception as e:
            return 9999999999999  # Assign a high value to ensure it appears last in the sort


    current_function = inspect.currentframe().f_code.co_name
    docstring = globals()[current_function].__doc__
    logger.debug( docstring )

    config.canvas_endpoint
    config.outline_gsheet_key

    # Load individual tabs from workbook.  These should all share common columns used below.
    # Assigning the source tab to activity type so we know what resources to connect.
    homeworks = extract_homeworks().copy()
    if not homeworks.empty:
        homeworks.loc[:,'activity_type'] = "assignment"
    projects = extract_projects().copy()
    if not projects.empty:
        projects.loc[:,'activity_type'] = "assignment"
    discussions = extract_discussions().copy()
    if not discussions.empty:
        discussions.loc[:,'activity_type'] = "assignment"
    surveys = extract_surveys().copy()
    if not surveys.empty:
        surveys.loc[:,'activity_type'] = "quiz"
    quizzes = extract_quizzes().copy()
    if not quizzes.empty:
        quizzes.loc[:,'activity_type'] = "quiz"

    # Combine the pages and resort by group and by id within group. Id is extracted from title.
    combined_df = pd.concat([homeworks,projects,surveys,quizzes,discussions], ignore_index=True)
    combined_df = combined_df.where(pd.notna(combined_df), None)
    combined_df["canvas_title_sort_key"] = combined_df["canvas_title"].apply(extract_number)
    combined_df = combined_df.sort_values(by=["canvas_assignment_group", "canvas_title_sort_key"], ascending=[True, True])

    # build list of assignments groups used by items in the outline
    outline_groups_used = combined_df["canvas_assignment_group"].unique().tolist()
    outline_groups_used = [item.strip() for item in outline_groups_used if not item.strip()==""]

    # load list from assignment groups tab and build list of unused assignment groups
    outline_groups = extract_assignment_groups().copy()
    outline_groups_unused = []
    for id,row in outline_groups.iterrows():
        if not row['name'] in outline_groups_used:
            outline_groups_unused.append( row['name'] )

    # Load canvas groups for syncing
    canvas_groups = config.get_assignment_groups() # from Canvas
    # Creating missing groups and sync canvas positions and group weights to match google sheet
    for g in outline_groups_used:
        if not outline_groups[outline_groups['name']==g].empty:
            position = outline_groups.loc[ outline_groups['name']==g,'position'].iloc[0]
            group_weight = outline_groups.loc[ outline_groups['name']==g,'group_weight'].iloc[0]
        else:
            position=0
            group_weight=0
        ag = create_or_replace_assignment_group( canvas_groups, name=g )
        ag = config.edit_assignment_group( ag['id'], position=position, group_weight=group_weight )

    # We've got outline_groups, outline_groups_used and outline_groups_unused
    # And, canvas groups are synced to outline groups

    # Reload canvas groups (after syncing above) and include assignments details.
    canvas_groups = config.get_assignment_groups(include=['assignments']) # from Canvas

    # build list of used and unused assignment groups
    canvas_groups_used = []
    canvas_groups_unused = []
    canvas_groups_group_weight_sum = 0
    for ag_key,ag in canvas_groups.items():
        canvas_groups_group_weight_sum += ag['group_weight']
        if not ag['assignments']:
            if not ag['name'] in canvas_groups_used:
                canvas_groups_unused.append( ag['name'] )
        else:
            if not ag['name'] in canvas_groups_unused:
                canvas_groups_used.append( ag['name'] )

    

    logger.success(f"Outline groups used: {outline_groups_used}" )
    logger.success(f"Outline groups unused: {outline_groups_unused}" )
    logger.success(f"Canvas groups used: {canvas_groups_used}" )
    logger.success(f"Canvas groups unused: {canvas_groups_unused}" )
    logger.success(f"Sum of group weights: {canvas_groups_group_weight_sum}")

    # Clean up assignment groups by removing any empty groups
    # This is an expensive query, contents of each individual assignment are transferred.
    # perhaps a facter logic can be found, but this is tight.

    for ag_key,ag in canvas_groups.items():
        if not ag['assignments']:
            logger.warning(f"Removing unused assignment group from Canvas: {ag['name']}")
            config.delete_assignment_group( ag_key )

    config.update_course( apply_assignment_group_weights=True )


def get_outline_objects():
    """ return large dataframe containing homeworks, quizzes, projects, discussions, and surveys """
    def extract_number(title):
        try:
            match = re.search(r"(\d+)", title)
            if match:
                value = int(match.group(1))  # Convert the matched number to an integer
            else:
                raise ValueError("No numeric value found")
            return value
        except Exception as e:
            return 9999999999999  # Assign a high value to ensure it appears last in the sort

    # Load individual tabs from workbook.  These should all share common columns used below.
    # Assigning the source tab to activity type so we know what resources to connect.
    resources = extract_resources().copy()
    if not resources.empty:
        resources.loc[:,'activity_type'] = "resource"
    overviews = extract_overviews().copy()
    if not overviews.empty:
        overviews.loc[:,'activity_type'] = "overview"
    lectures = extract_lectures().copy()
    if not lectures.empty:
        lectures.loc[:,'activity_type'] = "lecture"


    homeworks = extract_homeworks().copy()
    if not homeworks.empty:
        homeworks.loc[:,'activity_type'] = "assignment"
    projects = extract_projects().copy()
    if not projects.empty:
        projects.loc[:,'activity_type'] = "assignment"
    discussions = extract_discussions().copy()
    if not discussions.empty:
        discussions.loc[:,'activity_type'] = "assignment"
    surveys = extract_surveys().copy()
    if not surveys.empty:
        surveys.loc[:,'activity_type'] = "quiz"
    quizzes = extract_quizzes().copy()
    if not quizzes.empty:
        quizzes.loc[:,'activity_type'] = "quiz"

    # Combine the pages and resort by group and by id within group. Id is extracted from title.
    combined_df = pd.concat([resources,overviews,lectures,homeworks,projects,surveys,quizzes,discussions], ignore_index=True)
    combined_df = combined_df.where(pd.notna(combined_df), None)
    combined_df["canvas_title_sort_key"] = combined_df["canvas_title"].apply(extract_number)
    combined_df = combined_df.sort_values(by=["canvas_assignment_group", "canvas_title_sort_key","canvas_title"], ascending=[True, True, True])
    # assign an order within the group for use when updating assignments in Canvas
    combined_df["canvas_title_sort_key"] = combined_df.groupby("canvas_assignment_group").cumcount() + 1
    return combined_df

def freshen_canvas_objects_from_outline( include_weeks=None, exclude_weeks=None, group_list=None ):
    """ Freshen canvas objects
    """

    def extract_number(title):
        try:
            match = re.search(r"(\d+)", title)
            if match:
                value = int(match.group(1))  # Convert the matched number to an integer
            else:
                raise ValueError("No numeric value found")
            return value
        except Exception as e:
            return 9999999999999  # Assign a high value to ensure it appears last in the sort
    

    def create_header( row, owner_url ):
        if 'has_gradescope_page' in row.keys():
            if "https://" in str(row['has_gradescope_page']):
                url = f"<a href='{row['has_gradescope_page']}'>{row['has_gradescope_page']}</a>"
            else:
                url = row['has_gradescope_page']
        else:
            url = "no gradescope page"
        header = f"""<p>This is a gradescope submission page.</p>
<p>Homework repo invite: {url}</p>
<p>Original assignment: <a href="{owner_url}">{row["canvas_title"]}</a></p>
<p>REMEMBER - you are uploading a) your repo from this page AND b) your <a href="{owner_url}">report HTML here.</a>
        """
        return header

    def update_gradescope_page(m,title,row,owner_url,**kwargs):
        assignment = find_assignment_in_assignments( assignments, title=title )
        if assignment is None:
            logger.success(f"assignment: {title} (creating assignment)")
            assignment = config.create_assignment(title,due_at=row['DateCanvas'],unlock_at=row['canvas_unlock_at'],lock_at=row['canvas_lock_at'],description=create_header( row,owner_url ))
        else:
            logger.success(f"assignment: {title} (reusing assignment)")
            logger.debug( as_pretty_json(assignment) )
            assignment = config.edit_assignment( assignment["id"],name=title,due_at=row['DateCanvas'],unlock_at=row['canvas_unlock_at'],lock_at=row['canvas_lock_at'],description=create_header( row,owner_url ) )
        return assignment

    # ----------------------------------------------------------

    config.canvas_endpoint
    config.outline_gsheet_key

    # Load individual tabs from workbook.  These should all share common columns used below.
    # Assigning the source tab to activity type so we know what resources to connect.
    homeworks = extract_homeworks().copy()
    if not homeworks.empty:
        homeworks.loc[:,'activity_type'] = "assignment"
    projects = extract_projects().copy()
    if not projects.empty:
        projects.loc[:,'activity_type'] = "assignment"
    discussions = extract_discussions().copy()
    if not discussions.empty:
        discussions.loc[:,'activity_type'] = "assignment"
    surveys = extract_surveys().copy()
    if not surveys.empty:
        surveys.loc[:,'activity_type'] = "quiz"
    quizzes = extract_quizzes().copy()
    if not quizzes.empty:
        quizzes.loc[:,'activity_type'] = "quiz"

    # Combine the pages and resort by group and by id within group. Id is extracted from title.
    combined_df = pd.concat([homeworks,projects,surveys,quizzes,discussions], ignore_index=True)
    combined_df = combined_df.where(pd.notna(combined_df), None)
    combined_df["canvas_title_sort_key"] = combined_df["canvas_title"].apply(extract_number)
    combined_df = combined_df.sort_values(by=["canvas_assignment_group", "canvas_title_sort_key","canvas_title"], ascending=[True, True, True])
    # assign an order within the group for use when updating assignments in Canvas
    combined_df["canvas_title_sort_key"] = combined_df.groupby("canvas_assignment_group").cumcount() + 1

    # load canvas groups and assignments.
    # Note that assignments come in a dictionary by group.
    assignment_groups = config.get_assignment_groups()
    #assignments = config.get_assignments() # from Canvas, dictionary by assignment group!
    canvas_quizzes = config.get_quizzes()  # from Canvas

    logger.debug( assignment_groups )

    unique_outline_groups = combined_df["canvas_assignment_group"].unique().tolist()
    outline_assignment_groups = extract_assignment_groups().copy()
    logger.debug( unique_outline_groups )
    for g in unique_outline_groups:
        if not outline_assignment_groups[outline_assignment_groups['name']==g].empty:
            position = outline_assignment_groups.loc[ outline_assignment_groups['name']==g,'position'].iloc[0]
            group_weight = outline_assignment_groups.loc[ outline_assignment_groups['name']==g,'group_weight'].iloc[0]
        else:
            position=0
            group_weight=0
        ag = create_or_replace_assignment_group( assignment_groups, name=g )
        logger.debug( ag )
        ag = config.edit_assignment_group( ag['id'], position=position, group_weight=group_weight )
        logger.debug( ag )

    # get revised list of assignment groups
    assignment_groups = config.get_assignment_groups( include=['assignments'])
    logger.trace( assignment_groups )

    # Load the master outline, create a list of weeks (including special week names) to process
    outline_df = extract_outline() # from outline gsheet
    weeks_list = order_weeks_by_week( outline_df, prefix=['instructor','welcome'],include_weeks=include_weeks, exclude_weeks=exclude_weeks )

    # Loop over all activities
    for i,row in combined_df.iterrows():

        # only process desired groups
        if not row['canvas_assignment_group'].lower().replace(" ","_") in group_list:
            logger.success(f"skipping assignment group: {row['canvas_assignment_group'].lower().replace(" ","_")}")
            continue

        # Process if the activity is found in the list of weeks to process
        if row['week_id'] in weeks_list:

            # process Homeworks, Projects and Discussions
            # activity_type is assigned above, not found in the google doc.
            if row['activity_type'] in ['assignment']:

                title = row['canvas_title']
                canvas_id = row['canvas_id']
                assignment = create_or_replace_assignment( assignment_groups, title=title, id=canvas_id, assignment_group = row['canvas_assignment_group'] )
                if not assignment:
                    logger.error(f"Failed: {title} - {canvas_id}")
                if assignment:

                    # main submission
                    canvas_id = assignment['id']
                    logger.debug( canvas_id )
                    logger.debug( title )
                    description = row['description'] if row['description'] else ""
                    if row['google_doc_id']:
                        description = create_gdoc_iframe( row['google_doc_id'], description=row['description'] )
                    ag = find_ag_in_assignment_groups( assignment_groups, name=row['canvas_assignment_group'] )
                    assignment = config.edit_assignment( canvas_id,
                                                        name=row['canvas_title'],
                                                        position=row['canvas_title_sort_key'],
                                                        due_at=row['canvas_due_at'],
                                                        unlock_at=row['canvas_unlock_at'],
                                                        lock_at=row['canvas_lock_at'],
                                                        assignment_group_id=ag['id'],
                                                        description=description )
                    owner_url = assignment["html_url"]

                    # If submission uses gradescope, too.
                    if row['has_gradescope_page']:
                        logger.debug(f"Creating gradescope page: {row}")
                        gradescope_title = get_title("gradescope",title=title)
                        assignment = create_or_replace_assignment( assignment_groups, title=gradescope_title, id=None, assignment_group = row['canvas_assignment_group']  )
                        assignment = config.edit_assignment(
                            assignment["id"],
                            name=gradescope_title,
                            position=row['canvas_title_sort_key'],
                            due_at=row['canvas_due_at'],
                            unlock_at=row['canvas_unlock_at'],
                            lock_at=row['canvas_lock_at'],
                            assignment_group_id=ag['id'],
                            description=create_header( row,owner_url ) )

            elif row['activity_type'] in ['quiz']:
                title = row['canvas_title']
                quiz = create_or_replace_quiz( canvas_quizzes, title=title, id=None, assignment_group = row['canvas_assignment_group'] )
                ag = find_ag_in_assignment_groups( assignment_groups, name=row['canvas_assignment_group'] )
                if quiz:
                    if not row['canvas_quiz_type'] in ['practice_quiz','graded_survey','survey']:
                        row['canvas_quiz_type'] = 'assignment'

                    # set shared quiz attributes
                    quiz_args = dict(
                        assignment_group_id=ag['id'],
                        position=row['canvas_title_sort_key'],
                        quiz_type=row['canvas_quiz_type'],
                        due_at=row['canvas_due_at'],unlock_at=row['canvas_unlock_at'],lock_at=row['canvas_lock_at'],
                        description=create_gdoc_iframe( row['google_doc_id'],title,row['description'])
                    )

                    # customize based on type of quiz
                    # see: https://canvas.instructure.com/doc/api/quizzes.html#method.quizzes/quizzes_api.update

                    canvas_quiz_type = "practice_quiz" if "practice" in row['canvas_title'].lower() else row['canvas_quiz_type']
                    if canvas_quiz_type in ['practice_quiz']:
                        extras = dict(
                            shuffle_answers=True,
                            allowed_attempts=-1
                        )
                    elif canvas_quiz_type in ['survey']:
                        extras = dict(
                            allowed_attempts=-1
                        )
                    elif canvas_quiz_type in ['graded survey']:
                        extras = dict(
                            allowed_attempts=-1
                        )
                    else:
                        extras = dict(
                            shuffle_answers=True,
                            allowed_attempts=1
                        )
                    quiz_args.update(extras)
                    logger.debug( quiz_args )
                    quiz = config.edit_quiz( quiz['id'], title=title, **quiz_args )
                    logger.debug( quiz )

    # finally, clean up assignment groups by removing any empty groups
    # This is an expensive query, contents of each individual assignment are transferred.
    # perhaps a facter logic can be found, but this is tight.

    assignment_groups = config.get_assignment_groups(include=['assignments'])
    canvas_assignment_titles = []
    for ag_key,ag in assignment_groups.items():
        if not ag['assignments']:
            logger.warning(f"{ag['name']} doesn't have any assignments.")
            if 1:
                config.delete_assignment_group( ag_key )
        else:
            for assignment in ag['assignments']:
                if not 'gradescope' in assignment['name'].lower():
                    canvas_assignment_titles.append( assignment['name'] )

#            page = config.create_quiz(title,due_at=row['DateCanvas'],unlock_at=row['canvas_unlock_at'],lock_at=row['canvas_lock_at'],description=description)

    # build list of assignment names in Outline

    outline_assignment_titles = sorted(combined_df["canvas_title"].unique().tolist())
    canvas_assignment_titles = sorted(canvas_assignment_titles)

    logger.debug(f"Outline assignments: { outline_assignment_titles }")
    logger.debug(f"Canvas assignments: { canvas_assignment_titles }")


    set_outline = set(outline_assignment_titles)
    set_canvas = set(canvas_assignment_titles)

    outline_extras = set_outline - set_canvas
    if outline_extras:
        logger.warning(f"Assignments in canvas but not in outline: { outline_extras }")
        logger.warning(f"This should NEVER happen.  We just resynced and added any missing outline items to canvas!")

    canvas_extras = set_canvas - set_outline
    if canvas_extras:
        logger.warning(f"Assignments in canvas but not in outline: { canvas_extras }")
        logger.warning(f"Delete these assignments from Canvas OR Add them to the outline!")

    logger.debug(f"Setting apply_assignment_group_weights")
    config.update_course( apply_assignment_group_weights=True )


def freshen_canvas_frontpages_from_outline( include_weeks=None, exclude_weeks=None, additional_weeks_to_show=None, set_current_week=None ):
    """ Freshen details pages """

    def clean_html_block( html ):
        match = re.search(r'<link[^>]*>.*?<p>(.*?)</p>.*?<script', html, re.DOTALL)
        if match:
            logger.debug( match.group(1).strip() )
            return match.group(1).strip()
        return html
    
    def is_number(value):
        try:
            int(value)  # or use int(value) if you only want to check for integers
            return True
        except ValueError:
            return False
    
    def get_week_from_outline( outline_df, today=None ):
        """ given a outline dataframe determine the current week of the semester """
        if today:
            today_date = datetime.datetime.date( today )
        else:
            today_date = datetime.datetime.date(datetime.datetime.now())
        today_row = outline_df[outline_df['DateCanvas'].dt.date == today_date]
        if today_row.size==0:
            wk = 0
        else:
            wk = int(today_row["week_id"].iloc[0])
        if not set_current_week is None:
            wk = int(set_current_week)
        return wk

    def get_deliverables_for_week( assignments, week_id ):
        """ pick out deliverables for the week """
        deliverables = []
        for ag_value in assignments.values():
            for as_value in ag_value['assignments'].values():
                if str(week_id)==str(as_value['week_id']):
                    deliverables.append( dict(name=as_value['name'],url=as_value['html_url'] ) )
        return deliverables
    
    def get_lectures_for_week( lectures_df, week_id, pages ):
        """ determine lectures for the current week """
        lectures = []
        for id,row in lectures_df.iterrows():
            if week_id==row['week_id']:
                # Look for lecture slides page
                page_title = get_title('lecture_slide',row['id'])
                page = find_page_in_pages( pages, page_title)
                if not page:
                    logger.error(f'Missing lecture slides for week {row['id']}.  Rerun freshen canvas-lectures-from-outline.')
                    sys.exit(1)
                lectures.append( dict(name=page_title,url=page['html_url'] ) )
                # Look for lecture videos page
                page_title = get_title('lecture_video',row['id'])
                page = find_page_in_pages( pages, page_title)
                if not page:
                    logger.error(f'Missing lecture video for week {row['id']}.  Rerun freshen canvas-lectures-from-outline.')
                    sys.exit(1)
                lectures.append( dict(name=page_title,url=page['html_url'] ) )
        return lectures

    def get_resources_for_week( resources_df, week_id, pages ):
        """ return list of resources for current week """
        resources = []
        for id,row in resources_df.iterrows():
            if week_id.lower()==row['week_id'].lower():
                logger.debug( f"{row['type']} - {row['title']}" )
                if row['type'].lower() in ["external_url","external-url"]:
                    url = row['content']
                elif row['type']=='page':
                    logger.debug(f"searching for page: {row['content']}")
                    page = find_page_in_pages( pages, row['content'] )
                    if not page:
                        logger.error(f"Missing resource page for '{row['content']}'. Rerun freshen canvas-resources-from-outline")
                        sys.exit(1)
                    url = page['html_url']
                else:
                    page = find_page_in_pages( pages, row['title'] )
                    if not page:
                        logger.error(f"Missing resource page for '{row['title']}'. Rerun freshen canvas-resources-from-outline")
                        sys.exit(1)
                    url = page['html_url']
                resources.append( dict(name=row['displayed'],url=url )  )
        return resources


    logger.debug(f"Freshen details from Overview tab in outline")
    config.canvas_endpoint
    config.outline_gsheet_key

    logger.debug(f"Including weeks: {include_weeks}")
    logger.debug(f"Excluding weeks: {exclude_weeks}")

    #combined_df = get_outline_objects()
    #logger.debug(combined_df)

    outline_df = extract_outline().copy()
    outline_df['DateCanvas'] = pd.to_datetime( outline_df['DateCanvas'] )
 
#    outline_df.loc[:, 'DateCanvas'] = pd.to_datetime(outline_df['DateCanvas'])

    weeks_list = order_weeks_by_week( outline_df, prefix=['instructor','welcome'],include_weeks=include_weeks, exclude_weeks=exclude_weeks )
    logger.debug( weeks_list )
    current_week = get_week_from_outline( outline_df )    

    # add a week_id to each assignment based on when assignment is due.
    assignments = config.get_assignments()
    for ag_value in assignments.values():
        for as_value in ag_value['assignments'].values():
            as_value['week_id'] = get_week_from_outline( outline_df, today=pd.to_datetime( as_value['due_at'] ) )


    overview_df = extract_overviews()
    lectures_df = extract_lectures()
    resources_df = extract_resources()

    pages = config.get_pages()
    logger.debug(f"{[key for key in pages.keys()]}")


    for week_id in weeks_list:

        logger.debug(f"processing frontpage: {week_id}")

        # get module_name (a larger grouping of weeks) and overview text
        module_name = overview_df.loc[ overview_df['week_id'].str.lower()==week_id.lower(),'module'].squeeze()
        logger.debug( module_name )
        overview_text = overview_df.loc[ overview_df['week_id'].str.lower()==week_id.lower(),'overview'].squeeze()
        if not overview_text:
            logger.warning(f"Missing overview for {week_id}")
        logger.debug( overview_text )

        # Get week starting and end for subtitle
        week_start = overview_df.loc[ overview_df['week_id']==week_id,'week_start'].squeeze()
        week_end = overview_df.loc[ overview_df['week_id']==week_id,'week_end'].squeeze()

        logger.debug( week_id )
        logger.debug( week_start )
        logger.debug( week_end )
#        if not(week_start.empty or week_end.empty):
        if isinstance(week_start, str) and isinstance(week_end, str) and week_start and week_end:
            subtitle = f"{week_start} to {week_end} - {module_name}"
        else:
            subtitle = ""

        # Get deliverables for the week as a list of dictionaries with name and url keys
        deliverables = get_deliverables_for_week( assignments, week_id )
        logger.debug( deliverables )

        # get lectures as list of dictionaries with name and url keys
        lectures = get_lectures_for_week( lectures_df, week_id, pages )

        resources = get_resources_for_week( resources_df, week_id, pages )
        logger.debug( resources )

        # Get details content
        page = find_page_in_pages( pages, get_title("details",id=week_id))
        if not page:
            logger.error(f"Missing details page for week {week_id}. Rerun freshen canvas-details-from-outline.")
            sys.exit(1)
        page = config.get_page( page['url'] )
        logger.debug( page )
        details_body_text = page["body"]

        body_text = front_page_html(
                    week_id,
                    overview_df,
                    pages,
                    course_subj_and_num='CMSC 408',
                    week_title=f"Week {week_id} - {module_name}" if is_number(week_id) else f"{module_name}",
                    week_subtitle=subtitle,
                    overview=f"{overview_text}",
#                    deliverables = [{'name':'name','url':'https:www.google.com'},{'name':'name','url':'https:www.google.com'}],
                    deliverables=deliverables,
#                    lectures = [{'name':'lecture 1','url':'https:www.google.com'},{'name':'lecture 2','url':'https:www.google.com'}],
                    lectures = lectures,
#                    resources = [{'name':'resource 1','url':'https:www.google.com'},{'name':'resource 2','url':'https:www.google.com'}],
                    resources = resources,
                    details=details_body_text,
                    current_week=current_week,
                    additional_weeks_to_show=99
                     )

        page = create_or_replace_page( pages, get_title( "frontpage", id=week_id) )
        title = page['title']
        body = body_text
        existing_page_body = config.get_page( page['url'] )['body']

        if isinstance(week_id,int):
            front_page = current_week == week_id
        else:
            front_page = week_id.lower()=="welcome"

        # save the frontpage
        page = config.edit_page( page['url'],title = title, body=body, published=True, front_page = front_page )

    logger.debug("Setting homepage to wiki")
    config.update_course( default_view="wiki" )
