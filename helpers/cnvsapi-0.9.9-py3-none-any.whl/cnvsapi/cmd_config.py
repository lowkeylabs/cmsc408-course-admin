""" docstring for cmd_assessment
"""
import os
import re
import json
import click

from loguru import logger
import markdown
import pandas as pd

from cnvsapi.utils import as_pretty_json
from cnvsapi.config import config, DEFAULT_LOG_LEVEL,ENV_TOKEN_NAME

@click.group(invoke_without_command=True)
#@click.option("--course-id",help="Display details for this outcome ID",default=None,type=int)
#@click.option("--courses",help="Display courses and ids",is_flag=True, default=False)
@click.pass_context
def cli(ctx):
    """ Examine and change .cnvsapi configuration file.


    """
 
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())
        logger.success("")
        logger.success( config.get_status() )


if (0):
    @cli.command()
    @click.option("--overwrite",help="Overwrite destination file",default=False, is_flag=True )
    @click.pass_context
    def qmd(ctx,overwrite):
        """ Create assessment QMD from template """
        msg = config.roster_qmd_from_template(overwrite=overwrite)
        if not msg is None:
            click.echo( msg )


if __name__ == '__main__':
    cli(obj={})


