""" docstring for cmd_assessment
"""
import os
import re
import json
import click

import time

from loguru import logger
import markdown
import pandas as pd

from cnvsapi.utils import as_pretty_json
from cnvsapi.config import config, DEFAULT_LOG_LEVEL,ENV_TOKEN_NAME

@click.group(invoke_without_command=True)
#@click.option("--course-id",help="Display details for this outcome ID",default=None,type=int)
#@click.option("--courses",help="Display courses and ids",is_flag=True, default=False)
@click.pass_context
#def cli(ctx,course_id,courses):
def cli( ctx ):
    """ Example usage of cnvsapi commands.

    > List courses available to your canvas account.  Refer to these course_ids for later commands.

        cnvsapi list courses

    > List modules and module-items for course 10001

        cnvsapi --course-id=10001 list module-items

    > Create a local configuration file and set a default course-id

        cnvsapi --course-id=10001 --save

    or

        cnvsapi config course-id=10001 --save


        

    """
    if ctx.invoked_subcommand is None:
        print(f"Default course id: {config.course_id}")
        print(f"Default plugin folder: {config.plugin_folder}")
        click.echo(ctx.get_help())

if (0):
    @cli.command()
    @click.option("--overwrite",help="Overwrite destination file",default=False, is_flag=True )
    @click.pass_context
    def general(ctx,overwrite):
        """ List general examples

        List canvas courses available to your account:

            cnvsapi list courses
        

        """
        msg = config.roster_qmd_from_template(overwrite=overwrite)
        if not msg is None:
            click.echo( msg )

@cli.command()
@click.argument( "filename", type=click.Path(exists=True) )
@click.pass_context
def upload(ctx,filename):
    """ List general examples

    List canvas courses available to your account:

        cnvsapi list courses
    

    """
    click.echo( filename )
    rv = config.upload_file( filename )
    click.echo( as_pretty_json( rv ) )


@cli.command()
@click.pass_context
def get_files(ctx ):
    """ List general examples

    List canvas courses available to your account:

        cnvsapi list courses
    

    """
    files = config.get_files()
    click.echo( as_pretty_json( files ) )


@cli.command()
@click.argument( "filename", type=click.Path(exists=True) )
@click.pass_context
def upload_quiz_bank(ctx,filename):
    """ Upload a QTI question bank file (zip)

    """
    logger.debug( filename )
    rv = config.upload_file( filename )
    if rv:
        logger.debug( as_pretty_json( rv ) )
        file_info = rv[1]
        logger.debug( file_info )
        # Import the QTI file as a question bank
        import_params = {
            "migration_type": "qti_converter",
            "pre_attachment": {
                "name": file_info["display_name"],
                "upload_status": "success",
                "id": file_info["id"],
            },
            "settings": {
                "question_bank_name": filename  # Specify the question bank name
            },

        }
        logger.debug( import_params )
        logger.debug("waiting to let dust settle")
        time.sleep(10)
        logger.debug("ok - coming back")
        content_migration = config.get_default_course_endpoint().create_content_migration( **import_params )
        rv = config.get_python_object( content_migration )
        click.echo( as_pretty_json( rv ) )

if __name__ == '__main__':
    cli(obj={})


