""" docstring for cmd_download
"""
import os
import re
import csv
import json
import click
import markdown
import pandas as pd

from io import StringIO
from loguru import logger
from datetime import datetime, timezone, date

from cnvsapi.utils import as_pretty_json
from cnvsapi.config import config, DEFAULT_LOG_LEVEL,ENV_TOKEN_NAME

@click.group(invoke_without_command=True)
@click.option("--course-id",help="Display details for this outcome ID",default=None,type=int)
@click.option("--courses",help="Display courses and ids",is_flag=True, default=False)
@click.pass_context
def cli(ctx,course_id,courses):
    """ Download tools for Canvas
    """
    if courses:
        crses = config.get_courses()
        comments = ""
        for id in crses.keys():
            line = f"{'' if id==config.course_id else '# '}course_id={id:<8d} #  {crses[id]['name']}"
            print( line )
            comments = comments + "\n" + line
        return
    if not course_id is None:
        ctx.obj["COURSE_ID"] = course_id
        config.course_id = course_id
    
    course = config.get_default_course();
#    ctx["COURSE"] = course

    if ctx.invoked_subcommand is None:
        print(f"Default course id: {config.course_id} / {course["sis_course_id"]}")
        print(f"Default plugin folder: {config.plugin_folder}")
        default_report = config.config['assessment']['rubric']['default']
        print(f"Default rubric format is: {default_report}")
        print(f"Default rubric fields are:\n{as_pretty_json(config.config['assessment']['rubric'][default_report])}")
        click.echo(ctx.get_help())


def my_command(to_csv):
    if to_csv:
        if os.path.exists(to_csv):
            # The file already exists, so prompt the user for confirmation
            click.confirm(f"The file '{to_csv}' already exists. Do you want to overwrite it?", abort=True)

        click.echo(f"Converting to CSV and saving to {to_csv}")
        # Perform your CSV conversion logic here and save it to 'to_csv'
    else:
        click.echo("No CSV file name specified")

if __name__ == '__main__':
    my_command()


@cli.command()
@click.option('--to-csv', type=click.Path(), help='Specify the CSV file name', default="outcomes.xlsx")
@click.option("--overwrite",help="Overwrite destination file",default=False, is_flag=True )
@click.pass_context
def rubric_details(ctx,to_csv,overwrite):
    """ Generate stacked (narrow) rubric workbook across all assignments for course """
    if to_csv:
        if os.path.exists(to_csv) and not overwrite:
            # The file already exists, so prompt the user for confirmation
            click.confirm(f"The file '{to_csv}' already exists. Do you want to overwrite it?", abort=True)

    assignment_groups = config.get_assignments()
    users = config.get_users()

    # Loop over all assignment groups
    output_string = ""
    for ag_id in assignment_groups.keys():
        # Loop over assignments in assignment group
        for as_id in assignment_groups[ag_id]["assignments"].keys():
            # create shortcut to assignment
            assignment = assignment_groups[ag_id]["assignments"][as_id]
            # Continue if this assignment has a rubric
            if "rubric" in assignment.keys():
                # create shortcut to rubric
                rubric = assignment["rubric"]
                # print all potential rubric ratings
                rubric_dict = {}
                for rbi in rubric:
                    rubric_dict[rbi["id"]] = rbi
                    rubric_dict[rbi["id"]]["ratings_dict"] = {}
                    for rating in rbi["ratings"]:
                        rubric_dict[rbi["id"]]["ratings_dict"][rating["id"]] = rating
                        common_columns = [
                            assignment_groups[ag_id]['name'],
                            assignment['name'],
                            'Ratings',
                        ]
                        local_columns = [
                            rbi['description'],
                            rating["description"],
                            rating["points"]
                        ]
                        line = "\t".join( map(str,common_columns+local_columns) )
#                        output_string = output_string + "\n" + line;
                # Get responses
                responses = config.get_python_object_from( config.get_default_course_endpoint().get_assignment( as_id ).get_submissions,include=['rubric_assessment','assignment'])
#                print(as_pretty_json(responses))
#                return
                for resp_id in responses.keys():
                    response = responses[resp_id]
                    if "assignment" in response.keys():
                        # Build rubric dictionary from response assignment.  Sometimes originals are deleted.
                        rubric_dict = {}
                        for rbi in response["assignment"]["rubric"]:
                            rubric_dict[rbi["id"]] = rbi
                            rubric_dict[rbi["id"]]["ratings_dict"] = {}
                            for rating in rbi["ratings"]:
                                rubric_dict[rbi["id"]]["ratings_dict"][rating["id"]] = rating

                    if "rubric_assessment" in response.keys():
                        for key in response["rubric_assessment"].keys():
                            rating = response["rubric_assessment"][key]

                            default_report = config.config["assessment"]["rubric"]["default"]
                            report = config.config["assessment"]["rubric"][default_report]
                            fields = []
                            for var in report["assignment_group"]:
                                if var in assignment_groups[ag_id].keys():
                                    fields.append( assignment_groups[ag_id][var] )
                                else:
                                    fields.append( f"assignment_group {var} (not found)" )

                            for var in report["assignment"]:
                                if var in assignment.keys():
                                    fields.append( assignment[var] )
                                else:
                                    fields.append( f"assignment {var} (not found)" )

                            for var in report["user"]:
                                try:
                                    if var in users[response["user_id"]].keys():
                                        fields.append( users[response["user_id"]][var] )
                                    else:
                                        fields.append( f"user {var} (not found)" )
                                except Exception as e:
                                    fields.append(f"users[response['user_id']] {response['user_id']} not found")

                            for var in report["rubric"]:
                                try:
                                    if var in rubric_dict[key].keys():
                                        fields.append( rubric_dict[key][var] )
                                    else:
                                        fields.append( f"rubric {var} (not found)" )
                                except Exception as e:
                                    fields.append(f"rubric_dict[key] {key} not found")
                            
                            for var in report["rating"]:
                                try:
                                    if var in rubric_dict[key]["ratings_dict"][rating["rating_id"]].keys():
                                        fields.append( rubric_dict[key]["ratings_dict"][rating["rating_id"]][var] )
                                    else:
                                        fields.append( f"rating {var} (not found)" )
                                except Exception as e:
                                    fields.append(f"rating {var} host not found")
  
                            line = "\t".join( map(str,fields) )
                            output_string = output_string + "\n" + line;
    
        df = pd.read_csv(StringIO(output_string), sep='\t')
#        df.columns = ["Assignment Group","Assignment","Student","Assessment","Rating","Points"]
        df.to_excel(to_csv, index=False)

#            print(as_pretty_json(responses))


@cli.command()
@click.option('--to-csv', type=click.Path(), help='Specify the CSV file name', default=None)
@click.option("--overwrite",help="Overwrite destination file",default=False, is_flag=True )
@click.pass_context
def gradebook(ctx,to_csv,overwrite):
    """ Generate stacked (long-form) gradebook with one record per student per assignment for all active students """

    if not to_csv:
        today_str = date.today().strftime("%Y-%m-%d")
        to_csv = f"gradebook-{today_str}.csv"

    if to_csv:

        if os.path.exists(to_csv) and not overwrite:
            # The file already exists, so prompt the user for confirmation
            click.confirm(f"The file '{to_csv}' already exists. Do you want to overwrite it?", abort=True)

    students = {}
    for u in config.get_default_course_endpoint().get_users(enrollment_type=["student"], include=["email"], enrollment_state=["active"]):
        students[u.id] = {
            "name": u.name,
            "sortable_name": getattr(u, "sortable_name", u.name),
            "login_id": getattr(u, "login_id", None),
            "sis_user_id": getattr(u, "sis_user_id", None),
        }

    groups = config.get_assignment_groups()
    logger.debug( groups )

    assignments = config.get_default_course_endpoint().get_assignments(order_by='position')
    rows = []
    for a in assignments:
        now = datetime.now(timezone.utc)
        can_submit = (
            a.published and
            not getattr(a, "only_visible_to_overrides", False) and
            a.submission_types and
            "not_graded" not in a.submission_types and
            (a.unlock_at is None or datetime.fromisoformat(a.unlock_at.replace("Z","+00:00")) <= now) and
            (a.lock_at is None or datetime.fromisoformat(a.lock_at.replace("Z","+00:00")) > now)
        )
        too_early = (a.unlock_at is None) or (datetime.fromisoformat(a.unlock_at.replace("Z","+00:00")) > now)
        assignment_state = "OPEN" if can_submit else ("EARLY" if too_early else "CLOSED")
        print( f"{a.id:8} ({assignment_state:5}) {a.name}" )

        subs = a.get_submissions(include=["user", "submission_history", "rubric_assessment"])

        for s in subs:

            if s.user_id not in students:
                # Try to pick up user name if the API returned s.user
                display_name = getattr(getattr(s, "user", None), "name", None)
                login_id = getattr(getattr(s,"user", None),"login_id", None )
                students.setdefault(s.user_id, {"name": display_name or f"User {s.user_id}",
                                                "sortable_name": display_name or f"User {s.user_id}",
                                                "login_id" : login_id or f"(missing)" } )

            rows.append({
                "user_id": s.user_id,
                "student_name": students[s.user_id]["sortable_name"] if s.user_id in students else f"User {s.user_id}",
                "student_email" : ( students[s.user_id]["login_id"] + "@vcu.edu") if s.user_id in students else "",
                "assignment_id": a.id,
                "assignment_name": a.name,
                "assignment_state" : assignment_state,
                "assignment_group_name" : groups[int(a.assignment_group_id)]["name"] if a.assignment_group_id else "",
                "assignment_group_position"  : groups[int(a.assignment_group_id)]["position"] if a.assignment_group_id else "99",
                "assignment_group_weight"  : groups[int(a.assignment_group_id)]["group_weight"] if a.assignment_group_id else "0.0",
                "points_possible": a.points_possible,
                "score": s.score,  # numeric; None if no score yet
                "entered_score": getattr(s, "entered_score", None),
                "workflow_state": getattr(s, "workflow_state", None),  # 'graded', 'submitted', 'unsubmitted', etc.
                "late": getattr(s, "late", None),
                "missing": getattr(s, "missing", None),
                "excused": getattr(s, "excused", None),
                "graded_at": getattr(s, "graded_at", None),
                "submitted_at": getattr(s, "submitted_at", None),
                "attempt": getattr(s, "attempt", None),
                "grading_status": getattr(s, "grading_status", None),
            })


    with open(to_csv, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "user_id","student_name","student_email","assignment_id","assignment_name","assignment_state",
                "assignment_group_name","assignment_group_position","assignment_group_weight",
                "points_possible","score","entered_score","workflow_state",
                "late","missing","excused","graded_at","submitted_at","attempt","grading_status"
            ]
        )
        writer.writeheader()
        writer.writerows(rows)

if __name__ == '__main__':
    cli(obj={})


