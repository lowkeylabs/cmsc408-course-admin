""" docstring for cmd_outline
"""
import os
import re
import json
import click

from loguru import logger
import markdown
import pandas as pd
from datetime import datetime

from cnvsapi.build_utils import extract_lectures,extract_quizzes,extract_homeworks, \
    extract_weeks, extract_overviews, extract_resources, extract_projects, \
    extract_notes, extract_surveys, extract_discussions, extract_assignment_groups
from cnvsapi.utils import as_pretty_json, clean_include_lists
from cnvsapi.config import config, DEFAULT_LOG_LEVEL, ENV_TOKEN_NAME, DEFAULT_ATTRIBUTES
from cnvsapi.outline_utils import outline_instructor_checklist, outline_lecture_map, lecture_topics_from_disk

@click.group(invoke_without_command=True)
@click.option("--course-id",help="Display details for this outcome ID",default=None,type=int)
@click.option("--courses",help="Display courses and ids",is_flag=True, default=False)
@click.pass_context
def cli(ctx,course_id,courses):
    """ List outline settings.

    An outline is a google workbook containing course configuration information.  It's 
    much easier to modify the outline and let this tools modify canvas directly.
    
    """
    if courses:
        crses = config.get_courses()
        comments = ""
        for id in crses.keys():
            line = f"{'' if id==config.course_id else '# '}course_id={id:<8d} #  {crses[id]['name']}"
            print( line )
            comments = comments + "\n" + line
        return
    elif not course_id is None:
        ctx.obj["COURSE_ID"] = course_id
        config.course_id = course_id
    if ctx.invoked_subcommand is None:
        click.echo(f"Course id: {config.course_id} {' --> Select course from .cnvsapi' if config.course_id==None else '' }")

        click.echo(" ")
        for key in DEFAULT_ATTRIBUTES['course_attributes'].keys():
            click.echo(f"{key} : {config.get_course_attribute(key)}")
        click.echo(" ")

        click.echo(ctx.get_help())


@cli.command()
@click.pass_context
def lectures(ctx):
    """ List lectures found in google sheet """
    df = extract_lectures()
    click.echo(f"{df.columns}")
    for i,row in df.iterrows():
        datetime_string = row["calendar_date"]
#        datetime_object = datetime.strptime(datetime_string, "%m/%d/%Y %H:%M:%S")
#        formatted_date = datetime_object.strftime("%a, %b. %d")
        click.echo(f"{row['outline_entry']}, {datetime_string} ({row['calendar_dow']})") 


@cli.command()
@click.pass_context
def quizzes(ctx):
    """ List quizzes found in google sheet """
    df = extract_quizzes()
    for i,row in df.iterrows():
        datetime_string = row["calendar_date"]
#        datetime_object = datetime.strptime(datetime_string, "%m/%d/%Y %H:%M:%S")
#        formatted_date = datetime_object.strftime("%a, %b. %d")
        click.echo(f"{row['outline_entry']}, due {datetime_string} ({row['calendar_dow']})")

@cli.command()
@click.pass_context
def homeworks(ctx):
    """ List homeworks found in google sheet """
    df = extract_homeworks()
    for i,row in df.iterrows():
        datetime_string = row["calendar_date"]
#        datetime_object = datetime.strptime(datetime_string, "%m/%d/%Y %H:%M:%S")
#        formatted_date = datetime_object.strftime("%a, %b. %d")
        if row["has_gradescope_page"]!="":
            gradescope = ", (has gradescope page)"
        else:
            gradescope = ""
        click.echo(f"{row['outline_entry']}, due {datetime_string}{gradescope} ({row['calendar_dow']})")

@cli.command()
@click.pass_context
def projects(ctx):
    """ List projects found in google sheet """
    df = extract_projects()
    for i,row in df.iterrows():
        datetime_string = row["calendar_date"]
#        datetime_object = datetime.strptime(datetime_string, "%m/%d/%Y %H:%M:%S")
#        formatted_date = datetime_object.strftime("%a, %b. %d")
        if row["has_gradescope_page"]!="":
            gradescope = ",(has gradescope page)"
        else:
            gradescope = ""
        click.echo(f"{row['outline_entry']}, due {datetime_string}{gradescope} ({row['calendar_dow']})")
    if df.empty:
        logger.warning(f"No projects available.  Check the projects tab and the id or week_id columns.")


@cli.command()
@click.pass_context
def overviews(ctx):
    """ List overviews found in google sheet """
    df = extract_overviews()
    for i,row in df.iterrows():
        click.echo(f"Week {str(row['week_id']):2}: {row['overview']}")


@cli.command()
@click.pass_context
def resources(ctx):
    """ List overviews found in google sheet """
    df = extract_resources()
    for i,row in df.iterrows():
        click.echo(f"{row['title']} : {row["content"]}")

@cli.command()
@click.pass_context
def notes(ctx):
    """ List notes found in google sheet """
    df = extract_notes()
    for i,row in df.iterrows():
        click.echo(f"{str(row['date']):6}: {row['notes']}")

@cli.command()
@click.pass_context
def surveys(ctx):
    """ List surveys found in google sheet """
    df = extract_surveys()
    for i,row in df.iterrows():
        datetime_string = row["calendar_date"]
        click.echo(f"{row['outline_entry']}, due {datetime_string} ({row['calendar_dow']})")

@cli.command()
@click.pass_context
def discussions(ctx):
    """ List discussions found in google sheet """
    df = extract_discussions()
    for i,row in df.iterrows():
        datetime_string = row["calendar_date"]
        click.echo(f"{row['outline_entry']}, due {datetime_string} ({row['calendar_dow']})")

@cli.command()
@click.pass_context
def assignment_groups(ctx):
    """ List discussions found in google sheet """
    df = extract_assignment_groups()
    for i,row in df.iterrows():
        click.echo(f"{str(row['name']):15}: {row['group_weight']}% : {row['position']}")

    df.loc[:,'group_weight'] = df['group_weight'].astype(int)
    total_weight = int(df['group_weight'].sum())
    click.echo(f"Total Weight: {total_weight}")
    if not total_weight==int(100):
        logger.warning(f'Sum of group weights ({total_weight}) does not sum to 100! Check our "assignment-groups" tab.')

@cli.command()
@click.option("--all",help="Show all weeks",default=True, is_flag=True )
@click.option("--include-weeks",type=str,help="List of week ids to include",default=None )
@click.option("--exclude-weeks",type=str,help="List of week ids to exclude",default=None )
@click.option("--only-not-ok",help="Show only not OK records", is_flag=True,default=True)
@click.option("--within-days",help="Show only rows due within X days", default=365)
@click.pass_context
def checklist(ctx,all,include_weeks,exclude_weeks,only_not_ok,within_days):
    """ Instructor things-to-do ordered by unlock_date.
     
      
    """

    all,include_list,exclude_list = clean_include_lists( all, include_weeks, exclude_weeks )
    if (not all) and (include_list is None) and (exclude_list is None):
        click.echo(ctx.get_help())
    else:
        checklist = outline_instructor_checklist( include_weeks=include_list,exclude_weeks=exclude_list, only_not_ok=only_not_ok,within_days=within_days )
        click.echo(f"{checklist}")


@cli.command()
@click.option("--all",help="Show all weeks",default=True, is_flag=True )
@click.option("--include-weeks",type=str,help="List of week ids to include",default=None )
@click.option("--exclude-weeks",type=str,help="List of week ids to exclude",default=None )
@click.option("--from-disk",default=True, is_flag=True,help="Use topics from lecture files")
@click.option("--tablefmt",default="pretty",type=str,help="Tabulate table format to use")
@click.option("--csv-filename", type=click.Path(exists=False, writable=True), help="Output CSV filename", default=None)
@click.option("--xlsx-filename", type=click.Path(exists=False, writable=True), help="Output XLSX filename", default=None)
@click.pass_context
def lecture_map(ctx,all,include_weeks,exclude_weeks,from_disk,tablefmt,csv_filename,xlsx_filename):
    """ Lists lecture topic units by lecture and week
      
    """

    all,include_list,exclude_list = clean_include_lists( all, include_weeks, exclude_weeks )
    if (not all) and (include_list is None) and (exclude_list is None):
        click.echo(ctx.get_help())
    else:
        if from_disk:
            checklist = lecture_topics_from_disk( include_weeks=include_list,exclude_weeks=exclude_list,
                                                 tablefmt=tablefmt,csv_filename=csv_filename,xlsx_filename=xlsx_filename )
        else:
            checklist = outline_lecture_map( include_weeks=include_list,exclude_weeks=exclude_list )
        click.echo(f"{checklist}")



if __name__ == '__main__':
    cli(obj={})


