""" docstring for cmd_assessment
"""
import os
import re
import json
import click
import markdown
import pandas as pd

from io import StringIO
from loguru import logger

from cnvsapi.utils import as_pretty_json
from cnvsapi.config import config, DEFAULT_LOG_LEVEL,ENV_TOKEN_NAME

@click.group(invoke_without_command=True)
@click.option("--course-id",help="Display details for this outcome ID",default=None,type=int)
@click.option("--courses",help="Display courses and ids",is_flag=True, default=False)
@click.pass_context
def cli(ctx,course_id,courses):
    """ Assessment generator
    """
    if courses:
        crses = config.get_courses()
        comments = ""
        for id in crses.keys():
            line = f"{'' if id==config.course_id else '# '}course_id={id:<8d} #  {crses[id]['name']}"
            print( line )
            comments = comments + "\n" + line
        return
    if not course_id is None:
        ctx.obj["COURSE_ID"] = course_id
        config.course_id = course_id
    
    course = config.get_default_course();
#    ctx["COURSE"] = course

    if ctx.invoked_subcommand is None:
        print(f"Default course id: {config.course_id} / {course["sis_course_id"]}")
        print(f"Default plugin folder: {config.plugin_folder}")
        default_report = config.config['assessment']['rubric']['default']
        print(f"Default rubric format is: {default_report}")
        print(f"Default rubric fields are:\n{as_pretty_json(config.config['assessment']['rubric'][default_report])}")
        click.echo(ctx.get_help())


def my_command(to_csv):
    if to_csv:
        if os.path.exists(to_csv):
            # The file already exists, so prompt the user for confirmation
            click.confirm(f"The file '{to_csv}' already exists. Do you want to overwrite it?", abort=True)

        click.echo(f"Converting to CSV and saving to {to_csv}")
        # Perform your CSV conversion logic here and save it to 'to_csv'
    else:
        click.echo("No CSV file name specified")

if __name__ == '__main__':
    my_command()


@cli.command()
@click.option('--to-csv', type=click.Path(), help='Specify the CSV file name', default="outcomes.xlsx")
@click.option("--overwrite",help="Overwrite destination file",default=False, is_flag=True )
@click.pass_context
def rubrics(ctx,to_csv,overwrite):
    """ Generate stacked (narrow) rubric workbook acros all assignments for course """
    if to_csv:
        if os.path.exists(to_csv) and not overwrite:
            # The file already exists, so prompt the user for confirmation
            click.confirm(f"The file '{to_csv}' already exists. Do you want to overwrite it?", abort=True)

    assignment_groups = config.get_assignments()
    users = config.get_users()

    # Loop over all assignment groups
    output_string = ""
    for ag_id in assignment_groups.keys():
        # Loop over assignments in assignment group
        for as_id in assignment_groups[ag_id]["assignments"].keys():
            # create shortcut to assignment
            assignment = assignment_groups[ag_id]["assignments"][as_id]
            # Continue if this assignment has a rubric
            if "rubric" in assignment.keys():
                # create shortcut to rubric
                rubric = assignment["rubric"]
                # print all potential rubric ratings
                rubric_dict = {}
                for rbi in rubric:
                    rubric_dict[rbi["id"]] = rbi
                    rubric_dict[rbi["id"]]["ratings_dict"] = {}
                    for rating in rbi["ratings"]:
                        rubric_dict[rbi["id"]]["ratings_dict"][rating["id"]] = rating
                        common_columns = [
                            assignment_groups[ag_id]['name'],
                            assignment['name'],
                            'Ratings',
                        ]
                        local_columns = [
                            rbi['description'],
                            rating["description"],
                            rating["points"]
                        ]
                        line = "\t".join( map(str,common_columns+local_columns) )
#                        output_string = output_string + "\n" + line;
                # Get responses
                responses = config.get_python_object_from( config.get_default_course_endpoint().get_assignment( as_id ).get_submissions,include=['rubric_assessment','assignment'])
#                print(as_pretty_json(responses))
#                return
                for resp_id in responses.keys():
                    response = responses[resp_id]
                    if "assignment" in response.keys():
                        # Build rubric dictionary from response assignment.  Sometimes originals are deleted.
                        rubric_dict = {}
                        for rbi in response["assignment"]["rubric"]:
                            rubric_dict[rbi["id"]] = rbi
                            rubric_dict[rbi["id"]]["ratings_dict"] = {}
                            for rating in rbi["ratings"]:
                                rubric_dict[rbi["id"]]["ratings_dict"][rating["id"]] = rating

                    if "rubric_assessment" in response.keys():
                        for key in response["rubric_assessment"].keys():
                            rating = response["rubric_assessment"][key]

                            default_report = config.config["assessment"]["rubric"]["default"]
                            report = config.config["assessment"]["rubric"][default_report]
                            fields = []
                            for var in report["assignment_group"]:
                                if var in assignment_groups[ag_id].keys():
                                    fields.append( assignment_groups[ag_id][var] )
                                else:
                                    fields.append( f"assignment_group {var} (not found)" )

                            for var in report["assignment"]:
                                if var in assignment.keys():
                                    fields.append( assignment[var] )
                                else:
                                    fields.append( f"assignment {var} (not found)" )

                            for var in report["user"]:
                                try:
                                    if var in users[response["user_id"]].keys():
                                        fields.append( users[response["user_id"]][var] )
                                    else:
                                        fields.append( f"user {var} (not found)" )
                                except Exception as e:
                                    fields.append(f"users[response['user_id']] {response['user_id']} not found")

                            for var in report["rubric"]:
                                try:
                                    if var in rubric_dict[key].keys():
                                        fields.append( rubric_dict[key][var] )
                                    else:
                                        fields.append( f"rubric {var} (not found)" )
                                except Exception as e:
                                    fields.append(f"rubric_dict[key] {key} not found")
                            
                            for var in report["rating"]:
                                try:
                                    if var in rubric_dict[key]["ratings_dict"][rating["rating_id"]].keys():
                                        fields.append( rubric_dict[key]["ratings_dict"][rating["rating_id"]][var] )
                                    else:
                                        fields.append( f"rating {var} (not found)" )
                                except Exception as e:
                                    fields.append(f"rating {var} host not found")
  
                            line = "\t".join( map(str,fields) )
                            output_string = output_string + "\n" + line;
    
        df = pd.read_csv(StringIO(output_string), sep='\t')
#        df.columns = ["Assignment Group","Assignment","Student","Assessment","Rating","Points"]
        df.to_excel(to_csv, index=False)

#            print(as_pretty_json(responses))

if __name__ == '__main__':
    cli(obj={})


