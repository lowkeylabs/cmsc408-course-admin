""" docstring for cmd_open
"""
import os
import re
import json
import click
import webbrowser

from loguru import logger
import markdown
import pandas as pd

from cnvsapi.utils import as_pretty_json
from cnvsapi.config import config, DEFAULT_LOG_LEVEL,ENV_TOKEN_NAME


@click.group(invoke_without_command=True)
@click.pass_context
def cli(ctx):
    """ Open cnvsapi files using shortcuts.
    
    opens files by shortcut

    """

    if ctx.invoked_subcommand is None:
        course = config.get_default_course()
        print(f"Default course id: {config.course_id} / {course["sis_course_id"]}")
        click.echo(ctx.get_help())


@cli.command()
@click.pass_context
def outline( ctx ):
    """ open outline using id in .cnvsapi """
    key = config.outline_gsheet_key
    logger.debug( key )
    url = "https://docs.google.com/spreadsheets/d/" + key
    try:
        webbrowser.open( url )
    except Exception as e:
        logger.error(f"Failed to open {url}: {e}")


@cli.command()
@click.pass_context
def syllabus( ctx ):
    """ open syllabus using id in .cnvsapi """
    key = config.syllabus_gdoc_key
    logger.debug( key )
    url = "https://docs.google.com/document/d/" + key
    try:
        webbrowser.open( url )
    except Exception as e:
        logger.error(f"Failed to open {url}: {e}")

@cli.command()
@click.pass_context
def folder( ctx ):
    """ open folder using id in .cnvsapi """
    key = config.outline_google_folder
    logger.debug( key )
    url = "https://drive.google.com/drive/folders/" + key
    try:
        webbrowser.open( url )
    except Exception as e:
        logger.error(f"Failed to open {url}: {e}")


@cli.command()
@click.pass_context
def canvas( ctx ):
    """ open canvas courses listing """
    canvas_endpoint = config.canvas_endpoint
    course_id = config.course_id

    logger.debug(f"canvas_endpoint: {canvas_endpoint}" )
    logger.debug(f"course id: {course_id}")

    url = canvas_endpoint+"/courses/"

    logger.debug( url )
    try:
        webbrowser.open( url )
    except Exception as e:
        logger.error(f"Failed to open {url}: {e}")


@cli.command()
@click.pass_context
def course( ctx ):
    """ open canvas course using web browser """
    canvas_endpoint = config.canvas_endpoint
    course_id = config.course_id

    logger.debug(f"canvas_endpoint: {canvas_endpoint}" )
    logger.debug(f"course id: {course_id}")

    if not course_id is None:
        url = canvas_endpoint+"/courses/"+ str(course_id)
    else:
        url = canvas_endpoint+"/courses/"

    logger.debug( url )
    try:
        webbrowser.open( url )
    except Exception as e:
        logger.error(f"Failed to open {url}: {e}")

@cli.command()
@click.pass_context
def dashboard( ctx ):
    """ open canvas dashboard """
    canvas_endpoint = config.canvas_endpoint
    course_id = config.course_id

    logger.debug(f"canvas_endpoint: {canvas_endpoint}" )
    logger.debug(f"course id: {course_id}")

    url = canvas_endpoint

    logger.debug( url )
    try:
        webbrowser.open( url )

    except Exception as e:
        logger.error(f"Failed to open {url}: {e}")

if __name__ == '__main__':
    cli(obj={})


