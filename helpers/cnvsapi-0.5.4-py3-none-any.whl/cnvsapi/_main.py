""" docstring for _main.py
"""
import os
import sys
import json
import click
from pprint import pprint
from loguru import logger
from datetime import datetime
from collections.abc import Iterable

#import cnvsapi.utils
#from canvasapi import Canvas
from cnvsapi.config import config, DEFAULT_LOG_LEVEL,ENV_TOKEN_NAME, ExternalCommandClass, config_file_name, program_name

#from cnvsapi.utils import edit_list_with_editor, update_modules, update_moduleitems
#from cnvsapi.bridge import bridge

@click.group()
def cli1():
    # this group callback is never called.
    pass


@click.command( cls=ExternalCommandClass, plugin_folder=config.plugin_folder )
def cli2():
    """ This structure pulls in the externally stored commands. See config.py """
    pass

# Here is an example of a mini command stored in this file rather than in a plugin.
# These are merged in the final group

#@cli1.command()
#@click.pass_context
#def status( cts ):
#    """ Provide some sort of status for the system.  Needs more work!"""
#    print( config.get_status() )


@click.group(cls=click.CommandCollection,sources=[cli1,cli2],invoke_without_command=True)
@click.version_option( package_name="cnvsapi" )
@click.option('--log-level', help="Set log level (TRACE, DEBUG, INFO, SUCCESS, WARNING, ERROR, CRITICAL)", default=config.log_level )
#@click.option('--debug-vars', help="Show debug var details",default=False,is_flag=True)
@click.option('--course-id', help="Default course ID", type=int)
@click.option('--save',help=f"Use with --course-id to save configuration to {config_file_name}",default=False, is_flag=True)
@click.pass_context
def cli(ctx,log_level,course_id,save):
    """ Canvas CLI. 
    \n\n
    This command line interface (CLI) provides access to Canvas through the published canvas API.
    Some things are best left to the Canvas user interface, so this application doesn't try to do everything.
    However, sometimes the Canvas GUI is just too heavy or cludgy. So - this tool was created.

    Use "cnvsapi config" to create and customize a local configuration file.
    
    """
    ctx.ensure_object( dict )
    ctx.obj['LOG_LEVEL'] = log_level

#    ctx.obj['DEBUG_VARS'] = debug_vars
    if not course_id is None:
        if not config.course_id is None:
            click.echo(f"--course-id argument ignored.")
            click.echo(f"Course ID already set in {config.config_file_name}.  Comment it out before continuing.")
        else:
            logger.info(f"Course ID set to {course_id} by --course-id argument.")
            config.course_id = course_id

    if config.log_level != log_level:
        config.log_level = log_level
#        logger.info(f"Log level set to {log_level} by --log-level argument.")  Duplicate missage from sniffer.  See top of config.py.

    if save:
        config.save()

    logger.info(f"Invoking subcommand: {ctx.invoked_subcommand}")
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


if __name__ == "__main__":
    cli()
