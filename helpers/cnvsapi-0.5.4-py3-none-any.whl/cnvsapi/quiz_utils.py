"""
Utility files to support build command
"""
import os
import re
import sys
import json
import click
import shutil
import gspread
import warnings
import datetime
import frontmatter
import pandas as pd

#import numpy as np
from loguru import logger
from tabulate import tabulate
from cnvsapi.config import config
from IPython.display import Markdown, HTML, display
from oauth2client.service_account import ServiceAccountCredentials

def test():
    print("hello world!")


def write_df_to_gsheet( df, gsheet_id, gsheet_tab='Source data' ):
    """ write dataframe to google sheets """
    # Set up credentials
    logger.debug(f"sheet_id: {gsheet_id}  ::  gsheet_tab:{gsheet_tab}")
    scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/spreadsheets",
            "https://www.googleapis.com/auth/drive.file", "https://www.googleapis.com/auth/drive"]
    creds = ServiceAccountCredentials.from_json_keyfile_name(config.gsecrets, scope)
    client = gspread.authorize(creds)

    # Open the Google Sheet and create/use the tab. Add it if it doesn't exist.
    spreadsheet = client.open_by_key(gsheet_id)
    try:
        worksheet = spreadsheet.worksheet(gsheet_tab)  # You can specify the worksheet index (0 for the first sheet)
    except gspread.exceptions.WorksheetNotFound:
        worksheet = spreadsheet.add_worksheet(title=gsheet_tab,rows=1000,cols=10)

    # Clear existing content (optional)
    worksheet.clear()

    # Write DataFrame to Google Sheet
    warnings.filterwarnings("ignore", category=UserWarning, message=".*[Dd]eprecated.*")
    worksheet.update([df.columns.tolist()] + df.values.tolist())
    warnings.resetwarnings()
