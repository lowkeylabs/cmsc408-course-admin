"""
Utility files to support build command
"""
import os
import re
import sys
import json
import click
import shutil
import gspread
import inspect
import datetime
import frontmatter
import pandas as pd

from bs4 import BeautifulSoup

#import numpy as np
from loguru import logger
from tabulate import tabulate
from urllib.parse import urljoin
from cnvsapi.config import config
from IPython.display import Markdown, HTML, display
from oauth2client.service_account import ServiceAccountCredentials
from googleapiclient.discovery import build
from cachetools import TTLCache, cached
from gspread.exceptions import WorksheetNotFound

from cnvsapi.utils import grab_filenames, filter_filenames, find_page_in_pages


def freshen_canvas_pages_from_disk( confirm=False, all=True, include_words=None, exclude_words=None, page_dir="." ):
    """ Freshen canvas pages for files located in local folder
    (second line)
    """
    current_function = inspect.currentframe().f_code.co_name
    docstring = globals()[current_function].__doc__
    logger.debug( docstring.split("\n",1)[0] )

    logger.debug( config.local_page_folder )
    logger.debug( all )
    logger.debug( include_words )
    logger.debug( exclude_words )

    # Load files from page_dir and filter appropriately.  Return if nothing matches or is found.
    try:
        filenames = grab_filenames( page_dir )
        filtered_filenames = filter_filenames( filenames, include_words, exclude_words )
        logger.debug( filtered_filenames )
    except Exception as e:
        logger.error( e )
        return None
    
    # If we're actually going to do work, load the pages from Canvas:

    pages = config.get_pages()
    if not pages:
        logger.error("can't load pages")
        return None
    
    freshened_count = 0
    file_count = 0
    for i,filename in enumerate( filtered_filenames ):  

        logger.debug( filename )

        if not os.path.exists( filename ):
            continue
        
        if filename.endswith('.html'):
            title,body_content = parse_html_file( filename )
        else:
            logger.warning( f"Skipping {filename}. Not set to parse these files.")
            continue
        
        
        # Getting here, you've got a title and body content, and confirm flag
        file_count += 1
        logger.debug( title )
        logger.debug( body_content )
        if confirm:
            freshened_count += 1
            page = create_or_replace_page( pages, title )
            if page:
                body_content = f'<div id="dp-wrapper" class="dp-wrapper">{body_content}</div>'
                page = config.edit_page( page['url'],title = title, body=body_content, published=True )
                #logger.success(f"PROCESSING Page title: {title} in file: {filename}" )
            else:
                logger.error(f"Could not process page: {title}")
        else:
            logger.success(f"No changes: '{title}' in: '{filename}'" )
           

    if not confirm:
        logger.success('Use --confirm to change pages.')
    return file_count, freshened_count

def create_or_replace_page( pages, title ):
    """ returns a canvas page object, either found or created """
    page = find_page_in_pages( pages, title )
    if page is None:
        logger.success(f"{title} (creating)")
        page = config.create_page( title )
    else:
        logger.success(f"{title} (reusing)")
    return page


def parse_html_file(filename):
    """
    Parses an HTML file to extract the body and title.

    Args:
        filename (str): Path to the HTML file.

    Returns:
        tuple: A tuple containing the body content as a string and the title string.
               If the title or body is not found, it returns None for the respective element.
    """
    try:
        # Load the file
        with open(filename, 'r', encoding='utf-8') as file:
            html_content = file.read()

        # Parse the HTML
        soup = BeautifulSoup(html_content, 'html.parser')

        # Extract the title from an element with the "title" class
        title_element = soup.find(class_="title")
        title = title_element.get_text(strip=True) if title_element else None

        # Extract the body
        header_block = soup.find('header', id='title-block-header')
        if header_block:
            header_block.decompose()  # Remove the header block from the soup

        body = soup.body
        #body_content = body.get_text(strip=True) if body else None
        body_content = str(body) if body else None  # Use str() to keep HTML tags


        return title, body_content

    except FileNotFoundError:
        logger.error(f"Error: File '{filename}' not found.")
        return None, None
    except Exception as e:
        logger.error(f"An error occurred while parsing the file: {e}")
        return None, None
    