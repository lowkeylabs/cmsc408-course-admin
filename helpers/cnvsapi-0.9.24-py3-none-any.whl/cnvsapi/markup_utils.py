"""
Markup utilities - expanding links into canvas connections
"""

from cnvsapi.config import config
from cnvsapi.utils import find_page_in_pages, find_quiz_in_quizzes2, find_assignment_in_assignments, find_file_in_files, kwargs_to_string


def expand_resource( resource, resource_title, resource_name, source_type="page", url_type="html", target=None, **kwargs ):
    """ expand assignment to url """
    # look up assignment URL
    url = resource_name
    if source_type=="page":
        item = find_page_in_pages( resource, title=resource_name )
    elif source_type=="assignment":
        item = find_assignment_in_assignments( resource, title=resource_name )
    elif source_type=="quiz":
        item = find_quiz_in_quizzes2( resource, title=resource_name )
    elif source_type=="file":
        item = find_file_in_files( resource, title=resource_name )
        item['src'] = config.canvas_endpoint + f"/courses/{str(config.course_id)}/files/{str(item['id'])}/preview"
        item['alt'] = item['display_name']
        item['data-api-endpoint'] = config.canvas_endpoint + f"/api/v1/courses/{str(config.course_id)}/files/{str(item['id'])}"
        item['data-api-returntype'] = "File"
    # if found, get the html url
    if item:
        url = item.get('html_url',"")
    elif resource_name.lower()=="syllabus":
        url = config.canvas_endpoint + f"/courses/{str(config.course_id)}/assignments/syllabus"
    elif resource_name.lower()=="assignments":
        url = config.canvas_endpoint + f"/courses/{str(config.course_id)}/assignments"
    # construct returning link
    if url_type=="html":
        link = f'<a href="{url}">{resource_title}</a>'
    elif url_type=="anchor":
        link = f'<a href="{url}">{resource_title}</a>'
    elif url_type=="md":
        link = f'[{resource_title}]({url})'
    elif url_type=="img":
        link = f"""<img id="{item['id']}" src="{item['src']}" alt="{item['alt']}" data-api-endpoint="{item['data-api-endpoint']}" data-api-returntype="{item['data-api-returntype']}" {kwargs_to_string( **kwargs )} />
    """
    else:
        link = f'[{resource_title}]({url})'
    return link

def expand_assignment( resource,title, url, **kwargs ):
    """ expand assignment to url """
    return expand_resource( resource, title, url, source_type="assignment", **kwargs)

def expand_page( resource,title, url, **kwargs ):
    return expand_resource( resource, title, url, source_type="page", **kwargs )

def expand_quiz( resource, title, url, **kwargs ):
    return expand_resource( resource, title, url, source_type="quiz", **kwargs )

def expand_file( resource, title, url, **kwargs ):
    return expand_resource( resource, title, url, source_type="file", **kwargs )

