""" docstring for cmd_template
"""
import os
import re
import json
import click

from loguru import logger
import markdown
import pandas as pd

from cnvsapi.utils import as_pretty_json,clean_include_lists
from cnvsapi.config import config, DEFAULT_LOG_LEVEL,ENV_TOKEN_NAME
from cnvsapi.build_utils import copy_google_sheet, build_lecture_files_from_outline, build_lecture_headers_from_outline, \
    build_canvas_modules_from_outline, build_canvas_events_from_outline, build_canvas_frontpages_from_modules, \
    copy_lecture_template_files, sync_syllabus_to_config, freshen_overview_pages, freshen_resources, \
    sync_canvas_roster_from_source, freshen_quizzes_from_outline, freshen_homeworks_from_outline, \
    freshen_lectures_from_outline, freshen_canvas_lectures_summary_page, freshen_projects_from_outline


@click.group(invoke_without_command=True)
@click.pass_context
def cli(ctx):
    """ Freshen canvas objects from an outline.

    Assumes that objects are already created using `build`
    
    """    
    if ctx.invoked_subcommand is None:
        course = config.get_default_course()
        print(f"Default course id: {config.course_id} / {course["sis_course_id"]}")
        click.echo(ctx.get_help())


@cli.command()
@click.pass_context
@click.option("--all",help="Freshen all YAML lecture headers",default=False, is_flag=True )
@click.option("--include-lectures",type=str,help="List of lectures to include",default=None )
@click.option("--exclude-lectures",type=str,help="List of lectures to exclude",default=None )
def lecture_headers_from_outline(ctx,all,include_lectures,exclude_lectures):
    """ Freshen YAML headers for existing lecture files
    
       qmd files using data from google outline
       
    """
    all,include_list,exclude_list = clean_include_lists( all, include_lectures, exclude_lectures )

    if (not all) and (include_list is None) and (exclude_list is None):
        click.echo(ctx.get_help())
    else:
        build_lecture_headers_from_outline(include_lectures=include_list,exclude_lectures=exclude_list)

@cli.command()
@click.option("--all",help="Build for all weeks",default=False, is_flag=True )
@click.option("--include-weeks",type=str,help="List of week numbers to include in build",default=None )
@click.option("--exclude-weeks",type=str,help="List of week numbers to exclude from build",default=None )
@click.pass_context
def canvas_overviews_from_outline(ctx, all, include_weeks, exclude_weeks):
    """ Freshen overview pages using Overview tab
    
    You should consider freshening frontpages after this!
    
    """

    all,include_list,exclude_list = clean_include_lists( all, include_weeks, exclude_weeks )

    if (not all) and (include_list is None) and (exclude_list is None):
        click.echo(ctx.get_help())
    else:
        freshen_overview_pages( include_weeks=include_list,exclude_weeks=exclude_list )

@cli.command()
@click.option("--all",help="Build for all weeks",default=False, is_flag=True )
@click.option("--include-weeks",type=str,help="List of week numbers to include in build",default=None )
@click.option("--exclude-weeks",type=str,help="List of week numbers to exclude from build",default=None )
@click.pass_context
def canvas_resources_from_outline(ctx, all, include_weeks, exclude_weeks):
    """ Freshen module resources using Resources tab in outline
    
    You should consider freshening frontpages after this!
    
    """
    all,include_list,exclude_list = clean_include_lists( all, include_weeks, exclude_weeks )
    if (not all) and (include_list is None) and (exclude_list is None):
        click.echo(ctx.get_help())
    else:
        freshen_resources( include_weeks=include_list,exclude_weeks=exclude_list )

@cli.command()
@click.option("--all",help="Build for all weeks",default=False, is_flag=True )
@click.option("--include-weeks",type=str,help="List of week numbers to include in build",default=None )
@click.option("--exclude-weeks",type=str,help="List of week numbers to exclude from build",default=None )
@click.pass_context
def canvas_quizzes_from_outline(ctx, all, include_weeks, exclude_weeks):
    """ Freshen canvas quizzes using titles and dates from outline
    
    You should consider freshening frontpages after this!
    
    """
    all,include_list,exclude_list = clean_include_lists( all, include_weeks, exclude_weeks )

    if (not all) and (include_list is None) and (exclude_list is None):
        click.echo(ctx.get_help())
    else:
        freshen_quizzes_from_outline( include_weeks=include_list,exclude_weeks=exclude_list )


@cli.command()
@click.option("--all",help="Build for all weeks",default=False, is_flag=True )
@click.option("--include-weeks",type=str,help="List of week numbers to include in build",default=None )
@click.option("--exclude-weeks",type=str,help="List of week numbers to exclude from build",default=None )
@click.pass_context
def canvas_homeworks_from_outline(ctx, all, include_weeks, exclude_weeks):
    """ Freshen homeworks (not quizzes or projects) using titles, dates, and docs from outline
    
    You should consider freshening frontpages after this!
    
    """
    all,include_list,exclude_list = clean_include_lists( all, include_weeks, exclude_weeks )

    if (not all) and (include_list is None) and (exclude_list is None):
        click.echo(ctx.get_help())
    else:
        freshen_homeworks_from_outline( include_weeks=include_list,exclude_weeks=exclude_list )

@cli.command()
@click.option("--all",help="Build for all weeks",default=False, is_flag=True )
@click.option("--include-weeks",type=str,help="List of week numbers to include in build",default=None )
@click.option("--exclude-weeks",type=str,help="List of week numbers to exclude from build",default=None )
@click.pass_context
def canvas_projects_from_outline(ctx, all, include_weeks, exclude_weeks):
    """ Freshen canvas projects using titles, dates, and docs from outline
    
    You should consider freshening frontpages after this!
    
    """
    all,include_list,exclude_list = clean_include_lists( all, include_weeks, exclude_weeks )

    if (not all) and (include_list is None) and (exclude_list is None):
        click.echo(ctx.get_help())
    else:
        freshen_projects_from_outline( include_weeks=include_list,exclude_weeks=exclude_list )



@cli.command()
@click.option("--as-front-page",help="True to set syllabus as frontpage",is_flag=True, default=False)
@click.pass_context
def canvas_syllabus_from_gdoc( ctx, as_front_page ):
    """ Connect canvas syllabus to google doc """
    sync_syllabus_to_config( as_front_page )


@cli.command()
@click.option("--all",help="Build frontpages for all canvas modules",default=False, is_flag=True )
@click.option("--include-weeks",type=str,help="List of week numbers to include in build",default=None )
@click.option("--exclude-weeks",type=str,help="List of week numbers to exclude from build",default=None )
@click.option("--additional-weeks-to-show",type=int,help="Weeks to show beyond current week",default=None)
@click.option("--set-current-week",type=str,help="Override lookup of current week",default=None )
@click.pass_context
def canvas_frontpages_from_modules(ctx,all,include_weeks, exclude_weeks, additional_weeks_to_show, set_current_week):
    """ Creates frontpages from canvas modules.
    
    Assumes format created by canvas_modules_from_outline
    """
    all,include_list,exclude_list = clean_include_lists( all, include_weeks, exclude_weeks )

    if (not all) and (include_list is None) and (exclude_list is None):
        click.echo(ctx.get_help())
    else:
        build_canvas_frontpages_from_modules(include_weeks=include_list,exclude_weeks=exclude_list, additional_weeks_to_show=additional_weeks_to_show, set_current_week=set_current_week )

@cli.command()
@click.option("--all",help="Build frontpages for all canvas modules",default=False, is_flag=True )
@click.option("--include-weeks",type=str,help="List of week numbers to include in build",default=None )
@click.option("--exclude-weeks",type=str,help="List of week numbers to exclude from build",default=None )
@click.pass_context
def canvas_lectures_from_outline(ctx,all,include_weeks, exclude_weeks ):
    """ Freshens canvas lectures from outline
    """
    all,include_list,exclude_list = clean_include_lists( all, include_weeks, exclude_weeks )

    if (not all) and (include_list is None) and (exclude_list is None):
        click.echo(ctx.get_help())
    else:
        freshen_lectures_from_outline(include_weeks=include_list,exclude_weeks=exclude_list )

@cli.command()
@click.pass_context
def canvas_roster_from_source( ctx ):
    """ Freshen canvas page to contain roster headshots """
    sync_canvas_roster_from_source()


@cli.command()
@click.pass_context
def canvas_lectures_summary_page( ctx ):
    """ Freshen canvas page to contains summary of lecture urls """
    freshen_canvas_lectures_summary_page()


@cli.command()
@click.option("--all",help="Build frontpages for all canvas modules",default=False, is_flag=True )
@click.option("--include-weeks",type=str,help="List of week numbers to include in build",default=None )
@click.option("--exclude-weeks",type=str,help="List of week numbers to exclude from build",default=None )
@click.option("--additional-weeks-to-show",type=int,help="Weeks to show beyond current week",default=3 )
@click.option("--set-current-week",type=str,help="Override lookup of current week",default=None )
@click.pass_context
def all_canvas_items(ctx,all,include_weeks, exclude_weeks, additional_weeks_to_show, set_current_week):
    """ Freshens canvas items.  See help for more.
    
    Freshens syllabus, overview, resources, quizzes, assignments, and rebuilds front pages.
    """
    all,include_list,exclude_list = clean_include_lists( all, include_weeks, exclude_weeks )

    if (not all) and (include_list is None) and (exclude_list is None):
        click.echo(ctx.get_help())
    else:
        sync_syllabus_to_config( True )
        sync_canvas_roster_from_source()
        freshen_canvas_lectures_summary_page()
                
        freshen_overview_pages( include_weeks=include_list,exclude_weeks=exclude_list )
        freshen_resources( include_weeks=include_list,exclude_weeks=exclude_list )
        freshen_quizzes_from_outline( include_weeks=include_list,exclude_weeks=exclude_list )
        freshen_assignments_from_outline( include_weeks=include_list,exclude_weeks=exclude_list )
        freshen_projects_from_outline( include_weeks=include_list,exclude_weeks=exclude_list )
        freshen_lectures_from_outline( include_weeks=include_list,exclude_weeks=exclude_list )
        build_canvas_frontpages_from_modules(include_weeks=include_list,exclude_weeks=exclude_list, additional_weeks_to_show=additional_weeks_to_show, set_current_week=set_current_week )

if __name__ == '__main__':
    cli(obj={})


