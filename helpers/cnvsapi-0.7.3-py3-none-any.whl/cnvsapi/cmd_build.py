""" docstring for cmd_build
"""
import os
import re
import sys
import json
import click

from loguru import logger
import markdown
import pandas as pd

from cnvsapi.utils import as_pretty_json, clean_include_lists
from cnvsapi.config import config, DEFAULT_LOG_LEVEL,ENV_TOKEN_NAME
from cnvsapi.build_utils import copy_google_sheet, build_lecture_files_from_outline, build_lecture_headers_from_outline, \
    build_canvas_modules_from_outline, build_canvas_events_from_outline, build_canvas_frontpages_from_modules, \
    copy_lecture_template_files, sync_syllabus_to_config, freshen_overview_pages, freshen_resources, \
    sync_canvas_roster_from_source,freshen_canvas_lectures_summary_page
from cnvsapi.quiz_utils import test


@click.group(invoke_without_command=True)
@click.option("--course-id",help="Display details for this outcome ID",default=None,type=int)
@click.option("--courses",help="Display courses and ids",is_flag=True, default=False)
@click.pass_context
def cli(ctx,course_id,courses):
    """ Build canvas objects from an outline.

    The build command provide utilities for directly modifying Canvas objects and creating
    custom Canvas pages.

    CNVSAPI depends on a specifically formatted google sheet, called an OUTLINE to store content
    that is used manipulate a canvas course, and local lecture files.

    Step 1: Create gsheet using 'cnvsapi build outline-from-master'

    Step 2: Modify and amend the outline gsheet as desire. Use 'cnvsapi outline' tools to review.

    """
    if courses:
        crses = config.get_courses()
        comments = ""
        for id in crses.keys():
            line = f"{'' if id==config.course_id else '# '}course_id={id:<8d} #  {crses[id]['name']}"
            print( line )
            comments = comments + "\n" + line
        return
    if not course_id is None:
        ctx.obj["COURSE_ID"] = course_id
        config.course_id = course_id
    
    if ctx.invoked_subcommand is None:
        course = config.get_default_course()
        print(f"Default course id: {config.course_id} / {course["sis_course_id"]}")
        print(f"Default plugin folder: {config.plugin_folder}")
        print(f"Default QMD template is: {config.config['roster']['default_qmd_template']}")
        click.echo(ctx.get_help())


@cli.command()
@click.option("--overwrite",help="Overwrite destination file",default=False, is_flag=True )
@click.pass_context
def rubric(ctx,overwrite):
    """ Testing - creating rubrics on the fly """    
#    rubric = config.get_default_course_endpoint().get_rubric(121219).delete()
    x = config.create_rubric("rubric 1")
    rubric = config.get_default_course_endpoint().get_rubric( 121220 )
    rubric


@cli.command()
@click.option("--folder-id",help="Google folder ID to receive copy of original sheet",default=None )
@click.option("--original-id",help="GSheet ID of original gsheet to be copied",default="1cp9-7bAWZtcCDUfXEY5eD1Bg5SejFI-dqCjG0Mj1rXE")
@click.option("--confirm",help="Execute copy operation",default=False,is_flag=True)
@click.pass_context
def outline_from_master(ctx,folder_id,original_id,confirm):
    """ Copy outline gsheet from original ghsheet
    """

    if (folder_id is None) or (original_id is None or (not confirm)):
        click.echo(ctx.get_help())
        click.echo("\n")
        sheet_meta_data = copy_google_sheet(original_id, folder_id, False )

        click.echo(f"folder_id: {folder_id}")
        click.echo(f"original_id: {original_id}")
        click.echo(f"Use --confirm to execute the copy operation")
        sys.exit()

    if confirm:
        sheet_meta_data = copy_google_sheet(original_id, folder_id, confirm )
        if not sheet_meta_data is None:
            click.echo(f"Outline sheet created.")
            for key in ['name','webViewLink']:
                click.echo( f"{key}: {sheet_meta_data[key]}" )
        else:
            click.echo(f"Outline not created")
    else:
        click.echo(f"Use --confirm to make copy")


@cli.command()
@click.pass_context
@click.option("--all",help="Create all missing lecture files",default=False, is_flag=True )
@click.option("--include-lectures",type=str,help="List of lectures to include",default=None )
@click.option("--exclude-lectures",type=str,help="List of lectures to exclude",default=None )
def lecture_files_from_outline(ctx,all,include_lectures,exclude_lectures):
    """ Build missing lecture slides and update all YAML headers
    
       qmd files using data from google outline
       
    """
    all,include_list,exclude_list = clean_include_lists( all, include_lectures, exclude_lectures )

    if (not all) and (include_list is None) and (exclude_list is None):
        click.echo(ctx.get_help())
    else:
        build_lecture_files_from_outline(include_lectures=include_list,exclude_lectures=exclude_list)


@cli.command()
@click.pass_context
@click.option("--all",help="Build calendar events for all lectures",default=False, is_flag=True )
@click.option("--include-weeks",type=str,help="List of week numbers to include in build",default=None )
@click.option("--exclude-weeks",type=str,help="List of week numbers to exclude from build",default=None )
def canvas_events_from_outline(ctx,all,include_weeks,exclude_weeks):
    """ Build calendar events for course meetings using data from google outline """

    all,include_list,exclude_list = clean_include_lists( all, include_weeks, exclude_weeks )

    if (not all) and (include_list is None) and (exclude_list is None):
        click.echo(ctx.get_help())
    else:
        build_canvas_events_from_outline(include_weeks=include_list,exclude_weeks=exclude_list)


@cli.command()
@click.option("--all",help="Build modules for all weeks in calendar",default=False, is_flag=True )
@click.option("--include-weeks",type=str,help="List of week numbers to include in build",default=None )
@click.option("--exclude-weeks",type=str,help="List of week numbers to exclude from build",default=None )
@click.pass_context
def canvas_modules_from_outline(ctx,all,include_weeks, exclude_weeks):
    """ Create canvas modules from outline.  Adds quizzes, homeworks and lectures """

    all,include_list,exclude_list = clean_include_lists( all, include_weeks, exclude_weeks )

    if (not all) and (include_list is None) and (exclude_list is None):
        click.echo(ctx.get_help())
    else:
        build_canvas_modules_from_outline(include_weeks=include_list,exclude_weeks=exclude_list)


@cli.command()
@click.option("--all",help="Build frontpages for all canvas modules",default=False, is_flag=True )
@click.option("--include-weeks",type=str,help="List of week numbers to include in build",default=None )
@click.option("--exclude-weeks",type=str,help="List of week numbers to exclude from build",default=None )
@click.option("--additional-weeks-to-show",type=int,help="Weeks to show beyond current week",default=None )
@click.option("--set-current-week",type=str,help="Override lookup of current week",default=None )
@click.pass_context
def canvas_frontpages_from_modules(ctx,all,include_weeks, exclude_weeks, additional_weeks_to_show, set_current_week):
    """ Creates frontpages from canvas modules.
    
    Assumes format created by canvas_modules_from_outline
    """
    all,include_list,exclude_list = clean_include_lists( all, include_weeks, exclude_weeks )

    if (not all) and (include_list is None) and (exclude_list is None):
        click.echo(ctx.get_help())
    else:
        build_canvas_frontpages_from_modules(include_weeks=include_list,exclude_weeks=exclude_list, additional_weeks_to_show=additional_weeks_to_show, set_current_week=set_current_week )


@cli.command()
@click.option("--overwrite",help="Overwrite existing template files",default=False, is_flag=True )
@click.pass_context
def lecture_templates_from_source( ctx,overwrite ):
    """ Copy default lecture template files to current folder
    
    See [lecture] key for current default
    """
    copy_lecture_template_files( overwrite )


@cli.command()
@click.option("--as-front-page",help="True to set syllabus as frontpage",is_flag=True, default=True)
@click.pass_context
def canvas_syllabus_from_gdoc( ctx, as_front_page ):
    """ Connect canvas syllabus to google doc """
    sync_syllabus_to_config( as_front_page )


@cli.command()
@click.option("--all",help="Build for all weeks",default=False, is_flag=True )
@click.option("--include-weeks",type=str,help="List of week numbers to include in build",default=None )
@click.option("--exclude-weeks",type=str,help="List of week numbers to exclude from build",default=None )
@click.pass_context
def all_canvas_items(ctx, all, include_weeks, exclude_weeks):
    """ Modules, pages, events, frontpages, syllabus.
    
    Does not create lecture slides.
    
    """
    all,include_list,exclude_list = clean_include_lists( all, include_weeks, exclude_weeks )

    if (not all) and (include_list is None) and (exclude_list is None):
        click.echo(ctx.get_help())
    else:
        build_canvas_events_from_outline( include_weeks=include_list,exclude_weeks=exclude_list )
        build_canvas_modules_from_outline( include_weeks=include_list,exclude_weeks=exclude_list )
        freshen_overview_pages( include_weeks=include_list,exclude_weeks=exclude_list )
        freshen_resources( include_weeks=include_list,exclude_weeks=exclude_list )
        sync_syllabus_to_config( True )
        sync_canvas_roster_from_source()
        freshen_canvas_lectures_summary_page()
        build_canvas_frontpages_from_modules( include_weeks=include_list,exclude_weeks=exclude_list )


@cli.command()
@click.pass_context
def canvas_roster_from_source( ctx ):
    """ Create canvas page to contain roster headshots """
    sync_canvas_roster_from_source()


if __name__ == '__main__':
    cli(obj={})
