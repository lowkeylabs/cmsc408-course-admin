"""

"""

import os
import frontmatter

def clean_resource_title( s ):
    """ remove leading resource-related stuff from title """
    # Split the string on the last occurrence of '-'
    if '-' in s:
        return s.rsplit('-', 1)[-1].strip()
    return s  # Return the original string if no dash is present

def grab_frontmatter( filename ):
    """ load frontmatter from a file """
    current_file = os.path.abspath( filename )
    # Open and load the frontmatter from the current file
    with open(current_file, 'r') as f:
        post = frontmatter.load(f)
    return post

def dp_banner2( title, clean=True ):
    # returns a design-plus banner2 given a title.
    s = title
    if clean:
        s = clean_resource_title( title )
    return f"""<header class="dp-header cp-bg-dp-primary cp-out-dp-secondary dp-header-wrap-brdr-w-4 dp-header-title-txt-mc dp-header-sub-bg-dp-white dp-header-sub-brdr-w-1 dp-shadow-r2 dp-border-dir-none dp-padding-direction-all dp-header-pre-bg-dp-primary dp-header-pre-pos-x-c dp-header-pre-pos-y-top dp-header-pre-out-dp-secondary dp-header-pre-font-sm dp-header-pre-txt-mc dp-header-pre-s-brdr-b dp-header-wrap-s-brdr-b dp-header-pre-brdr-w-1 dp-header-out-dp-primary dp-header-s-rect dp-header-brdr-w-2">
        <h2 class="dp-heading"><span class="dp-header-title">{s}</span></h2>
    </header>
    """

def dp_banner2_from_qmd( filename ):
    """ return designplus banner 2 """
    yaml = grab_frontmatter( filename )
    title = yaml['title']
    return dp_banner2( title )


def dp_iframe_youtube( title, youtube_link ):
    """ return a design-plus formatted iframe for a youtube link and title """
    iframe_style = "mx-auto d-block" # center from dp style screen
    iframe_style = ""

    title = clean_resource_title( title )
    return f"""<div class="dp-embed-wrapper {iframe_style}">
<iframe
  class="lti-embed"
  style="width: 640px; height: 480px;"
  title="{title}"
  src="https://www.youtube-nocookie.com/embed/{youtube_link}?feature=oembed&amp;rel=0"
  width="640" height="480"
  allowfullscreen="allowfullscreen" webkitallowfullscreen="webkitallowfullscreen" mozallowfullscreen="mozallowfullscreen"
  allow="geolocation *; microphone *; camera *; midi *; encrypted-media *; autoplay *; clipboard-write *; display-capture *">
</iframe>
</div>
"""
 
def dp_iframe_youtube_from_qmd( filename, youtube_link ):
    """ grab the iframe title from the qmd file then call other routine. """
    yaml = grab_frontmatter( filename )

    iframe_style = "mx-auto d-block" # center from dp style screen
    iframe_style = ""
    title = yaml['title']
    return dp_iframe_youtube( title, youtube_link )
