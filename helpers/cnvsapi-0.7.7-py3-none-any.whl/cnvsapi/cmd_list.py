""" docstring for cmd_explore
"""
import os
import re
import sys
import json
import click

from loguru import logger
import markdown
import pandas as pd

from cnvsapi.utils import as_pretty_json, parse_cli_list
from cnvsapi.config import config, DEFAULT_LOG_LEVEL,ENV_TOKEN_NAME, config_file_name


@click.group(invoke_without_command=True)
@click.option("--course-id",help="Display details for this course ID",default=None,type=int)
@click.option("--courses",help="Display course ID for selection", is_flag=True, default=False )
@click.pass_context
def cli(ctx,course_id,courses):
    """ List canvas objects, courses and endpoints.

    Useful for discovering whats inside a course.
    
    """
    if courses:
        courses = config.get_courses()
        for id in courses.keys():
            line = f"{'' if id==config.course_id else '# '}course_id={id:<8d} #  {courses[id]['name']}"
            click.echo( line )

    if not course_id is None:
        ctx.obj["COURSE_ID"] = course_id
        config.course_id = course_id

    if ctx.invoked_subcommand is None:
        if not courses:
            click.echo( ctx.get_help() )
        click.echo(f"\nDefault course id: {config.course_id}")

@cli.command()
@click.option("--course-id",help="Display details for this course ID",default=None,type=int)
@click.option("--as-json",help="Display as json",required=False,is_flag=True,default=False )
@click.option("--fields",callback=parse_cli_list,help="Fields to display",type=str, required=False, default=['id','name','workflow_state','concluded',{'term':['name']} ] )
@click.pass_context
def course( ctx, course_id, as_json, fields ):
    """ List course attributes
    """
    id = config.course_id 
    if not course_id is None:
        id = course_id

    if not id is None:
        courses = config.get_courses()
        logger.success( config.display_object( courses, id=id, as_json=as_json, elements=fields, oneline=True ) )
    else:
        logger.warning(f"Missing course id.  Use --id or set default course in {config.config_file_name}")

@cli.command()
@click.option("--course-id",help="Display details for this course ID",default=None,type=int)
@click.option("--as-json",help="Display as json",required=False,is_flag=True,default=False )
@click.option("--fields",callback=parse_cli_list,help="Fields to display",type=str, required=False, default=['id','name','workflow_state','concluded',{'term':['name']} ] )
@click.option("--include",type=str,help="List of filter strings to include in final list.")
@click.option("--exclude",type=str,help="List of filter strings to exclude from final list.")
@click.option("--save",help="Save configuration to current folder using course_id.", is_flag=True, default=False )
@click.option("--add-to-config",help="Add available courses to config file",default=False,is_flag=True,show_default=True )
@click.pass_context
def courses( ctx, course_id, as_json, fields, include, exclude, save, add_to_config ):
    """ List available courses for current user.

    The list displays the nickname (as set on the Dashboard) otherwise it shows the full canvas name.

    When renaming courses, take care to include the 

    Current user and courses is set by token.  See: cnvsapi token

    """
    id = config.course_id 
    if not course_id is None:
        id = course_id
        if include is None:
            include = str(id)
        else:
            include = include + "," + id
        if save:
            logger.success(f"Saving configuration to: {config_file_name}")
            config.course_id=id
            config.save()
            sys.exit(0)

    logger.debug(f"course id: {id}")

    courses = config.get_courses()
    if not add_to_config:
        logger.success( config.display_object( courses, id=None, as_json=as_json, elements=fields, include=include, exclude=exclude, oneline=True ) )
    else:
        logger.debug(config.config.keys())
        config.save()
        config.reload()
        if not "user_courses" in config.config.keys():
            config.config["user_courses"] = {}
        for key in courses.keys():
            config.config["user_courses"][str(key)] = courses[key]['name']
        config.save()
        #logger.success(f".cnvsapi -> Edit config file and uncomment the desired course")


@cli.command()
@click.option("--id",help="User id to display",required=False,default=None,type=int)
@click.option("--as-json",help="Display as json",required=False,is_flag=True,default=False )
@click.option("--fields",callback=parse_cli_list,help="Fields to display",type=str, required=False, default=['id','name'] )
@click.pass_context
def users( ctx, id, as_json, fields ):
    """ List users for a course
    """
    users = config.get_users()
    print( config.display_object( users, id=id, as_json=as_json, elements=fields ) )


@cli.command()
@click.option("--id",help="Assignment group id to display",required=False,default=None,type=int)
@click.option("--as-json",help="Display as json",required=False,is_flag=True,default=False )
@click.option("--fields",callback=parse_cli_list,help="Fields to display",type=str, required=False, default=['id','name','group_weight'] )
@click.pass_context
def assignment_groups( ctx,id,as_json,fields ):
    """ List assignment groups for a course
    """
    assignment_groups = config.get_assignment_groups()
    print( config.display_object( assignment_groups, id=id, as_json=as_json, elements=fields ) )

@cli.command()
@click.option("--id",help="Assignment id to display",required=False,default=None,type=int)
@click.option("--as-json",help="Display as json",required=False,is_flag=True,default=False )
@click.option("--fields",callback=parse_cli_list,help="Fields to display",type=str, required=False, default=['id','name','group_weight',{'assignments':['id','name','points_possible']}] )
@click.pass_context
def assignments( ctx,id,as_json,fields ):
    """ List assignment groups for a course
    """
    items = config.get_assignments()
    print( config.display_object( items, id=id, as_json=as_json, elements=fields ) )


@cli.command()
@click.option("--id",help="Quiz id to display",required=False,default=None,type=int)
@click.option("--as-json",help="Display as json",required=False,is_flag=True,default=False )
@click.option("--fields",callback=parse_cli_list,help="Fields to display",type=str, required=False, default=['assignment_group_id','id','title',{'all_dates':['due_at']}] )
@click.pass_context
def quizzes( ctx,id,as_json,fields ):
    """ List quizzes for a course
    """
    items = config.get_quizzes()
    print( config.display_object( items, id=id, as_json=as_json, elements=fields,oneline=True ) )


@cli.command()
@click.option("--id",help="Module id to display",required=False,default=None,type=int)
@click.option("--as-json",help="Display as json",required=False,is_flag=True,default=False )
@click.option("--fields",callback=parse_cli_list,help="Fields to display",type=str, required=False, default=['id','name'] )
@click.pass_context
def modules( ctx,id,as_json,fields ):
    """ List modules for a course
    """
    items = config.get_modules()
    print( config.display_object( items, id=id, as_json=as_json, elements=fields ) )


@cli.command()
@click.option("--id",help="id to display",required=False,default=None,type=int)
@click.option("--as-json",help="Display as json",required=False,is_flag=True,default=False )
@click.option("--fields",callback=parse_cli_list,help="Fields to display",type=str, required=False, default=['id','role',{'user':['id','name','login_id','pronouns']}] )
@click.pass_context
def enrollments( ctx,id, as_json, fields ):
    """ List enrollments for a course
    """
    items = config.get_enrollments()
    print( config.display_object( items, id=id, as_json=as_json, elements=fields ) )


@cli.command()
@click.option("--id",help="id to display",required=False,default=None,type=int)
@click.option("--as-json",help="Display as json",required=False,is_flag=True,default=False )
@click.option("--fields",callback=parse_cli_list,help="Fields to display",type=str, required=False, default=['id','title',{'data':['description','points']}] )
@click.pass_context
def rubrics( ctx, id, as_json,fields ):
    """ List rubrics for a course
    """
    items = config.get_rubrics()
    print( config.display_object( items, id=id, as_json=as_json, elements=fields ) )


@cli.command()
@click.option("--id",help="id to display",required=False,default=None)
@click.option("--as-json",help="Display as json",required=False,is_flag=True,default=False )
@click.option("--fields",callback=parse_cli_list,help="Fields to display",type=str, required=False, default=['url','title','published'] )
@click.option("--include",type=str,help="List of filter strings to include in final list.")
@click.option("--exclude",type=str,help="List of filter strings to exclude from final list.")
@click.pass_context
def pages( ctx, id, as_json, fields, include, exclude ):
    """ List pages for a course
    """
    items = config.get_pages()
    print( config.display_object( items, id=id, as_json=as_json, elements=fields, include=include, exclude=exclude ) )


@cli.command()
@click.option("--id",help="id to display",required=False,default=None,type=int)
@click.option("--as-json",help="Display as json",required=False,is_flag=True,default=False )
@click.option("--fields",callback=parse_cli_list,help="Fields to display",type=str, required=False, default=['id','name',{'module_items':['id','title']}] )
@click.pass_context
def module_items( ctx,id, as_json, fields ):
    """ List modules and module items for a course
    """
    items = config.get_module_items()
    print( config.display_object( items, id=id, as_json=as_json, elements=fields ) )



@cli.command()
@click.option("--id",help="id to display",required=False,default=None,type=int)
@click.option("--as-json",help="Display as json",required=False,is_flag=True,default=False )
@click.option("--fields",callback=parse_cli_list,help="Fields to display",type=str, required=False, default=['id','name'] )
@click.pass_context
def groups( ctx,id,as_json,fields ):
    """ List groups for a course
    """
    items  = config.get_groups()
    print( config.display_object( items, id=id, as_json=as_json, elements=fields ) )


@cli.command()
@click.argument('command_name', type=str,default='list' )
@click.pass_context
def canvas_endpoint( ctx,command_name ):
    """ Explore endpoints on canvas object
    """
    if command_name=='list':
        print( as_pretty_json( config.get_callable_canvas_objects() ))
    else:
        print( as_pretty_json( config.get_canvas_object_by_name( command_name )))


@cli.command()
@click.argument('command_name', type=str,default='list' )
@click.pass_context
def course_endpoint( ctx,command_name ):
    """ Explore endpoints on the default course object
    """
    if command_name=='list':
        print( as_pretty_json( config.get_callable_course_objects() ))
    else:
        print( as_pretty_json( config.get_course_object_by_name( command_name )))


@cli.command()
@click.option("--id",help="id to display",required=False,default=None,type=int)
@click.option("--as-json",help="Display as json",required=False,is_flag=True,default=False )
@click.option("--fields",callback=parse_cli_list,help="Fields to display",type=str, required=False, default=['id','title','start_at_date','end_at_date'] )
@click.pass_context
def calendar_events( ctx, id, as_json, fields):
    """ Explore endpoints on the default course object
    """
    items = config.get_calendar_events( type="event", all_events=True, context_codes=["course_"+str(config.course_id)] ) 
    print(config.display_object( items, id=id, as_json=as_json, elements=fields ))


if __name__ == '__main__':
    cli(obj={})


