"""
Outline utilities for present lists based on outline data
"""

import textwrap
from loguru import logger
from tabulate import tabulate
from datetime import datetime
from zoneinfo import ZoneInfo
import pandas as pd

from cnvsapi.config import config


from cnvsapi.utils import order_weeks_by_week, local_time_difference, find_quiz_in_quizzes, as_pretty_json, \
                            get_title, find_page_in_pages, find_assignment_in_assignments, get_day_of_week, \
                            normalize_date, parse_markdown_link, write_lectures_to_csv, convert_to_localtime, \
                            get_2_digit_date, save_topics_to_xlsx
from cnvsapi.build_utils import extract_outline, get_outline_objects, extract_overviews, \
                        get_list_of_local_lecture_files, get_lecture_yaml_header

def outline_instructor_checklist( include_weeks=None,exclude_weeks=None,only_not_ok=False,within_days=1000 ):
    """ returns an instructor checklist for desired weeks """

    logger.debug(f"Including weeks: {include_weeks}")
    logger.debug(f"Excluding weeks: {exclude_weeks}")

    outline_df = extract_outline()
    weeks_list = order_weeks_by_week( outline_df, prefix=['instructor','welcome'],include_weeks=include_weeks, exclude_weeks=exclude_weeks )
    logger.debug( weeks_list )

    combined_df = get_outline_objects()
    combined_df = combined_df.sort_values(by='canvas_unlock_at', ascending=True)
    logger.trace( combined_df )


    canvas_quizzes = config.get_quizzes()
    canvas_pages = config.get_pages()
#    canvas_assignments = config.get_assignments()
    canvas_assignments = config.get_assignment_groups(include=['assignments']) # from Canvas


    results = []
    for id,row in combined_df.iterrows():

        if not row['week_id'] in weeks_list:
            continue
        if row['source_tab'] in ['resources']:
            continue

        diff = local_time_difference( row['canvas_unlock_at'] )
        try:
            timediff = float(diff)
        except:
            timediff = 0.0
        outline_entry = row['outline_entry']
        status = ['(not calculated)']

        # process surveys and quizzes
        if row['source_tab'] in ['surveys','quizzes']:
            if not row['google_doc_id']:
                status.append("Missing google_doc_id")
            quiz = find_quiz_in_quizzes( canvas_quizzes,title=row['canvas_title'])
            if not quiz:
                status.append("Quiz not found in canvas")
            else:
                logger.trace( as_pretty_json( quiz ) )
                if not quiz['published']:
                    status.append("Not published")
                if not quiz['question_count']>0:
                    status.append("No questions found")

            # Set to OK if nothing was appended.
            if len(status)>1:
                status = status[1:]
            else:
                status = ['Ok']

        # process lectures
        elif row['source_tab'] in ['lectures']:
            try:
                if not int(row['topic_count'])>0:
                    status.append("Add topics to tab")
            except:
                status.append("Add topics to tab")

            if not row['content_url']:
                status.append("Add content_url to lecture tab")

            # Verify lecture is published
            title = get_title("lecture_slide",id=row['id'])
            page = find_page_in_pages( canvas_pages,title=title)
            if not page:
                status.append(f"Create lecture page ({title})")
            else:
                logger.trace( as_pretty_json( page ) )
                if not page['published']:
                    status.append("Publish lecture")

            title = get_title("lecture_video",id=row['id'])
            page = find_page_in_pages( canvas_pages,title=title)
            page = config.get_page( page['url'] )
            if not page:
                status.apend(f"Create video page ({title})")
            else:
                if not page['published']:
                    status.append("Publish video page")
                # message to add kaltura video only appears AFTER lecture has happened.
                if ("external_tools" not in page['body'].lower()) and (timediff<0.0):
                    status.append("Link kaltura video")

            # Last thing to do.  If nothing added, mark it OK.
            if len(status)>1:
                status = status[1:]
            else:
                status = ['Ok']

        # process discussions
        elif row['source_tab'] in ['discussions']:
            if not row['google_doc_id']:
                status.append("Missing google_doc_id")
            title = row['canvas_title']
            assign = find_assignment_in_assignments( canvas_assignments, title=title )
            if not assign:
                status.append(f"Missing assignment ({title})")
            else:
                logger.trace( as_pretty_json( assign ) )
                if not assign['published']:
                    status.append('Not published')
                submission_types = assign.get("submission_types",[])
                if (len(submission_types)>0) and submission_types[0]=="external_tool":
                    external_tool_tag_attributes = assign.get("external_tool_tag_attributes",{})
                    if not external_tool_tag_attributes:
                        status.append('External tool not assigned')
                    else:
                        url = external_tool_tag_attributes.get("url","")
                        if not url:
                            status.append('External tool missing url')
            # Last thing to do.  If nothing added, mark it OK.
            if len(status)>1:
                status = status[1:]
            else:
                status = ['Ok']

        # process overviews
        elif( row['source_tab'] in ['overviews']):
            if not row['overview']:
                status.append("Add overview text")
            if not row['module']:
                status.append("Ass module to overview")

            # Last thing to do.  If nothing added, mark it OK.
            if len(status)>1:
                status = status[1:]
            else:
                status = ['Ok']
    
        # process homeworks and projects
        elif( row['source_tab'] in ['homeworks','projects']):
            if not row['outline_entry']:
                status.append("Missing outline_entry")
            if not row['google_doc_id']:
                status.append("Add google_doc_id")
            if row['canvas_submission_types']:
                if row['canvas_submission_types'].lower()=="external_tool" and not row['has_gradescope_page']:
                    status.append("External tool and not has_gradescope_page")
            if row['has_gradescope_page']:
                if not "https:" in row['has_gradescope_page']:
                    status.append("Add GH classroom URL")

            # check non-gradescope assignment
            title = row['canvas_title']
            assign = find_assignment_in_assignments( canvas_assignments, title=title)
            if not assign:
                status.append(f"Assignment not found ({title})")
            else:
                logger.debug( as_pretty_json( assign ))
                if not assign['published']:
                    status.append("Not published")
                    # verify external tool attached
                submission_types = assign.get("submission_types",[])
                if not ( (len(submission_types)==1) and (submission_types[0]=="online_upload")):
                    status.append("Not online upload")
                allowed_extensions = assign.get("allowed_extensions",[])
                if ("course" in title.lower()) and ("evaluation" in title.lower()):
                    if ("png" in allowed_extensions) or ("jpg" in allowed_extensions):
                        pass
                    else:
                        status.append("Fix upload to JPG or PNG")
                else:
                    if not ( (len(allowed_extensions)==1) and (allowed_extensions[0]=="html")):
                        status.append("Fix upload to HTML only")
                use_rubric_for_grading = assign.get("use_rubric_for_grading", False )
                if not use_rubric_for_grading:
                    status.append("Set use_rubric_for_grading to True")
                rubric = assign.get("rubric",[])
                if not rubric:
                    status.append("Missing or invalid rubric")

            # check gradescope portion of assignment
            if row['has_gradescope_page']:
                title = get_title("gradescope",title=row['canvas_title'])
                assign = find_assignment_in_assignments( canvas_assignments, title=title)
                if not assign:
                    status.append(f"Create GS assignment ({title})")
                else:
                    logger.debug( as_pretty_json( assign ))
                    if not assign['published']:
                        status.append("Publish GS assignment")
                    # verify external tool attached
                    submission_types = assign.get("submission_types",[])
                    if (len(submission_types)==1) and submission_types[0]=="external_tool":
                        external_tool_tag_attributes = assign.get("external_tool_tag_attributes",{})
                        if not external_tool_tag_attributes:
                            status.append('Assign GS external tool')
                        else:
                            url = external_tool_tag_attributes.get("url","")
                            if not url:
                                status.append('Assign GS external tool')
                    else:
                        status.append("Assign GS external")


            # Last thing to do.  If nothing added, mark it OK.
            if len(status)>1:
                status = status[1:]
            else:
                status = ['Ok']

        if not status:
            status.append("Ok")
        if outline_entry:
            outline_entry = outline_entry[:25]

        msg = "; ".join( status )
        if not msg=="Ok":
            msg += "."
        group = ""
        if row['canvas_assignment_group']:
            group = textwrap.fill(row['canvas_assignment_group'],10)

        results.append( [ row['week_id'],outline_entry,diff,row['source_tab'], msg ])

    # Details don't have tabs in outline, so we'll check them here
    # and add any messages to the results list.
    #  week : title : days_until : source : group : message 

    overviews = extract_overviews()
    for week_id in weeks_list:
        title = get_title("details",id=week_id)
        page = find_page_in_pages( canvas_pages, title )
        page = config.get_page( page['url'] )
        overview_row = overviews[ overviews['week_id']==str(week_id)]
        status = []
        if not overview_row.empty:
            diff = local_time_difference( str(overview_row['canvas_unlock_at'].iloc[0]) )
        else:
            diff = 0.0
        if page:
            if "add description to course workbook" in page["body"].lower():
                status.append("Review page body for 'add description'")
        if not status:
            status.append("Ok")
        msg = "; ".join( status )
        if not msg=="Ok":
            msg += "."

        results.append( [week_id,title,diff,"details", msg])


    # sort and format table, then return it.

    headers = ['Week', 'Outline Entry', 'Unlocks\n(days)','Group','Status']
    colalign = ['center', 'left', 'right','left','left']

    if only_not_ok:
        results = [row for row in results if not row[4]=="Ok"]
    results = [row for row in results if float(row[2])<=float(within_days) ]
    results = sorted(results, key=lambda x: float(x[2]))
    for row in results:
        row[4] = textwrap.fill( row[4],width=45 )

    return tabulate(results, headers=headers, tablefmt="pretty",colalign=colalign)


def outline_lecture_map( include_weeks=None,exclude_weeks=None ):
    """ returns a listing of topics and activities by week """

    def get_deliverables_for_week( assignments, week_id ):
        """ pick out deliverables for the week """
        deliverables = []
        for ag_value in assignments.values():
            for as_value in ag_value['assignments'].values():
                if str(week_id)==str(as_value['week_id']):
                    deliverables.append( dict(name=as_value['name'],url=as_value['html_url'] ) )
        return deliverables


    logger.debug(f"Including weeks: {include_weeks}")
    logger.debug(f"Excluding weeks: {exclude_weeks}")

    outline_df = extract_outline()
    weeks_list = order_weeks_by_week( outline_df, prefix=['instructor','welcome'],include_weeks=include_weeks, exclude_weeks=exclude_weeks )
    logger.debug( weeks_list )

    combined_df = get_outline_objects()
    combined_df = combined_df.sort_values(by='canvas_unlock_at', ascending=True)
    logger.trace( combined_df )


    canvas_quizzes = config.get_quizzes()
    canvas_pages = config.get_pages()
#    canvas_assignments = config.get_assignments()
    canvas_assignments = config.get_assignment_groups(include=['assignments']) # from Canvas
    for ag_value in canvas_assignments.values():
        for as_value in ag_value['assignments'].values():
            as_value['week_id'] = get_week_from_outline( outline_df, today=pd.to_datetime( convert_to_localtime(as_value['due_at']) ) )
            logger.debug(f"{as_value['name']} - {as_value['week_id']} - {convert_to_localtime(as_value['due_at'])}")


    results = []
    for id,row in combined_df.iterrows():

        if not row['week_id'] in weeks_list:
            continue
        if row['source_tab'] in ['resources']:
            continue

        diff = local_time_difference( row['canvas_unlock_at'] )
        try:
            timediff = float(diff)
        except:
            timediff = 0.0
        outline_entry = row['outline_entry']
        status = ['(not calculated)']

        if row['source_tab'] in ['lectures']:
            try:
                if not int(row['topic_count'])>0:
                    status.append("Add topics to tab")
            except:
                status.append("Add topics to tab")

            if not row['content_url']:
                status.append("Add content_url to lecture tab")

            # Verify lecture is published
            title = get_title("lecture_slide",id=row['id'])
            page = find_page_in_pages( canvas_pages,title=title)
            if not page:
                status.append(f"Create lecture page ({title})")
            else:
                logger.trace( as_pretty_json( page ) )
                if not page['published']:
                    status.append("Publish lecture")

            title = get_title("lecture_video",id=row['id'])
            page = find_page_in_pages( canvas_pages,title=title)
            page = config.get_page( page['url'] )
            if not page:
                status.apend(f"Create video page ({title})")
            else:
                if not page['published']:
                    status.append("Publish video page")
                # message to add kaltura video only appears AFTER lecture has happened.
                if ("external_tools" not in page['body'].lower()) and (timediff<0.0):
                    status.append("Link kaltura video")

            # Last thing to do.  If nothing added, mark it OK.
            if len(status)>1:
                status = status[1:]
            else:
                status = ['Ok']

    # sort and format table, then return it.

    headers = ['Week', 'Outline Entry', 'Unlocks\n(days)','Group','Status']
    colalign = ['center', 'left', 'right','left','left']

#    if only_not_ok:
#        results = [row for row in results if not row[4]=="Ok"]

    results = sorted(results, key=lambda x: float(x[2]))
    for row in results:
        row[4] = textwrap.fill( row[4],width=45 )

    return tabulate(results, headers=headers, tablefmt="pretty",colalign=colalign)


def get_deliverables_by_week( outline_df ):
    """ return a list of deliverables """
    
    def get_week_from_outline( outline_df, today=None ):
        """ given a outline dataframe determine the current week of the semester """
        if today:
            today_date = datetime.date( today )
        else:
            today_date = datetime.date(datetime.datetime.now())
        today_row = outline_df[outline_df['DateCanvas'].dt.date == today_date]
        if today_row.size==0:
            wk = 0
        else:
            try:
                wk = int(today_row["week_id"].iloc[0])
            except:
                wk = 0
        return wk

    def get_deliverables_for_week( assignments, week_id ):
        """ pick out deliverables for the week """
        deliverables = []
        for ag_value in assignments.values():
            for as_value in ag_value['assignments'].values():
                if str(week_id)==str(as_value['week_id']):
                    deliverables.append( dict(name=as_value['name'],url=as_value['html_url'] ) )
        return deliverables

    # get assignments from Canvas and add a week_id to each assignment based on when assignment is due.
    # Canvas tracks time by UTC, so adjust to local time, otherwise assignments due Sunday night bump to next week
    assignments = config.get_assignments()
    all_weeks = {}
    for ag_value in assignments.values():
        for as_value in ag_value['assignments'].values():
            as_value['week_id'] = get_week_from_outline( outline_df, today=pd.to_datetime( convert_to_localtime(as_value['due_at']) ) )
            all_weeks.setdefault( str(as_value['week_id']),[])
            all_weeks[ str(as_value['week_id'])].append( as_value )
            logger.debug(f"{as_value['name']} - {as_value['week_id']} - {convert_to_localtime(as_value['due_at'])}")
    # 
    return all_weeks


def filter_assignments_by_date(assignments, date_str, day_window ):
    """
    Filters assignments based on their 'due_at' date (UTC) being within 'day_window' days 
    of 'date_str' (local time).
    
    :param assignments: Dictionary of assignments
    :param date_str: Reference date as a string in "YYYY-MM-DD" format (local time)
    :param day_window: Number of days before and after the reference date to include
    :param convert_to_localtime: Function to convert UTC datetime to local time
    :return: List of as_value dictionaries that fall within the date range
    """
    reference_date = pd.to_datetime(date_str)  # Local time
    filtered_assignments = []

    for ag_value in assignments.values():
        for as_value in ag_value['assignments'].values():
            #due_date_utc = pd.to_datetime(as_value['due_at'])  # Convert due_at to datetime
            due_date_utc = as_value['due_at']
            if not due_date_utc:
#                logger.error(f"Missing due_at: {as_value['name']}" )
                continue

            due_date_local = pd.to_datetime(convert_to_localtime(due_date_utc))  # Convert UTC to local time

            #logger.debug(f"{as_value['name']}   {due_date_utc}  {due_date_local} {date_str}" )

            # Check if the due_date is within the specified window
            if 0<= (due_date_local - reference_date).days <= day_window:
                filtered_assignments.append(as_value)
#                logger.info(f"{ag_value['name']} - {as_value['name']}")

    filtered_assignments = sorted( filtered_assignments, key=lambda x: x['due_at'])
    return filtered_assignments

# Example usage:
# filtered = filter_assignments_by_date(assignments, "2025-01-25", 7, convert_to_localtime)
# print(filtered)



def lecture_topics_from_disk( include_weeks=None,exclude_weeks=None, columns=['week','id','t_opics','t_urls'],
                             tablefmt='tsv',csv_filename=None,xlsx_filename=None ):
    """ returns lecture topics from files on disk """

    lecture_files = sorted(get_list_of_local_lecture_files(),key=lambda x: x )
    if not lecture_files:
        return "No lecture files found.  Verify your current directory."

    outline_df = extract_outline().copy()
    outline_df['DateCanvas'] = pd.to_datetime( outline_df['DateCanvas'] )
    outline_df['datex'] = outline_df['DateCanvas'].dt.strftime('%Y-%m-%d')

#    deliverables = get_deliverables_by_week( outline_df )
#    logger.trace( deliverables )

    assignments = config.get_assignments()

    lectures = []
    stacked_lectures = []

    # loop over lecture files, already in ascending order (from above)

    for i,lecture_file in enumerate(lecture_files):

        # Reset topics and discussion items for lecture
        stacked_deliverables = []
        stacked_topics = []
        stacked_discussions = []
        stacked_includes = []

        # pick out key features - YAML header, lecture topics python list and discussion items python list
        yaml_header,lecture_topics,discussion_items,include_blocks = get_lecture_yaml_header( lecture_file )

        # build dictionary of common elements for each resulting row
        title=yaml_header.get('title','(missing)')
        dt = normalize_date(yaml_header.get('date','(missing)'))
        dow = get_day_of_week( dt )
        id = yaml_header.get('lecture-id',0)

        row = outline_df[outline_df['datex'] == dt]
        try:
            week = row['week_id'].iloc[0]
        except:
            week = 0

        common_elements = dict(
            lecture_file=lecture_file,
        	title=title,
            date=dt,
            dow=dow,
            week=week,
            id=id
        )

        # Process weekly deliverables
        # weekly_deliverables = deliverables[str(week)] # this snags deliverable due this exact week

        # this code filters deliverable due within X days of lecture date.
        weekly_deliverables = filter_assignments_by_date( assignments, dt, 8 )

        if weekly_deliverables is None:
            stacked_row = {**common_elements,"contents":'deliverable',"topic":None,"url":None,"opts":None,"post":None}
            stacked_row['topic'] = "No deliverables this week"
            stacked_deliverables.append( stacked_row )
        else:
            for row in weekly_deliverables:
                if 'gradescope' in row['name'].lower():
                    continue
                if ' - Requires Respondus' in row['name']:
                    row['name'] = row['name'].split(" - Requires Respondus")[0]

                stacked_row = {**common_elements,"contents":'deliverable',"topic":None,"url":None,"opts":None,"post":None}
                stacked_row['topic'] = row['name']
                stacked_row['url'] = row['html_url']
                stacked_row['opts'] = 'target="_blank"'
                due_at_str = convert_to_localtime(row['due_at']).split(" ")[0]
                due_on_day = get_day_of_week( due_at_str )
                date_2_digit = get_2_digit_date( due_at_str )
                stacked_row['post'] = f" - due {date_2_digit}, {due_on_day.upper()}"
                stacked_deliverables.append( stacked_row )

        # process include statements
        if not include_blocks:
            stacked_row = {**common_elements,"contents":'include',"topic":'.',"url":'.',"opts":'.',"post":'.'}
            stacked_row['topic'] = "When ready, the complete lecture will replace this one."
            stacked_includes.append( stacked_row )
        else:
            for row in include_blocks:
                stacked_row = {**common_elements,"contents":'include',"topic":'.',"url":'.',"opts":'.',"post":'.'}
                stacked_row['topic'] = row['title']
                stacked_row['url'] = row['include']
                stacked_includes.append( stacked_row )

        # process lecture topics
        t_opics = []
        t_urls = []
        t_options = []
        t_post_text = []

        stacked_row = {**common_elements,"topic":None,"url":None,"opts":None,"post":None}

        if lecture_topics is None:
            lecture_topics = ['When ready, the complete lecture will replace this one.']
            stacked_row = {**common_elements,"contents":'topic',"topic":'.',"url":'.',"opts":'.',"post":'.'}
            stacked_row['topic'] = lecture_topics[0]
            stacked_topics.append( stacked_row )
        else:
            for row in lecture_topics:
                stacked_row = {**common_elements,"contents":'topic',"topic":None,"url":None,"opts":None,"post":None}
                t,u,o,p = parse_markdown_link( row )
                if t:
                    t_opics.append( t )
                    stacked_row["topic"] = t
                if u:
                    t_urls.append( u )
                    stacked_row["url"] = u
                if o:
                    t_options.append( o )
                    stacked_row['opts'] = o
                if p:
                    t_post_text.append( p )
                    stacked_row['post'] = p
                stacked_topics.append( stacked_row )

        # process discussion items

        d_iscussion_items = []
        d_urls = []
        d_options = []
        d_post_text = []

        if discussion_items is None:
            discussion_items = ['This is a placeholder lecture.']
            stacked_row = {**common_elements,"contents":'discussion',"topic":'.',"url":'.',"opts":'.',"post":'.'}
            stacked_row['topic'] = discussion_items[0]
            stacked_discussions.append( stacked_row )
        else:
            for row in discussion_items:
                stacked_row = {**common_elements,"contents":'discussion',"topic":None,"url":None,"opts":None,"post":None}
                t,u,o,p = parse_markdown_link( row )
                if t:
                    t_opics.append( t )
                    stacked_row["topic"] = t
                if u:
                    t_urls.append( u )
                    stacked_row["url"] = u
                if o:
                    t_options.append( o )
                    stacked_row['opts'] = o
                if p:
                    t_post_text.append( p )
                    stacked_row['post'] = p
                stacked_discussions.append( stacked_row )


        # Use a set for efficient lookups
        # Filter stacked_discussions by keeping only items where the URL is NOT in deliverable_urls
        if stacked_deliverables and stacked_discussions:
            discussion_urls = {item["url"] for item in stacked_discussions}
            stacked_deliverables = [item for item in stacked_deliverables if item["url"] not in discussion_urls]


        # at this point, we've got a list of topics and a list of discussion items
        stacked_lectures.extend( stacked_discussions )
        stacked_lectures.extend( stacked_deliverables )

        # if length of topics and includes are the same, then we're aligned correctly.
        # let's keep just one to minimize cleanup.
        if len(stacked_topics)==len(stacked_includes):
            stacked_lectures.extend( stacked_includes )
        else:
            stacked_lectures.extend( stacked_topics )
            stacked_lectures.extend( stacked_includes )

        # add a blank row to the stacked output
        stacked_lectures.extend( [{key: None for key in stacked_row }] )

        # save the row for text output
        lectures.append( dict(file=lecture_file,
                              title=title,
                              date=dt,
                              dow=dow,
                              week=week,
                              id=id,
                              t_opics=f"{ '\n'.join(t_opics)}",
                              t_urls=f"{ '\n'.join(t_urls)}",
                              t_options=f"{ '\n'.join(t_options)}",
                              t_post_text=f"{ '\n'.join(t_post_text)}",
                              d_iscussion_items=f"{ '\n'.join(d_iscussion_items)}",
                              d_urls=f"{ '\n'.join(d_urls)}",
                              d_options=f"{ '\n'.join(d_options)}",
                              d_post_text=f"{ '\n'.join(d_post_text)}",
                        ))


    features = {
        'file':dict(header='File',colalign='left',colwidth=15),
        'title':dict(header='Title',colalign='left',colwidth=28),
        'date':dict(header='Date',colalign='center',colwidth=10.5),
        'dow':dict(header='DOW',colalign='center',colwidth=7),
        'week':dict(header='Week',colalign='center',colwidth=7),
        'id':dict(header='LID',colalign='center',colwidth=7),
        't_opics':dict(header='Topics',colalign='left',colwidth=15),
        't_urls':dict(header='URLs',colalign='left',colwidth=15),
        't_options':dict(header='Opts',colalign='left',colwidth=15),
        't_post_text':dict(header='Post',colalign='left',colwidth=15),
        'd_iscussion_items':dict(header='Discussion',colalign='left',colwidth=15),
        'd_urls':dict(header='URLs',colalign='left',colwidth=15),
        'd_options':dict(header='Opts',colalign='left',colwidth=15),
        'd_post_text':dict(header='Post',colalign='left',colwidth=15),
        'contents':dict(header='Contents',colalign='left',colwidth=11),
        'topic':dict(header='Topic',colalign='left',colwidth=40),
        'url':dict(header='URL',colalign='left',colwidth=20),
        'opts':dict(header='Options',colalign='left',colwidth=15),
        'post':dict(header='Post text',colalign='left',colwidth=15),
    }

    #select = ['file','title','date','dow','week','id','topics','urls','discussion_items']
    #select = ['week','dow','id','topics','discussion_items']

    # columns providea a list of the selected keys from the lectures structure

    headers = [ features[key]['header'] for key in columns ]
    colalign = [ features[key]['colalign'] for key in columns ]
    results = [ [ lecture[key] for key in columns] for lecture in lectures ]

    return_str = []
    if csv_filename:
        write_lectures_to_csv( stacked_lectures, csv_filename )  # fix me to loop over keys, using t_ and d_ knowledge.
        return_str.append( f'Results stored to {csv_filename}' )

    if xlsx_filename:
        save_topics_to_xlsx(stacked_lectures, xlsx_filename, features)
        return_str.append( f'Results stored to {xlsx_filename}' )

    if return_str:
        return "\n".join( return_str )
    else:
        return tabulate(results, headers=headers, tablefmt=tablefmt, colalign=colalign)
