""" docstring for cmd_token.py
"""
import os
import click
from loguru import logger

from cnvsapi.config import config, DEFAULT_LOG_LEVEL,ENV_TOKEN_NAME

@click.group()
@click.pass_context
def cli(ctx):
    """ *Token management

    For this program to access the canvas API, it needs a token from Canvas. Once the user
    obtains a token from Canvas, these commands can store it and retrieve it for later use.
    The token is stored locally on this computer in secure, persistent storage. For more
    details on this approach, see: https://pypi.org/project/keyring/
    
    Once the token is stored, this program can use it to access the canvas API. No further
    token thought required. The GET command is provided as a helper so that if desired
    the token CAN be accessed and shared with other programs, too. See the examples below.

    \b
    To obtain a token, visit:
        https://virginiacommonwealth.instructure.com/profile/settings
    and look under "Integrations" for the "add token" button.

    \b
    Once you have the token, use this command to store it locally:
        cnvsapi token set <your token goes here>

    \b
    To retrieve the token, use:
        cnvsapi token get

    \b
    For example, to store the token in an environment variable (on powershell):
        $ENV:CANVAS_API_TOKEN=$(cnvsapi token get)
        
    """
    logger.debug(f"TOKEN: invoked subcommand: {ctx.invoked_subcommand}")
    logger.debug(f"TOKEN: Inside token routine")



@cli.command()
def get():
    """ Returns token value from persistent secure storage on this computer.
    
    This command is useful when choosing to set an environment variable for later use
    in testing programs.

    \b
    For example:
        $ENV:CANVAS_API_TOKEN=$(cnvsapi token get)
    
    """
    print( config.token )

@cli.command()
@click.argument("token_value")
def set(token_value):
    """ Stores token in persistent secure storage on this computer.
    
    The token is stored locally on this computer in secure, persistent storage. For more
    details on this approach, see: https://pypi.org/project/keyring/

    \b
    To obtain a token, visit:
        https://virginiacommonwealth.instructure.com/profile/settings
    and look under "Integrations" for the "add token" button.
    """
    config.token = token_value

if __name__ == '__main__':
    cli(obj={})


