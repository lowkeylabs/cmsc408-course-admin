"""
"""
import re
import os
import sys
import ast
import json
import urllib
from loguru import logger
from datetime import datetime
from bs4 import BeautifulSoup


from urllib.parse import urlparse, parse_qs

def custom_encoder(obj):
    """ A custom decoder for json.dumps """
    if isinstance(obj, datetime):
        return obj.strftime('%Y-%m-%d %H:%M:%S')  # Convert datetime to a string
    elif obj.__class__.__name__=="File":
        return "file"
    else:
        try:
            # Attempt to serialize the object, and if it raises a TypeError, catch it
            json.dumps(obj)
        except TypeError:
            raise TypeError(f"Object of type {obj.__class__.__name__} is not JSON serializable in custom encoder")
        return obj

def extract_id( input_string ):
    """ returns a module identifier from a module title """
    #  "Week 1 - Resources" returns "1"
    #  "Welcome - introduction and resources" returns "welcome"
    extracted_string = input_string.split(' - ')[0]
    extracted_string = extracted_string.split()[-1].lower()
    return extracted_string

def extract_last_element( input_string):
    """
    Extracts the last element of a string split by ' - '.

    For example,    "Resource - Week 16 - CLI Guidelines", return "CLI Guidelines"
    
    Args:
        strings (list): A list of strings to process.
    
    Returns:
        list: A list of the last elements of each string.
    """
    return input_string.split(" - ")[-1]


def module_prefix_from_id( id ):
    """ returns a page url prefix from a module identifier """
    # "1" returns "Week 1"
    # "Welcome" returns "Welcome"
    result = id
    try:
        test = int(id)
        result = "Week " + str(id)
        if id==0:
            result = "Welcome"
    except ValueError:
        result = id
    return result

def get_frontpage_title( module_prefix ):
    title = f"{module_prefix.capitalize()} - Front Page"
    return title

def get_overview_title( module_prefix ):
    title = f"{module_prefix.capitalize()} - Overview"
    return title

def get_details_title( module_prefix ):
    title = f"{module_prefix.capitalize()} - Details"
    return title

def get_title(title_type, id=None, title=None ):
    """Return the appropriately formatted string based on title_type."""
    def is_number( value ):
        try:
            int(value)
            return True
        except:
            return False

    if title_type == "gradescope":
        return f"{title} - (gradescope)"

    prefix = ""
    if id:
        prefix = f"Week {id}" if is_number( id ) else f"{id.capitalize()}"

    if title_type == "frontpage":
         return f"{prefix} - Front Page"
    elif title_type == "overview":
         return f"{prefix} - Overview"
    elif title_type == "details":
        return f"{prefix} - Details"
    elif title_type == "lecture_slide":
        return f"Lecture {id} - slides"
    elif title_type == "lecture_video":
        return f"Lecture {id} - video"
    else:
        raise ValueError(f"Unknown title_type: {title_type}")

def clean_page_title( page_title ):
    """ return a cleaned page title for use with canvas """
    title = page_title.lower()
    # Replace ' - ' with '-'
    title = title.replace(" - ","-")
    # Replace spaces with hyphens
    title = title.replace(" ", "-")
    # Replace slashes with hyphens (or another character of your choice)
    title = title.replace("/", "-")
    # URL-encode the string
    url_friendly_title = urllib.parse.quote(title, safe="-")
    return url_friendly_title    


def find_page_in_pages( pages, title ):
    """ search for page """
    # This routine scans the local pages variable
    logger.debug(f"{title}")
    page = None
    for key, value in pages.items():
        if ('title' in value.keys()) and (clean_page_title(title) in clean_page_title(value['title'])):
            page = value
            return page
    return None

def find_quiz_in_quizzes( quizzes, title=None, id=None ):
    """ search for quiz """
    # This routine scans the local pages variable
    logger.debug(f"{title}")
    quiz = None
    for key, value in quizzes.items():
        if ('title' in value.keys()) and (value['title'].lower() == title.lower()):
            quiz = value
            return quiz
    return None

def find_ag_in_assignment_groups( assignment_groups, name=None, id=None ):
    for ag_key, ag in assignment_groups.items():
        if id:
            if ag['id']==id:
                return ag
        if name:
            if ag['name'].lower()==name.lower():
                return ag
    return None


def find_assignment_in_assignments( assignments, title=None, id=None ):
    """ search for assignment or quiz in list of assignments """
    logger.trace(f"{title}")
    # loop over assignment groups
    logger.trace( assignments )
    for ag_key,assign_group in assignments.items():
        for assign in assign_group["assignments"]:
            if id:
                if assign["id"] == id:
                    return assign
            if title:
                if assign["name"].lower() == title.lower():
                    return assign
    return None


def as_pretty_json( object,indent=3 ):
    """ Returns a formatted json representation of a python object """
    return json.dumps( object, indent=indent, default=custom_encoder)


def parse_cli_listxxx(ctx, param, value):
    logger.debug( param )
    if value is None:
        return ['default1', 'default2', 'default3']
    return value.split(',')


def find_config_file( filename ):
    current_path = os.getcwd()
    home_dir = os.path.expanduser("~")
    root_dir = os.path.abspath(os.sep)  # Get the root directory based on the OS

    while True:
        config_path = os.path.join(current_path, filename)
        if os.path.exists(config_path):
            return config_path
        if current_path == home_dir or current_path == root_dir:
            break
        current_path = os.path.dirname(current_path)

    # If file doesn't exists, return full path anyway

    current_path = os.getcwd()
    config_path = os.path.join(current_path, filename)
    return config_path

def parse_cli_listyyy(ctx,params,sample_string):
    # Preprocess the string to add quotes around elements
    def preprocess_string(s):
        # Add quotes around words that are not keys or in quotes
        s = re.sub(r'(?<!\w)(\w+)(?![\w\':])', r'"\1"', s)
        return s

    # Preprocess the input string
    processed_string = preprocess_string(sample_string)

    # Parse the string into a Python data structure
    data_structure = ast.literal_eval(processed_string)
    return data_structure


def parse_cli_list(ctx, params, sample_string):
    import re
    import ast

    # Preprocess the string to handle wildcards (`*`) as valid keys
    def preprocess_string(s):
        # Wrap unquoted keys (e.g., `key:`) with quotes
        s = re.sub(r'(?<![\w"])('  # Negative lookbehind: not after a word or quote
                   r'\w+'          # Match word characters
                   r')(?=\s*:)',   # Positive lookahead: colon follows
                   r'"\1"', s)

        # Wrap `*` in quotes to make it a valid key
        s = s.replace('*', '"*"')

        return s

    # Preprocess the input string
    processed_string = preprocess_string(sample_string)

    # Parse the string into a Python data structure
    try:
        data_structure = ast.literal_eval(processed_string)
        return data_structure
    except Exception as e:
        raise click.BadParameter(f"Invalid format for input string: {e}")


def order_modules_by_week( outline_df, prefix=None, postfix=None, include_weeks=None, exclude_weeks=None):
    """ Return a list of properly ordered modules for processing """
    filtered_df = outline_df[ (outline_df["week_id"] != '') & (outline_df["Module"] != '')]
    weeks = [ i for i in filtered_df["week_id"].unique() if i != "" ]
    logger.debug( weeks )
    complete_list = weeks
    if not prefix is None:
        complete_list = prefix + complete_list
    if not postfix is None:
        complete_list = complete_list + postfix
    if not include_weeks is None:
        return_list = []
        for item in include_weeks:
            if item in complete_list:
                return_list.append( item )
    elif not exclude_weeks is None:
        return_list = complete_list
        for item in exclude_weeks:
            if item in return_list:
                return_list.remove( item )
    else:
        return_list = complete_list

    return return_list

def order_weeks_by_week( outline_df, prefix=None, postfix=None, include_weeks=None, exclude_weeks=None):
    """ Return a list of properly ordered modules for processing """
    filtered_df = outline_df[ (outline_df["week_id"] != '') & (outline_df["Module"] != '')]
    weeks = [ i.lower() for i in filtered_df["week_id"].unique() if i != "" ]
    complete_list = weeks

    if not prefix is None:
        for item in prefix:
            if item.lower() in complete_list:
                complete_list.remove( item )
        complete_list = prefix + complete_list
    if not postfix is None:
        for item in postfix:
            if item.lower() in complete_list:
                complete_list.remove( item )
        complete_list = complete_list + postfix

    if not include_weeks is None:
        return_list = []
        for item in include_weeks:
            if item.lower() in complete_list:
                return_list.append( item )
    elif not exclude_weeks is None:
        return_list = complete_list
        for item in exclude_weeks:
            if item.lower() in return_list:
                return_list.remove( item )
    else:
        return_list = complete_list

    logger.debug( return_list )
    return return_list


#    weeks sorted( [ i for i in outline_df["WK"].unique() if i != ""]

def set_logger( log_level="DEBUG" ):
    """ Set logger with different messages for different levels """

    default_format = "<green>{time:YYYY-MM-DD HH:mm:ss.SSS}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>"
    simple_format = "{message}"

    simple_levels = ["INFO","SUCCESS","WARNING"]

    log_levels = [level.name for level in logger._core.levels.values() if level.no >= logger.level(log_level).no and not level.name in simple_levels ]

    # Remove the default logger configuration
    logger.remove()

    logger.add(sys.stderr, format=default_format, level=log_level, filter=lambda record: record["level"].name in log_levels)

    # this code is written out because of a bug in logger.add
    if "INFO" in simple_levels and logger.level(log_level).no <= logger.level("INFO").no:
        logger.add(sys.stderr, format=simple_format, level='INFO', filter=lambda record: record["level"].name=='INFO' )
    if "SUCCESS" in simple_levels and logger.level(log_level).no <= logger.level("SUCCESS").no:
        logger.add(sys.stderr, format=simple_format, level='SUCCESS', filter=lambda record: record["level"].name=='SUCCESS' )
    if "WARNING" in simple_levels and logger.level(log_level).no <= logger.level("WARNING").no:
        logger.add(sys.stderr, format=simple_format, level='WARNING', filter=lambda record: record["level"].name=='WARNING' )
    if "ERROR" in simple_levels and logger.level(log_level).no <= logger.level("ERROR").no:
        logger.add(sys.stderr, format=simple_format, level='ERROR', filter=lambda record: record["level"].name=='ERROR' )
    if "CRITICAL" in simple_levels and logger.level(log_level).no <= logger.level("CRITICAL").no:
        logger.add(sys.stderr, format=simple_format, level='CRITICAL', filter=lambda record: record["level"].name=='CRITICAL' )

def clean_include_lists( all, include_weeks, exclude_weeks ):
    """ process command line options and return clean lists """
    if include_weeks is None:
        include_list = None
    else:
        include_list = [x.lower() for x in include_weeks.split(",")]
    if exclude_weeks is None:
        exclude_list = None
    else:
        exclude_list = [x.lower() for x in exclude_weeks.split(",")]
    if all:
        include_list=None
        exclude_list=None
    if isinstance( include_list, list ):
        if "all" in include_list:
            all = True
            include_list = None
    return all, include_list, exclude_list 

def get_fp_styles( ):
    """ returns a list of frontpage/fp styles for appending into html """
    # Styles used in HTML.  Note that these CANNOT be edited once they are in Canvas.
    # Canvas deletes any styles when it opens an editor window for the page.
    lines = []
    lines.append("<style>")
    lines.append(
                """
                .fp-header-div{
                    display: flex;
                    flex-direction: column;
                    background-color: gray;
                    height:auto;
                    width:100%;
                    align-items:center;
                    justify-content:center;
                    margin:0;
                    padding:0;
                }

                .fp-header-div-current{
                    display: flex;
                    flex-direction: column;
                    background-color: dodgerblue;
                    height:auto;
                    width:100%;
                    align-items:center;
                    justify-content:center;
                    margin:0;
                    padding:0;
                }
                .fp-header-span-first{
                    color: white; 
                    max-width:100%;
                    font-size: 36px;
                    height:44px;
                    white-space: nowrap;
                    align-items:center;
                    justify-content:center;
                    margin:0;
                    padding:0;
                }

                .fp-header-span-second{
                    color: lightgray; 
                    align-items:center;
                    justify-content:center;
                    max-width:100%;
                    margin:0;
                    padding:0;
                    padding-bottom:4px;
                }
                    
                .fp-footer-container{
                    width:100%;
                    display: flex;
                    flex-wrap: wrap;
                    flex-direction: row;
                    gap: 10px;
                    justify-content: center;
                    margin-bottom: 20px;
                    margin-left:0;
                    margin-right:0;
                    padding-left:0;
                    padding-right:0;
                    }
                .fp-footer-button-available {
                    width:60px;
                    background-color: gray;
//                        padding: 10px 20px;
                    border: 2px solid black;
                    border-radius: 5px;
                    color: white;
                    text-align: center;
                    cursor: pointer;
                    transition: background-color 0.3s;                     
                }
                .fp-footer-button-current {
                    width:60px;
                    background-color: dodgerblue;
//                        padding: 10px 20px;
                    border: 2px solid black;
                    border-radius: 5px;
                    color: white;
                    text-align: center;
                    cursor: pointer;
                    transition: background-color 0.3s;                     
                }

                .fp-footer-button-available:hover {
                    background-color:darkgray;
                }
                .fp-footer-button-available a {
                    color:white;
                    text-decoration:none;
                }

                .fp-footer-button-current:hover {
                    background-color:darkgray;
                }
                .fp-footer-button-current a {
                    color:white;
                    text-decoration:none;
                }
                .fp-footer-button-notavailable {
                    width:60px;
                    background-color: lightgray;
//                        padding: 10px 20px;
                    border: 2px solid black;
                    border-radius: 5px;
                    color: white;
                    text-align: center;
                    cursor: pointer;
                    transition: background-color 0.3s;                     
                }
                .fp-footer-button-text {
                    font-size: 22px;
                }
                @media (max-width:900px) {  // these don't work in Canvas!
                    .fp-header-span-second {
                        display: none;
                        color: yellow;
                    }
                }
                .fp-test-placeholder {
                    color:red;
                }

                .fp-content {
                    display: flex;
                    flex-direction: row;
                }

                .fp-wiki-page {
                    display: flex;
                    flex: 1;
                    flex-direction: column;
                }

                .fp-right-side-placeholder {
                    width:288px;
                }
                .fp-left-side-placeholder {
                    background-color:green;
                    flex: 1;
                    border: 1px solid black;
                }

                .fp-body-container{
                    width:100%;
                    display: flex;
                    flex-wrap: wrap;
                    flex-direction: row;
                    gap: 3%;
                    justify-content: center;
                    //padding-left: 4%; 
                    //padding-right: 4%;
                }

                .fp-body-3column{
                    flex: 1;
                    word-wrap: break-word;
                    width: 27%;
                    max-width: 27%;
                    //border: 1px solid black;
                    padding-left: 10px;
                    padding-right: 10px;
                }
                .fp-body-2column{
                    flex: 1;
                    word-wrap: break-word;
                    width: 44%;
                    max-width: 44%;
                    //border: 1px solid black;
                    padding-left: 10px;
                    padding-right: 10px;
                }
                .fp-body-1column{
                    flex: 1;
                    word-wrap: break-word;
                    width: 60%;
                    max-width: 60%;
                    //border: 1px solid black;
                    padding-left: 10px;
                    padding-right: 10px;
                }
                .fp-body-details{
                    flex: 1;
                    word-wrap: break-word;
                    width: 95%;
                    max-width: 95%;
                    //border: 1px solid black;
                    margin-top: 0px;
                    margin-top: 0px;
                    padding-top:0px;
                    padding-bottom:0px;
                    padding-left: 10px;
                    padding-right: 10px;
                }

                .fp-hr-div{
                    //border: 1px solid black;
                    margin-bottom: -20px;
                    margin-top: -15px;
                    padding-bottom: 0px;
                }

                
                .fp-row-container {
                    display: flex;
                    width: 100%;
                    margin:0;
                    padding:0;
                    align-items:center;
                }

                .fp-row-item {
                    margin:0;
                    passing:0;
                }

                .left {
                    width: 120px;
                    justify-content: flex-end;
                    text-align:center;
                }
                .right {
                    width: 120px;
                    justify-content: flex-start;
                    text-align: center;
                }

                .center {
                    flex-grow: 1; /* This makes the center cell take up the remaining space */
//                        background-color: lightgray; /* Just for visual differentiation */
                }
                
                """)
                
    lines.append("</style>")
    return lines



def extract_links_from_body_text(html_snip):
    """
    Extracts name/URL pairs from list items (<li>) in an HTML snippet.

    Args:
        html_snip (str): The HTML snippet containing an ordered or unordered list with links.

    Returns:
        list: A list of tuples, each containing the name and URL of a link.
    """
    soup = BeautifulSoup(html_snip, "html.parser")
    links = []
    
    # Find all list items (<li>) containing links
    for li in soup.find_all("li"):
        a_tag = li.find("a", href=True)  # Find <a> tag with href attribute
        if a_tag:
            name = a_tag.text.strip()  # Extract link text
            url = a_tag["href"]        # Extract href attribute
            links.append((name, url))
    
    return links


from urllib.parse import urlparse, parse_qs

def extract_youtube_video_id(url):
    """
    Processes a URL and returns the YouTube identifier (video ID, playlist ID, etc.)
    if it's a YouTube URL, otherwise returns the full URL.
    
    Args:
        url (str): The URL to process.
        
    Returns:
        str: The YouTube identifier or the full URL.
    """
    parsed_url = urlparse(url)
    netloc = parsed_url.netloc
    path = parsed_url.path
    query = parse_qs(parsed_url.query)

    # Standardize netloc to handle "youtube-nocookie.com"
    if "youtube" in netloc:
        # Standard YouTube video URL
        if "watch" in path and "v" in query:
            return query["v"][0]
        # Shortened YouTube URL
        elif "youtu.be" in netloc:
            return path.lstrip("/")
        # Playlist URL
        elif "playlist" in path and "list" in query:
            return query["list"][0]
        # Embedded video, including youtube-nocookie.com
        elif "embed" in path:
            return path.split("/")[-1]
        # Live stream
        elif "live" in path:
            return path.split("/")[-1]

    return url  # Return the full URL if not YouTube


def clean_canvas_body_text( body_text ):
    """ take a body_text from canvas, and clean it up.  Remove <link> and <script> tags """
    # Parse the HTML
    soup = BeautifulSoup(body_text, 'html.parser')

    # Remove all <script> and <link> tags
    for tag in soup(['script', 'link']):
        tag.decompose()

    # Pretty format the cleaned HTML
    formatted_html = soup.prettify()
    return formatted_html

def extract_iframes_from_body_text( body_text ):
    """ extract iframes from canvas body text """
    soup = BeautifulSoup(body_text, 'html.parser')

    # Extract iframe src and title attributes
    iframes = soup.find_all('iframe')
    results = [{'src': iframe.get('src'), 'title': iframe.get('title')} for iframe in iframes]
    return results


def parse_names(ctx, param, value):
    if value:
        return [name.strip() for name in value.split(',')]
    return []


def grab_filenames( folder_path ):
    """ return list of filenames for the given folder """
    if folder_path is None:
        raise ValueError(f"No folder path provided")
    if not os.path.isdir(folder_path):
        raise ValueError(f"The provided folder path '{folder_path}' does not exist or is not a directory.")
    filenames = os.listdir( folder_path )
    full_paths = [os.path.join(folder_path, filename) for filename in filenames]
    return full_paths


def filter_filenames( filenames, match_words, exclude_words):
    """
    Filters a list of filenames based on matching and excluding words.

    Args:
        filenames : List of filenames
        match_words (list): List of words to match in filenames.
        exclude_words (list): List of words to exclude in filenames.

    Returns:
        list: A list of filenames that match the criteria.
    """

    # Normalize to lower case for case-insensitive matching
    match_words = [word.lower() for word in match_words]
    exclude_words = [word.lower() for word in exclude_words]

    filtered_files = []

    logger.debug( filenames )

    for filename in filenames:
        # Skip directories
        if os.path.isdir(filename):
            continue

        lower_filename = filename.lower()

        # Match all files if match_words is None or empty
        match_condition = True if not match_words else any(substring in lower_filename for substring in match_words)

        # Exclude nothing if exclude_words is None or empty
        exclude_condition = False if not exclude_words else any(substring in lower_filename for substring in exclude_words)

        # Add the filename if it meets the conditions
        if match_condition and not exclude_condition:
            filtered_files.append(filename)

    return filtered_files

def get_relative_filenames(folder):
    """
    Returns a list of relative filenames for all files under the specified folder.

    Args:
        folder (str): The folder to search for files.

    Returns:
        list: A list of relative file paths.
    """
    relative_filenames = []
    for root, _, files in os.walk(folder):
        for file in files:
            # Calculate the relative path
            relative_path = os.path.relpath(os.path.join(root, file), start=folder)
            relative_filenames.append(relative_path)
    return relative_filenames

import os
import shutil

def copy_folder_contents(source_folder, destination_folder, overwrite=False):
    """
    Copies the contents of the source folder to the destination folder.

    Args:
        source_folder (str): The folder to copy files from.
        destination_folder (str): The folder to copy files to.
        overwrite (bool): Whether to overwrite existing files in the destination.

    Raises:
        ValueError: If the source folder does not exist.
    """
    if not os.path.exists(source_folder):
        raise ValueError(f"Source folder '{source_folder}' does not exist.")
    
    # Ensure the destination folder exists
    os.makedirs(destination_folder, exist_ok=True)

    # Walk through the source folder
    for root, dirs, files in os.walk(source_folder):
        # Calculate relative path to preserve structure
        relative_path = os.path.relpath(root, source_folder)
        destination_path = os.path.join(destination_folder, relative_path)

        # Ensure subdirectories exist in the destination
        os.makedirs(destination_path, exist_ok=True)

        # Copy files
        for file in files:
            source_file = os.path.join(root, file)
            destination_file = os.path.join(destination_path, file)

            if overwrite or not os.path.exists(destination_file):
                logger.debug(f"copying {source_file} to {destination_file}")
                shutil.copy2(source_file, destination_file)


from collections import OrderedDict


def float_keys(metadata, keys_to_float_top, keys_to_float_bottom):
    """
    Reorders a metadata dictionary by floating specified keys to the top and bottom.

    Args:
        metadata (dict): The metadata dictionary to reorder.
        keys_to_float_top (list): List of keys to move to the top in the specified order.
        keys_to_float_bottom (list): List of keys to move to the bottom in the specified order.

    Returns:
        OrderedDict: A new dictionary with the keys floated to the top and bottom.
    """
    sorted_metadata = OrderedDict()

    # Add the prioritized top keys first
    for key in keys_to_float_top:
        if key in metadata:
            sorted_metadata[key] = metadata[key]

    # Add the remaining keys that are not in top or bottom lists
    for key, value in metadata.items():
        if key not in keys_to_float_top and key not in keys_to_float_bottom:
            sorted_metadata[key] = value

    # Add the bottom-prioritized keys
    for key in keys_to_float_bottom:
        if key in metadata:
            sorted_metadata[key] = metadata[key]

    return sorted_metadata

