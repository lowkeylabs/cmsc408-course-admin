""" docstring for cmd_quizzes
"""
import os
import re
import json
import click

from loguru import logger
import markdown
import pandas as pd

from cnvsapi.utils import as_pretty_json
from cnvsapi.config import config, DEFAULT_LOG_LEVEL,ENV_TOKEN_NAME
from cnvsapi.quiz_utils import test, write_df_to_gsheet
#from cnvsapi.utils import edit_list_with_editor, update_modules, update_moduleitems

def print_list_of_quizzes( quizzes ):
    """ print a pretty list of quizzes """
    for key in quizzes.keys():
        print(f"{quizzes[key]['id']}\t{quizzes[key]['title']}")

def print_quiz( quiz ):
    print(f"{quiz['id']}\t{quiz['title']}")
    print( as_pretty_json( quiz ) )


@click.group(invoke_without_command=True)
@click.option("--course-id",help="Display details for this course ID",default=None,type=int)
@click.option("--quiz-id",help="Display details for this quiz ID",default=None,type=int)
@click.option("--courses",help="Display courses and ids",is_flag=True, default=False)
@click.pass_context
def cli(ctx,course_id,quiz_id,courses):
    """ Quiz command

    The quiz command provide utilities for directly modifying canvas quiz objects.

    """
    if courses:
        crses = config.get_courses()
        comments = ""
        for id in crses.keys():
            line = f"{'' if id==config.course_id else '# '}course_id={id:<8d} #  {crses[id]['name']}"
            print( line )
            comments = comments + "\n" + line
        return
    if not course_id is None:
        ctx.obj["COURSE_ID"] = course_id
        config.course_id = course_id
    
    course = config.get_default_course()
    ctx.obj["QUIZ_ID"] = quiz_id


    if ctx.invoked_subcommand is None:
        quizzes = config.get_quizzes()
        print(f"Default course id: {config.course_id} / {course["sis_course_id"]}")
        if not quiz_id is None:
            if quiz_id in quizzes.keys():
                print(f"Default quiz id: {quiz_id} \t {quizzes[quiz_id]['title']}")
            else:
                print(f"Invalid quiz_id: {quiz_id}")
                quiz_id = None

#        print(f"Default plugin folder: {config.plugin_folder}")
#        print(f"Default QMD template is: {config.config['roster']['default_qmd_template']}")
        click.echo(ctx.get_help())

        if quiz_id is None:
            print("\nList of available quizzes to view:")
            print_list_of_quizzes( quizzes )
           


@cli.command()
@click.pass_context
def pull(ctx):
    """ Get quiz info and add it to cnvsapi. Canvas data overrides local .cnvsapi data."""
#    qq = bridge.get_all_quizzes_and_questions()
#    for quiz_id in qq.keys():
#        for ques_id in qq[quiz_id].keys():
#            print(f"{quiz_id}:{ques_id}:{qq[quiz_id][ques_id]['position']}:{qq[quiz_id][ques_id]['clean_text']}")

#    if ctx.obj["QUIZ_ID"] is None:
#        print("Pull command requires --quiz-id")
#    else:
#        quiz_id = ctx.obj["QUIZ_ID"]
#        print(f"responses for {quiz_id}")
#        submissions = config.get_canvas().get_course(config.course_id).get_quiz( quiz_id ).get_submissions()
#        logger.debug(f"quiz_id: {quiz_id}")
#        for submission in submissions:
#            print(f"user_id: {getattr(submission,'user_id')}; submission_id: {getattr(submission,'submission_id')}")
#            print(vars(submission))
#            if getattr(submission,"submission_id")==25546116:
#                answers = config.get_canvas().get_course(config.course_id).get_qui
#                print(f"{answers}")


@cli.command()
@click.option('--to-xlsx',help="Store responses to excel workbook")
@click.option('--to-gsheet-id',help="Store responses to google sheet")
@click.option('--to-gsheet-tab',default='Source data',help="Name of tab in gsheet for data")
@click.pass_context
def responses(ctx,to_xlsx,to_gsheet_id,to_gsheet_tab):
    """ Get responses for specific quiz """
    print(f"responses for {ctx.obj['QUIZ_ID']}")
    quiz_id = ctx.obj["QUIZ_ID"]
    if quiz_id is None:
        print('missing quiz_id')
    else:
        logger.debug(f"course: {config.course_id} :: assignment: {quiz_id} ")

#        x = config.get_quiz_responses( quiz_id )
#        print(x)
        # get quiz questions and answers
        if not to_xlsx is None:
            logger.debug(f"response to_xlsx: {to_xlsx}")
            df = config.get_quiz_responses( quiz_id )
            df.to_excel( to_xlsx )
        elif not to_gsheet_id is None:
            logger.debug(f"response gsheet: {to_gsheet_id} and tab: {to_gsheet_tab}")
            df = config.get_quiz_responses( quiz_id )
            data = {
                'A': [1, 2, 3, 4, 5],
                'B': ['foo', 'bar', 'foo', 'bar', 'foo'],
                'C': [0.1, 0.2, 0.3, 0.4, 0.5]
            }
            write_df_to_gsheet( df, to_gsheet_id, to_gsheet_tab )
        else:
            print('needs a storage location')


@cli.command()
@click.option("--id",help="Display details for this question ID",default=None,type=int)
@click.pass_context
def questions(ctx,id):
    quiz_id = ctx.obj["QUIZ_ID"]
    if quiz_id is None:
        logger.debug(f"processing questions")
 #       qq = bridge.get_all_quizzes_and_questions()
 #       for quiz_id in qq.keys():
 #           for ques_id in qq[quiz_id].keys():
 #               print(f"{quiz_id}:{ques_id}:{qq[quiz_id][ques_id]['position']}:{qq[quiz_id][ques_id]['clean_text']}")
    else:
        logger.debug(f"Gathering data for quiz {quiz_id}")
#        quiz = bridge.get_quiz_questions( quiz_id )
#        if id is None:
#            for ques_id in quiz:
#                print("-----")
#                print(f"{quiz_id}:{ques_id}:{quiz[ques_id]['position']}:{quiz[ques_id]['question_type']}:{quiz[ques_id]['clean_text']}")
#                for id,answer in enumerate(quiz[ques_id]['answers']):
#                    print(f"{id}: {answer['id']}: {answer['text']}")
#        else:
#            ques_id = id
#            logger.debug(f"{quiz.keys()}")
#            for key in quiz[ques_id]:
#                print(f"{quiz_id}:{ques_id}:{quiz[ques_id]['position']}:{key}:{quiz[ques_id][key]}")


@cli.command()
@click.option("--quiz-id",help="Display details for this quiz id",default=None,type=int)
@click.pass_context
def list(ctx,quiz_id):
    """ List quizzes for current course """
    logger.debug(f"Listing quizzes in current course.")
    id = ctx.obj["QUIZ_ID"]
    if not quiz_id is None:
        id = quiz_id
    quizzes = config.get_quizzes()
    if id is None:
        print_list_of_quizzes( quizzes )
    else:
        if not id in quizzes.keys():
            click.echo(f"Invalid quiz id: {id}")
            click.echo("Valid ids include:")
            print_list_of_quizzes( quizzes )
        else:
            print_quiz( quizzes[id] ) 



if __name__ == '__main__':
    cli(obj={})


