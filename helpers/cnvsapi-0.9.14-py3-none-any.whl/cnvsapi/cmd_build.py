""" docstring for cmd_build
"""
import os
import re
import sys
import json
import click

from loguru import logger
import markdown
import pandas as pd

from cnvsapi.utils import as_pretty_json, clean_include_lists
from cnvsapi.config import config, DEFAULT_LOG_LEVEL,ENV_TOKEN_NAME
from cnvsapi.build_utils import copy_google_sheet, build_lecture_files_from_outline, \
    build_canvas_events_from_outline,  \
    sync_syllabus_from_config, freshen_lectures_from_outline, \
    sync_canvas_roster_from_source, build_detail_files_from_outline, \
    copy_template_folder, freshen_canvas_objects_from_outline
from cnvsapi.quiz_utils import test


@click.group(invoke_without_command=True)
@click.option("--course-id",help="Display details for this outcome ID",default=None,type=int)
@click.option("--courses",help="Display courses and ids",is_flag=True, default=False)
@click.pass_context
def cli(ctx,course_id,courses):
    """ Build canvas objects from an outline.

The build command provide utilities for directly modifying Canvas objects and creating
custom Canvas pages.

CNVSAPI depends on a specifically formatted google sheet, called an OUTLINE to store content
that is used manipulate a canvas course, and local lecture files.

\b
1. Create .cnvsapi configuration file
List available courses:
cnvsapi list courses
From list, pick desired course id and test:
cnvsapi list courses --course-id=113806
If OK then save to .cnvsapi file:
cnvsapi list courses --course-id=113806 --save

\b
2. Create new copy of outline from master template.
cnvsapi build outline-from-master

\b
3. Modify, amend, and review the outline gsheet as desired.
cnvsapi outline lectures
cnvsapi outline homeworks
etc.

\b
4. Add syllabus.
Create syllabus in appropriate gdrive folder.  Cut/clip gdoc id
Add gdoc ID to .cnvsapi file.
cnvsapi build canvas-syllabus-from-config

\b
5. Add lecture meetings to event calendar
Clean and verify lectures.  'cnvsapi outline lectures'
cnvsapi build canvas-events-from-outline' 

\b
6. Create Lecture folder and files.
cnvsapi build local-lectures-from-outline
cnvsapi build local-details-from-outline
cnvsapi build local-pages-from-outline
cnvsapi build local-rosters-from-outline

(Then edit _quarto.yml with appropriate gh-pages destination folder.)
quarto render lecture-01.qmd

These were the one-time commands.  Now, jump to the FRESHEN command
cnvsapi freshen

"""
    if courses:
        crses = config.get_courses()
        comments = ""
        for id in crses.keys():
            line = f"{'' if id==config.course_id else '# '}course_id={id:<8d} #  {crses[id]['name']}"
            click.echo( line )
            comments = comments + "\n" + line
        return

    if not course_id is None:
        ctx.obj["COURSE_ID"] = course_id
        config.course_id = course_id
    
    if ctx.invoked_subcommand is None:
        course = config.get_default_course()
        click.echo(ctx.get_help())
        click.echo("\nDefaults:")
        click.echo(f"  Course id: {config.course_id} / \"{course["name"]}\"")
        click.echo(f"  Plugin folder: {config.plugin_folder}")

if 0:
    @cli.command()
    @click.option("--overwrite",help="Overwrite destination file",default=False, is_flag=True )
    @click.pass_context
    def rubric(ctx,overwrite):
        """ *Testing - creating rubrics on the fly """    
    #    rubric = config.get_default_course_endpoint().get_rubric(121219).delete()
        x = config.create_rubric("rubric 1")
        rubric = config.get_default_course_endpoint().get_rubric( 121220 )
        rubric


@cli.command()
@click.option("--folder-id",help="Google folder ID to receive copy of original sheet",default=None )
@click.option("--original-id",help="GSheet ID of original gsheet to be copied",default="1cp9-7bAWZtcCDUfXEY5eD1Bg5SejFI-dqCjG0Mj1rXE")
@click.option("--confirm",help="Execute copy operation",default=False,is_flag=True)
@click.pass_context
def outline_from_master(ctx,folder_id,original_id,confirm):
    """ Copy outline gsheet from existing course or template.

\b
To get started, you'll need to track down two items:
- original-id : the google sheet id for the source outline.
- folder-id : the google folder id for the destination folder to receive the new outline.
"""

    if (folder_id is None) or (original_id is None or (not confirm)):
        click.echo(ctx.get_help())
        click.echo("\n")
        sheet_meta_data = copy_google_sheet(original_id, folder_id, False )

        click.echo(f"folder_id: {folder_id}")
        click.echo(f"original_id: {original_id}")
        click.echo(f"Use --confirm to execute the copy operation")
        sys.exit()

    if confirm:
        sheet_meta_data = copy_google_sheet(original_id, folder_id, confirm )
        if not sheet_meta_data is None:
            click.echo(f"Outline sheet created.")
            for key in ['name','webViewLink']:
                click.echo( f"{key}: {sheet_meta_data[key]}" )
        else:
            click.echo(f"Outline not created")
    else:
        click.echo(f"Use --confirm to make copy")


@cli.command()
@click.option("--all",help="Create new or replace missing lecture files",default=False, is_flag=True )
#@click.option("--include-lectures",type=str,help="List of lectures to include",default=None )
#@click.option("--exclude-lectures",type=str,help="List of lectures to exclude",default=None )
@click.pass_context
def local_lectures_from_outline(ctx,all):
    """ Build lecture slides file. Will NOT overwrite existing files.
    
       qmd files using data from google outline
       
    """
#    all,include_list,exclude_list = clean_include_lists( all, include_lectures, exclude_lectures )

#    if (not all) and (include_list is None) and (exclude_list is None):
    if not all:
        click.echo(ctx.get_help())
    else:
        if copy_template_folder( "lectures", overwrite=False ):
            build_lecture_files_from_outline( folder="lectures")
            freshen_lectures_from_outline()


@cli.command()
@click.option("--all",help="Build weekly details files",default=False, is_flag=True )
@click.option("--include-weeks",type=str,help="List of week numbers to include in build",default=None )
@click.option("--exclude-weeks",type=str,help="List of week numbers to exclude from build",default=None )
@click.pass_context
def local_details_from_outline(ctx,all,include_weeks,exclude_weeks):
    """ Build weekly details pages and templates
    
       qmd files using data from google outline
       
    """

    all,include_list,exclude_list = clean_include_lists( all, include_weeks, exclude_weeks )

    if (not all) and (include_list is None) and (exclude_list is None):
        click.echo(ctx.get_help())
    else:
        if copy_template_folder( "details", overwrite=False ):
            build_detail_files_from_outline(include_weeks=include_list,exclude_weeks=exclude_list, folder="details")


@cli.command()
@click.option("--all",help="Build page folder and templates",default=False, is_flag=True )
@click.pass_context
def local_pages_from_outline(ctx,all):
    """ Build demo page files and templates
    
       qmd files using data from google outline
       
    """
    if (not all):
        click.echo(ctx.get_help())
    else:
        if copy_template_folder( "pages", overwrite=False ):
            click.echo("Page folder and templates created. Nothing else happened. More work can happen here!")


@cli.command()
@click.option("--all",help="Build roster folder and templates",default=False, is_flag=True )
@click.pass_context
def local_rosters_from_outline(ctx,all):
    """ Build roster folder and templates
    
       qmd files using data from google outline
       
    """
    if (not all):
        click.echo(ctx.get_help())
    else:
        if copy_template_folder( "rosters", overwrite=False ):
            click.echo("Roster folder and templates created. Nothing else happened. More work can happen here!")



@cli.command()
@click.option("--all",help="Build calendar events for all lectures",default=False, is_flag=True )
#@click.option("--include-weeks",type=str,help="List of week numbers to include in build",default=None )
#@click.option("--exclude-weeks",type=str,help="List of week numbers to exclude from build",default=None )
@click.pass_context
def canvas_events_from_outline(ctx,all):
    """ Build calendar events for course lectures using data from google outline """

#    all,include_list,exclude_list = clean_include_lists( all, include_weeks, exclude_weeks )

    if (not all):
        click.echo(ctx.get_help())
    else:
        build_canvas_events_from_outline()


@cli.command()
@click.option("--all",help="Confirmation to build/rebuild syllabus",default=False, is_flag=True )
@click.option("--as-front-page",help="True to set syllabus as frontpage",is_flag=True, default=True)
@click.pass_context
def canvas_syllabus_from_config( ctx, all, as_front_page ):
    """ Connect canvas syllabus using syllabus info in config """
    if not all:
        click.echo( ctx.get_help() )
    else:
        if sync_syllabus_from_config( as_front_page ):
            click.echo(f"Syllabus attached. See canvas for details.")


@cli.command()
@click.option("--all",help="Confirmation to build/rebuild canvas objects",default=False, is_flag=True )
@click.pass_context
def canvas_objects_from_outline( ctx, all ):
    """ Build canvas objects including assignments, quizzes, etc.
    """
    if not all:
        click.echo( ctx.get_help() )
    else:
        freshen_canvas_objects_from_outline( )



if 0:
    @cli.command()
    @click.option("--all",help="Build for all weeks",default=False, is_flag=True )
    @click.option("--include-weeks",type=str,help="List of week numbers to include in build",default=None )
    @click.option("--exclude-weeks",type=str,help="List of week numbers to exclude from build",default=None )
    @click.pass_context
    def all_canvas_items(ctx, all, include_weeks, exclude_weeks):
        """ *Modules, pages, events, frontpages, syllabus.
        
        Does not create lecture slides.
        
        """
        all,include_list,exclude_list = clean_include_lists( all, include_weeks, exclude_weeks )

        if (not all) and (include_list is None) and (exclude_list is None):
            click.echo(ctx.get_help())
        else:
            pass


@cli.command()
@click.option("--all",help="Confirmation to build/rebuikd roster",default=False, is_flag=True )
@click.pass_context
def canvas_roster_from_source( ctx, all ):
    """ Create canvas page to contain roster headshots """
    if not all:
        click.echo( ctx.get_help() )
    else:
        if sync_canvas_roster_from_source():
            click.echo("Roster page created.")


if __name__ == '__main__':
    cli(obj={})
