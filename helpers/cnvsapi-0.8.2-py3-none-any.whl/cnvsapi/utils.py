"""
"""
import re
import os
import sys
import ast
import json
from loguru import logger
from datetime import datetime

def custom_encoder(obj):
    """ A custom decoder for json.dumps """
    if isinstance(obj, datetime):
        return obj.strftime('%Y-%m-%d %H:%M:%S')  # Convert datetime to a string
    elif obj.__class__.__name__=="File":
        return "file"
    else:
        try:
            # Attempt to serialize the object, and if it raises a TypeError, catch it
            json.dumps(obj)
        except TypeError:
            raise TypeError(f"Object of type {obj.__class__.__name__} is not JSON serializable in custom encoder")
        return obj

def extract_id( input_string ):
    """ returns a module identifier from a module title """
    #  "Week 1 - Resources" returns "1"
    #  "Welcome - introduction and resources" returns "welcome"
    extracted_string = input_string.split(' - ')[0]
    extracted_string = extracted_string.split()[-1].lower()
    return extracted_string


def module_prefix_from_id( id ):
    """ returns a page url prefix from a module identifier """
    # "1" returns "Week 1"
    # "Welcome" returns "Welcome"
    result = id
    try:
        test = int(id)
        result = "Week " + str(id)
        if id==0:
            result = "Welcome"
    except ValueError:
        result = id
    return result

def get_frontpage_title( module_prefix ):
    title = f"{module_prefix.capitalize()} - Front Page"
    return title

def get_overview_title( module_prefix ):
    title = f"{module_prefix.capitalize()} - Overview"
    return title

def get_details_title( module_prefix ):
    title = f"{module_prefix.capitalize()} - Details"
    return title

def find_page_in_pages( pages, title ):
    """ search for page """
    # This routine scans the local pages variable
    logger.debug(f"{title}")
    page = None
    for key, value in pages.items():
        if ('title' in value.keys()) and (value['title'].lower() == title.lower()):
            page = value
            return page
    return page

def find_assignment_in_assignments( assignments, title ):
    """ search for assignment or quiz in list of assignments """
    logger.debug(f"{title}")
    # loop over assignment groups
    for ag_key, assign_group in assignments.items():
        if ('assignments' in assign_group.keys()) and isinstance(assign_group["assignments"],dict):
            for assign_key, assign in assign_group["assignments"].items():
                if assign["name"].lower() == title.lower():
                    return assign
    return None


def as_pretty_json( object,indent=3 ):
    """ Returns a formatted json representation of a python object """
    return json.dumps( object, indent=indent, default=custom_encoder)


def parse_cli_listxxx(ctx, param, value):
    logger.debug( param )
    if value is None:
        return ['default1', 'default2', 'default3']
    return value.split(',')


def find_config_file( filename ):
    current_path = os.getcwd()
    home_dir = os.path.expanduser("~")
    root_dir = os.path.abspath(os.sep)  # Get the root directory based on the OS

    while True:
        config_path = os.path.join(current_path, filename)
        if os.path.exists(config_path):
            return config_path
        if current_path == home_dir or current_path == root_dir:
            break
        current_path = os.path.dirname(current_path)

    # If file doesn't exists, return full path anyway

    current_path = os.getcwd()
    config_path = os.path.join(current_path, filename)
    return config_path

def parse_cli_list(ctx,params,sample_string):
    # Preprocess the string to add quotes around elements
    def preprocess_string(s):
        # Add quotes around words that are not keys or in quotes
        s = re.sub(r'(?<!\w)(\w+)(?![\w\':])', r'"\1"', s)
        return s

    # Preprocess the input string
    processed_string = preprocess_string(sample_string)

    # Parse the string into a Python data structure
    data_structure = ast.literal_eval(processed_string)
    return data_structure

def order_modules_by_week( outline_df, prefix=None, postfix=None, include_weeks=None, exclude_weeks=None):
    """ Return a list of properly ordered modules for processing """
    filtered_df = outline_df[ (outline_df["WK"] != '') & (outline_df["Module"] != '')]
    weeks = [ i for i in filtered_df["WK"].unique() if i != "" ]
    logger.debug( weeks )
    complete_list = weeks
    if not prefix is None:
        complete_list = prefix + complete_list
    if not postfix is None:
        complete_list = complete_list + postfix
    if not include_weeks is None:
        return_list = []
        for item in include_weeks:
            if item in complete_list:
                return_list.append( item )
    elif not exclude_weeks is None:
        return_list = complete_list
        for item in exclude_weeks:
            if item in return_list:
                return_list.remove( item )
    else:
        return_list = complete_list

    return return_list


#    weeks sorted( [ i for i in outline_df["WK"].unique() if i != ""]

def set_logger( log_level="DEBUG" ):
    """ Set logger with different messages for different levels """

    default_format = "<green>{time:YYYY-MM-DD HH:mm:ss.SSS}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>"
    simple_format = "{message}"

    simple_levels = ["INFO","SUCCESS","WARNING"]

    log_levels = [level.name for level in logger._core.levels.values() if level.no >= logger.level(log_level).no and not level.name in simple_levels ]

    # Remove the default logger configuration
    logger.remove()

    logger.add(sys.stderr, format=default_format, level=log_level, filter=lambda record: record["level"].name in log_levels)

    # this code is written out because of a bug in logger.add
    if "INFO" in simple_levels and logger.level(log_level).no <= logger.level("INFO").no:
        logger.add(sys.stderr, format=simple_format, level='INFO', filter=lambda record: record["level"].name=='INFO' )
    if "SUCCESS" in simple_levels and logger.level(log_level).no <= logger.level("SUCCESS").no:
        logger.add(sys.stderr, format=simple_format, level='SUCCESS', filter=lambda record: record["level"].name=='SUCCESS' )
    if "WARNING" in simple_levels and logger.level(log_level).no <= logger.level("WARNING").no:
        logger.add(sys.stderr, format=simple_format, level='WARNING', filter=lambda record: record["level"].name=='WARNING' )
    if "ERROR" in simple_levels and logger.level(log_level).no <= logger.level("ERROR").no:
        logger.add(sys.stderr, format=simple_format, level='ERROR', filter=lambda record: record["level"].name=='ERROR' )
    if "CRITICAL" in simple_levels and logger.level(log_level).no <= logger.level("CRITICAL").no:
        logger.add(sys.stderr, format=simple_format, level='CRITICAL', filter=lambda record: record["level"].name=='CRITICAL' )

def clean_include_lists( all, include_weeks, exclude_weeks ):
    """ process command line options and return clean lists """
    if include_weeks is None:
        include_list = None
    else:
        include_list = [x.lower() for x in include_weeks.split(",")]
    if exclude_weeks is None:
        exclude_list = None
    else:
        exclude_list = [x.lower() for x in exclude_weeks.split(",")]
    if all:
        include_list=None
        exclude_list=None
    if isinstance( include_list, list ):
        if "all" in include_list:
            all = True
            include_list = None
    return all, include_list, exclude_list 

def get_fp_styles( ):
    """ returns a list of frontpage/fp styles for appending into html """
    # Styles used in HTML.  Note that these CANNOT be edited once they are in Canvas.
    # Canvas deletes any styles when it opens an editor window for the page.
    lines = []
    lines.append("<style>")
    lines.append(
                """
                .fp-header-div{
                    display: flex;
                    flex-direction: column;
                    background-color: gray;
                    height:auto;
                    width:100%;
                    align-items:center;
                    justify-content:center;
                    margin:0;
                    padding:0;
                }

                .fp-header-div-current{
                    display: flex;
                    flex-direction: column;
                    background-color: dodgerblue;
                    height:auto;
                    width:100%;
                    align-items:center;
                    justify-content:center;
                    margin:0;
                    padding:0;
                }
                .fp-header-span-first{
                    color: white; 
                    max-width:100%;
                    font-size: 36px;
                    height:44px;
                    white-space: nowrap;
                    align-items:center;
                    justify-content:center;
                    margin:0;
                    padding:0;
                }

                .fp-header-span-second{
                    color: lightgray; 
                    align-items:center;
                    justify-content:center;
                    max-width:100%;
                    margin:0;
                    padding:0;
                    padding-bottom:4px;
                }
                    
                .fp-footer-container{
                    width:100%;
                    display: flex;
                    flex-wrap: wrap;
                    flex-direction: row;
                    gap: 10px;
                    justify-content: center;
                    margin-bottom: 20px;
                    margin-left:0;
                    margin-right:0;
                    padding-left:0;
                    padding-right:0;
                    }
                .fp-footer-button-available {
                    width:60px;
                    background-color: gray;
//                        padding: 10px 20px;
                    border: 2px solid black;
                    border-radius: 5px;
                    color: white;
                    text-align: center;
                    cursor: pointer;
                    transition: background-color 0.3s;                     
                }
                .fp-footer-button-current {
                    width:60px;
                    background-color: dodgerblue;
//                        padding: 10px 20px;
                    border: 2px solid black;
                    border-radius: 5px;
                    color: white;
                    text-align: center;
                    cursor: pointer;
                    transition: background-color 0.3s;                     
                }

                .fp-footer-button-available:hover {
                    background-color:darkgray;
                }
                .fp-footer-button-available a {
                    color:white;
                    text-decoration:none;
                }

                .fp-footer-button-current:hover {
                    background-color:darkgray;
                }
                .fp-footer-button-current a {
                    color:white;
                    text-decoration:none;
                }
                .fp-footer-button-notavailable {
                    width:60px;
                    background-color: lightgray;
//                        padding: 10px 20px;
                    border: 2px solid black;
                    border-radius: 5px;
                    color: white;
                    text-align: center;
                    cursor: pointer;
                    transition: background-color 0.3s;                     
                }
                .fp-footer-button-text {
                    font-size: 22px;
                }
                @media (max-width:900px) {  // these don't work in Canvas!
                    .fp-header-span-second {
                        display: none;
                        color: yellow;
                    }
                }
                .fp-test-placeholder {
                    color:red;
                }

                .fp-content {
                    display: flex;
                    flex-direction: row;
                }

                .fp-wiki-page {
                    display: flex;
                    flex: 1;
                    flex-direction: column;
                }

                .fp-right-side-placeholder {
                    width:288px;
                }
                .fp-left-side-placeholder {
                    background-color:green;
                    flex: 1;
                    border: 1px solid black;
                }

                .fp-body-container{
                    width:100%;
                    display: flex;
                    flex-wrap: wrap;
                    flex-direction: row;
                    gap: 3%;
                    justify-content: center;
                    //padding-left: 4%; 
                    //padding-right: 4%;
                }

                .fp-body-3column{
                    flex: 1;
                    word-wrap: break-word;
                    width: 27%;
                    max-width: 27%;
                    //border: 1px solid black;
                    padding-left: 10px;
                    padding-right: 10px;
                }
                .fp-body-2column{
                    flex: 1;
                    word-wrap: break-word;
                    width: 44%;
                    max-width: 44%;
                    //border: 1px solid black;
                    padding-left: 10px;
                    padding-right: 10px;
                }
                .fp-body-1column{
                    flex: 1;
                    word-wrap: break-word;
                    width: 60%;
                    max-width: 60%;
                    //border: 1px solid black;
                    padding-left: 10px;
                    padding-right: 10px;
                }
                .fp-body-details{
                    flex: 1;
                    word-wrap: break-word;
                    width: 95%;
                    max-width: 95%;
                    //border: 1px solid black;
                    margin-top: 0px;
                    margin-top: 0px;
                    padding-top:0px;
                    padding-bottom:0px;
                    padding-left: 10px;
                    padding-right: 10px;
                }

                .fp-hr-div{
                    //border: 1px solid black;
                    margin-bottom: -20px;
                    margin-top: -15px;
                    padding-bottom: 0px;
                }

                
                .fp-row-container {
                    display: flex;
                    width: 100%;
                    margin:0;
                    padding:0;
                    align-items:center;
                }

                .fp-row-item {
                    margin:0;
                    passing:0;
                }

                .left {
                    width: 120px;
                    justify-content: flex-end;
                    text-align:center;
                }
                .right {
                    width: 120px;
                    justify-content: flex-start;
                    text-align: center;
                }

                .center {
                    flex-grow: 1; /* This makes the center cell take up the remaining space */
//                        background-color: lightgray; /* Just for visual differentiation */
                }
                
                """)
                
    lines.append("</style>")
    return lines
