""" docstring for cmd_template
"""
import os
import re
import json
import click

from loguru import logger
import markdown
import pandas as pd

from cnvsapi.utils import as_pretty_json
from cnvsapi.config import config, DEFAULT_LOG_LEVEL,ENV_TOKEN_NAME


@click.group(invoke_without_command=True)
@click.pass_context
def cli(ctx):
    """ Remove canvas objects and components.
    
    Nothing gets removed unless/until the --confirm switch is included on the command line!

    """    
    if ctx.invoked_subcommand is None:
        course = config.get_default_course()
        print(f"Default course id: {config.course_id} / {course["sis_course_id"]}")
        click.echo(ctx.get_help())


@cli.command()
@click.option("--confirm",help="Include this flag to remove.",is_flag=True, default=False)
@click.pass_context
def calendar_events_from_canvas( ctx, confirm ):
    """ Remove events from canvas course. """
    count = config.delete_calendar_events( confirm )
    if confirm:
        if count==1:
            click.echo(f"{count} calendar event deleted.")
        else:
            click.echo(f"{count} calendar events deleted.")
    elif( count > 0 ):
        click.echo(f"Use --confirm to remove these calendar events from course.")
    else:
        click.echo(f"Nothing to remove.")

@cli.command()
@click.option("--confirm",help="Include this flag to remove.",is_flag=True, default=False)
@click.pass_context
def modules_from_canvas( ctx, confirm ):
    """ Remove modules from canvas course.
    """  
    count = config.delete_modules( confirm )
    if confirm:
        if count==1:
            click.echo(f"{count} item deleted.")
        else:
            click.echo(f"{count} items deleted.")
    elif( count > 0 ):
        click.echo(f"Use --confirm to remove these items from course.")
    else:
        click.echo(f"Nothing to remove.")

def parse_names(ctx, param, value):
    if value:
        return [name.strip() for name in value.split(',')]
    return []


@cli.command()
@click.option("--confirm",help="Include this flag to remove.",is_flag=True, default=False)
@click.option("--with-words",callback=parse_names, help="List of words in URL.",default=None)
@click.option("--all", help="Delete all pages",default=False, is_flag=True)
@click.pass_context
def pages_from_canvas( ctx, confirm,with_words, all ):
    """ Remove pages from canvas course.
    """
    logger.debug( with_words )
    count = config.delete_pages( confirm, with_words=with_words, all=all )
    if confirm:
        if count==1:
            click.echo(f"{count} item deleted.")
        else:
            click.echo(f"{count} items deleted.")
    elif( count > 0 ):
        click.echo(f"Use --confirm to remove these items from course.")
    else:
        click.echo(f"Nothing to remove.")

@cli.command()
@click.option("--confirm",help="Include this flag to remove.",is_flag=True, default=False)
@click.pass_context
def assignments_from_canvas( ctx, confirm ):
    """ Remove assignments (homeworks) from canvas course.
    """  
    count = config.delete_assignments( confirm )
    if confirm:
        if count==1:
            click.echo(f"{count} item deleted.")
        else:
            click.echo(f"{count} items deleted.")
    elif( count > 0 ):
        click.echo(f"Use --confirm to remove these items from course.")
    else:
        click.echo(f"Nothing to remove.")

@cli.command()
@click.option("--confirm",help="Include this flag to remove.",is_flag=True, default=False)
@click.pass_context
def syllabus_from_canvas( ctx, confirm ):
    """ Remove syllabus gdoc connection 
    """  
    count = config.delete_syllabus( confirm )
    if confirm:
        if count==1:
            click.echo(f"{count} item deleted.")
        else:
            click.echo(f"{count} items deleted.")
    elif( count > 0 ):
        click.echo(f"Use --confirm to remove these items from course.")
    else:
        click.echo(f"Nothing to remove.")

if (0):
    @cli.command()
    @click.option("--confirm",help="Include this flag to remove.",is_flag=True, default=False)
    @click.pass_context
    def all_canvas_items( ctx, confirm ):
        """ Remove modules, pages, events and assignments.
        """  
        count_syllabus = config.delete_syllabus( confirm )
        count_modules = config.delete_modules( confirm )
        count_pages = config.delete_pages( confirm )
        count_events = config.delete_calendar_events( confirm )
        count = count_modules + count_pages +  count_events
        if confirm:
            if count==1:
                click.echo(f"{count} item deleted.")
            else:
                click.echo(f"{count} items deleted.")
        elif( count > 0 ):
            click.echo(f"Use --confirm to remove these items from course.")
        else:
            click.echo(f"Nothing to remove.")

if __name__ == '__main__':
    cli(obj={})


