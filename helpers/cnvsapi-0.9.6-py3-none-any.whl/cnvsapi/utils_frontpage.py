"""
utilities from building FrontPages
"""
import re
import sys
from loguru import logger
from cnvsapi.config import config
from cnvsapi.utils import as_pretty_json, extract_id, module_prefix_from_id, find_page_in_pages, \
    order_modules_by_week, get_frontpage_title, get_overview_title, get_details_title, find_assignment_in_assignments, get_fp_styles, \
    get_title


def front_page_html( week_id,
                    overview_df,
                    pages,
                    course_subj_and_num='CMSC 408',
                    week_title="Week Title (usually Week [week_id] - [module name from outline] )",
                    week_subtitle="Week Subtitle ( like 1/13-1/20 - [module name from outline])",
                    overview="overview string (pulled from Overviews tab in workbook)",
                    deliverables = [{'name':'name','url':'https:www.google.com'},{'name':'name','url':'https:www.google.com'}],
                    lectures = [{'name':'lecture 1','url':'https:www.google.com'},{'name':'lecture 2','url':'https:www.google.com'}],
                    resources = [{'name':'resource 1','url':'https:www.google.com'},{'name':'resource 2','url':'https:www.google.com'}],
                    details="details string (pulled from details canvas page)",
                    current_week=0,
                    additional_weeks_to_show=99
                     ):
    """ return html for dropping into canvas body """


    def get_header(dp_title=week_title,dp_subtitle=week_subtitle,
                   dp_header_style="dp-circle-left variation-2",dp_header_level="H2",
                   dp_pre_1=course_subj_and_num,dp_pre_2=""):
        header = f"""
            <header class="dp-header {dp_header_style}">
                <{dp_header_level} class="dp-heading">
                    <span class="dp-header-pre">
                        {f'<span class="dp-header-pre-1">{dp_pre_1}</span>' if not dp_pre_1=="" else ""}
                        {f'<span class="dp-header-pre-2">{dp_pre_2}</span>' if not dp_pre_2=="" else ""}
                    </span>
                <span class="dp-header-title">{dp_title}</span>
                </{dp_header_level}>
                {f'<p class="dp-header-subtitle">{dp_subtitle}</p>' if not dp_subtitle=="" else ""}
                {f'<div class="dp-header-description"><p>{overview}</p></div>' if overview else ""}
            </header>
            """
        return header
    
    def get_list_of_links_and_urls( url_list ):
        """ returns a string of <ul> and <li>s for a list of name/url pairs """
        s = []
        s.append("<ul>")
        for i,item in enumerate( url_list ):
            s.append( f'<li><a href="{item["url"]}">{item["name"]}</a></li>' )
        s.append("</ul>")
        return "\n".join( s )
    
    def get_paragraphs( items ):
        """ returns a string of paragraphs """
        s = []
        for i,para in enumerate(items):
            s.append( f'<p>{para}</p>')
        return "\n".join( s )

    def get_row_of_links():
        row = f"""
            <div class="dp-column-container container-fluid">
                <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-12">
                        <h3>Deliverables</h3>
                        { get_list_of_links_and_urls( deliverables ) if deliverables else "<p>No deliverables this week</p>" }
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-12">
                        <h3>Lectures</h3>
                        { get_list_of_links_and_urls( lectures ) if lectures else "<p>No lectures this week</p>" }
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-12">
                      <h3>Resources</h3>
                        { get_list_of_links_and_urls( resources ) if resources else "<p>No resources this week</p>" }
                    </div>
                </div>
            </div>
        """
        return row

    def get_hr():
        hr = f'<hr class="dp-hr-solid-light dp-hr-color-dp-secondary w-100" />'
        return hr

    def get_gantt():
        hr = get_hr()
        gantt_url = config.frontpage_gantt_url
        gantt_height = config.frontpage_gantt_height
        gantt_height = gantt_height if gantt_height else 480

        if gantt_url:
            gantt = f"""
{hr}
<iframe width=100% height={gantt_height}
src="{gantt_url}"
></iframe>
"""
        return gantt

    def get_body():
        return details

    dp_header_body = "body text"
    header = get_header()
    row = get_row_of_links()
    hr = get_hr()
    body = get_body()
    gantt = get_gantt()
    quick_links = get_quick_links( pages, overview_df, week_id, current_week, additional_weeks_to_show )
    lines = f"""
    <div id="dp-wrapper" class="dp-wrapper">
        {header}
        {quick_links}
        {row}
        {hr}
        {body}
        {gantt}
    </div>
    """
    return lines    


def frontpage_from_block( week_id, week_name, block, current_week, pages, modules, additional_weeks_to_show ):
    """ main switch between different front page styles """

    frontpage_style = "design_plus"
#    frontpage_style = "original"

    # gather html lines depending on frontpage style
    lines = ""

    logger.debug( frontpage_style )
    logger.debug( week_id )
    logger.debug( current_week )
    logger.debug( week_name )
#    logger.debug( as_pretty_json( modules ) )
    logger.debug( as_pretty_json(block) )

    cnt = week_name.count("-")
    if cnt > 1:
        [week,days,topic] = week_name.split("-",2)
        week_title = f"{week} - {topic}"
        week_subtitle = f"{days} - {topic}"
    else:
        week_title = week_name
        week_subtitle = week_name

    course_subj_and_num = "CMSC 408"

    if frontpage_style == "original":
        lines = frontpage_from_block_original( week_id, week_name, block, current_week, pages, modules, additional_weeks_to_show )
    elif frontpage_style == "design_plus":
        lines = frontpage_from_block_designplus(  course_subj_and_num, week_title, week_subtitle, block, current_week, pages, modules, additional_weeks_to_show )

    # return single string of html codes for use in canvas page body
    return lines

def frontpage_from_block_designplus( course_subj_and_num, week_title, week_subtitle, block, current_week, pages, modules, additional_weeks_to_show ):
    """ create designplus-based front page"""

    def clean_overview( html ):
        match = re.search(r'<link[^>]*>.*?<p>(.*?)</p>.*?<script', html, re.DOTALL)
        if match:
            logger.debug( match.group(1).strip() )
            return match.group(1).strip()
        return html

    def get_header(dp_title=week_title,dp_subtitle=week_subtitle,
                   dp_header_style="dp-circle-left variation-2",dp_header_level="H2",
                   dp_pre_1=course_subj_and_num,dp_pre_2=""):
        header = f"""
            <header class="dp-header {dp_header_style}">
                <{dp_header_level} class="dp-heading">
                    <span class="dp-header-pre">
                        {f'<span class="dp-header-pre-1">{dp_pre_1}</span>' if not dp_pre_1=="" else ""}
                        {f'<span class="dp-header-pre-2">{dp_pre_2}</span>' if not dp_pre_2=="" else ""}
                    </span>
                <span class="dp-header-title">{dp_title}</span>
                </{dp_header_level}>
                {f'<p class="dp-header-subtitle">{dp_subtitle}</p>' if not dp_subtitle=="" else ""}
                {f'<div class="dp-header-description"><p>{clean_overview(block["overview"][1])}</p></div>' if "overview" in block.keys() else ""}
            </header>
            """
        return header

    def get_row_of_links():
        row = f"""
            <div class="dp-column-container container-fluid">
                <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-12">
                        { "\n".join(block["deliverables"]) if "deliverables" in block.keys() else "<h3>Deliverables</h3><p>No deliverables this week</p>" }
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-12">
                        { "\n".join(block["lectures"]) if "lectures" in block.keys() else "<h3>Lectures</h3><p>No lectures this week</p>" }
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-12">
                        { "\n".join(block["resources"]) if "resources" in block.keys() else "<h3>Resources</h3><p>No resources this week</p>" }
                    </div>
                </div>
            </div>
        """
        return row

    def get_hr():
        hr = f'<hr class="dp-hr-solid-light dp-hr-color-dp-secondary w-100" />'
        return hr

    def get_details():
        details = "\n".join(block["details"]) if "details" in block.keys() else ""
        return details

    def get_gantt():
        hr = get_hr()
        gantt = f"""
        {hr}
        <!-- GANTT: "https://lowkeylabs.github.io/cmsc408-course-admin/fa2024/weekly-gantts_files/figure-commonmark/mermaid-figure-2.png" -->
        <img
          src="https://lowkeylabs.github.io/cmsc408-course-admin/fa2024/weekly-gantts_files/figure-commonmark/mermaid-figure-2.png'"
          alt="Gantt chart for week 17"
        >
        """
        gantt=""
        return gantt

    dp_header_body = "body text"
    header = get_header()
    row = get_row_of_links()
    hr = get_hr()
    details = get_details()
    gantt = get_gantt()
    week_id = 0
    quick_links = get_quick_links( pages, modules, week_id, current_week, additional_weeks_to_show )
    lines = f"""
    <div id="dp-wrapper" class="dp-wrapper">
        {header}
        {quick_links}
        {row}
        {hr}
        {details}
        {gantt}
    </div>
    """
    logger.debug( lines )
    return lines


def get_quick_links( pages, overview_df, week_id, current_week, additional_weeks_to_show ):
    """ returns quick link buttons to other front pages """

    def get_course_home_url( url_string ):
        """ Given a Canvas page URL return the course home URL """
        # example: url_string = "https://virginiacommonwealth.instructure.com/courses/93957/pages/front-page-week-3-3"
        # Split the URL string by "/" to create a list of parts
        url_parts = url_string.split("/")
        # Remove the last two parts from the list
        url_parts = url_parts[:-2]
        # Join the remaining parts to create the modified URL
        modified_url = "/".join(url_parts)
        return modified_url
    
    def find_key_and_page( title ):
        """ return the key and page object given a page title """
        # This routine scans the local pages variable
        page = None
        for key, value in pages.items():
            if ('title' in value) and (value['title'].lower() == title.lower()):
                page = value
                break
        if page is None:
            key = None
        return key, page

    #button_names = [ extract_id(modules[module_id]['name']) for module_id in modules.keys() if modules[module_id]['published'] ]
    #button_ids = [ module_id for module_id in modules.keys() if modules[module_id]['published'] ]

    buttons = [ {'name':row['week_id']} for row_id,row in overview_df.iterrows() if not row['publish'].lower()=='n' ]
    buttons = [ {**item,'index':i,'frontpage_title':get_title('frontpage',item['name'])} for i,item in enumerate( buttons )]


    for i,button in enumerate(buttons):
#        key,page = find_key_and_page( button["frontpage_title"])
        page = find_page_in_pages( pages, button['frontpage_title'])
        if page:
            frontpage_url = page["html_url"]
            if current_week == i:
                frontpage_url = get_course_home_url( frontpage_url )
        else:
            logger.warning(f"Page not found: {button['frontpage_title']}")
            frontpage_url = ""
        button["frontpage_url"] = frontpage_url

    for i,button in enumerate(buttons):
        button["tag"] = ""
        if i <= current_week + additional_weeks_to_show:
            button["tag"] = f'<a class="btn btn-sm btn-outline-dp-secondary" href="{button["frontpage_url"]}">{button["name"]}</a>'

        if button["name"].lower()==week_id.lower():
            button["tag"] = f'<a class="btn btn-sm btn-dp-primary" href="{button["frontpage_url"]}">{button["name"]}</a>'
        elif button["name"].lower()==str(current_week).lower():
            button["tag"] = f'<a class="btn btn-sm btn-dp-gray" href="{button["frontpage_url"]}">{button["name"]}</a>'
        elif current_week==0 and i==0:
            button["tag"] = f'<a class="btn btn-sm btn-dp-gray" href="{button["frontpage_url"]}">{button["name"]}</a>'

# btn-dp-primary
# btn-outline-dp-secondary

    logger.trace( buttons )

    quick_links = "\n".join( [button["tag"] for button in buttons if not button["tag"]=="" ])
    quick_links = f"""
    <div class="d-flex justify-content-center">
    {quick_links}
    </div>
    """
    return quick_links

def frontpage_from_block_original( week_id, week_name, block, current_week, pages, modules, additional_weeks_to_show ):
    """
    Create the frontpage layout using contents of dictionary `block`
    
    returns:
        an array of lines
    """

    def get_course_home_url( url_string ):
        """ Given a Canvas page URL return the course home URL """
        # example: url_string = "https://virginiacommonwealth.instructure.com/courses/93957/pages/front-page-week-3-3"
        # Split the URL string by "/" to create a list of parts
        url_parts = url_string.split("/")
        # Remove the last two parts from the list
        url_parts = url_parts[:-2]
        # Join the remaining parts to create the modified URL
        modified_url = "/".join(url_parts)
        return modified_url
    
    def find_key_and_page( title ):
        """ return the key and page object given a page title """
        # This routine scans the local pages variable
        logger.debug(f"{title}")
        page = None
        for key, value in pages.items():
            if ('title' in value) and (value['title'].lower() == title.lower()):
                page = value
                break
        if page is None:
            key = None
        return key, page
    
    # block contains "overview" "resource" "details" "week"

    lines = []

    # add frontpage styles.  
    lines.extend( get_fp_styles() )

    # check if this is the front page.  If so, use slightly different style
    test = week_id
    if week_id=="welcome":
        test=0
    is_front_page = str(test)==str(current_week)
    logger.debug(f"test: {test}  current_week: {current_week}  is_front_page:{is_front_page}")

    # Header

    lines.append('<div class="fp-content">')

    if (1):
        lines.append('<div class="fp-wiki-page">')

        logger.debug(f"week_id: {week_id}  current_week: {current_week}")

        # check if this is the front page.  If so, use different style
        if (1):
            if is_front_page:
                lines.append('<div class="fp-header-div-current">')
            else:
                lines.append('<div class="fp-header-div">')

            [week_name_first,week_name_end] = week_name.split("-",1)
            lines.append(f'<div class="fp-header-span-first">{week_name_first.strip()}</div>')
            lines.append(f'<div class="fp-header-span-second">{week_name_end.strip()}</div>')
            lines.append("</div>")

        # 3-column top body
        if (1):
            lines.append('<div class="fp-body-container">')
            
            # Determine how many columns
            ncol = 0
            ncol = ncol + (1 if "overview" in block.keys() else 0);
            ncol = ncol + (1 if "resources" in block.keys() else 0);
            ncol = ncol + (1 if ("lectures" in block.keys()) or ("deliverables" in block.keys()) else 0)
        
            if ncol==3:
                column_class = "fp-body-3column"
            elif ncol==2:
                column_class = "fp-body-2column"
            else:
                column_class = "fp-body-1column"
                

            # Column 1 - overview
            if "overview" in block.keys():
                lines.append(f'<div class="{column_class}">')
                lines.append( "\n".join(block["overview"]) )
                lines.append("</div>")

            # Column 2 - lectures and deliverables
            if ("lectures" in block.keys()) or ("deliverables" in block.keys()):
                lines.append(f'<div class="{column_class}">')
                if "lectures" in block.keys():
                    lines.append( "\n".join(block["lectures"]) )
                if "deliverables" in block.keys():
                    lines.append( "\n".join(block["deliverables"]) )
                lines.append("</div>")
            
            # Column 3 - resources
            if "resources" in block.keys():
                lines.append(f'<div class="{column_class}"">')
                lines.append( "\n".join(block["resources"]) )
                lines.append("</div>")

            lines.append("</div>")


        # Additional columns, in their own new row.
        
        if (1):
            lines.append('<div class="fp-body-container">')

            for key in block.keys():
                if not key in ["overview","lectures","deliverables","resources","complete","details"]:
                    logger.debug( f"key: {key}.  Number of records: {len(block[key])}")
                    # show any block that isn't empty.  That is, with more the 3 elements.  <h2></h2> and <ul> and </ul>
                    if len(block[key])>3:
                        logger.debug(block[key])
                        lines.append('<div class="fp-columnx">')
                        lines.append( "\n".join(block[key]) )
                        lines.append("</div>")

            # finish up the body and draw a horizontal rule
            lines.append("</div>")

        # Details - if the details page exists and if it has contents, then copy them here.

        if (1):
            logger.debug("processing details page!")
            if "details" in block.keys():
                if len(block["details"])>0 and not (block["details"][0]==""):
                    logger.debug(block["details"])
                    column_class = "fp-body-details"
                    lines.append("<div class='fp-hr-div'><hr/></div>")
                    lines.append('<div class="fp-body-container">')
                    lines.append(f'<div class="{column_class}">')
                    lines.append( "\n".join(block["details"]) )
                    lines.append("</div>")
                    lines.append("</div>")

        # line separator between 
        lines.append("<div><hr/></div>")

        # Footer

        lines.append('<div class="fp-row-container">')

        logger.debug(f"show_frontpage_vcr_buttons: {config.show_frontpage_vcr_buttons}")
        if config.show_frontpage_vcr_buttons:
            lines.append('<div class="fp-footer-button-available left">')
            lines.append('<span class="fp-footer-button-text">')
            #
            ### process left arrow button
            button_id = week_id
            button_names = [ extract_id(modules[module_id]['name']) for module_id in modules.keys() if modules[module_id]['published'] ]
            logger.debug( button_names )
            logger.debug( button_id )
            try:
                idx = button_names.index( button_id )
            except ValueError:
                idx = 0
            idx = idx - 1
            if idx<0:
                idx = len(button_names)-1
            button_id = button_names[idx]

            s = get_frontpage_title( module_prefix_from_id(button_id) )
            logger.debug(f"Searching for: {s}" )
            key,page = find_key_and_page( s )                    
            if not page is None:
                logger.debug(page['url'])
                front_page_url=page["html_url"]
                logger.debug(f"button_id: {button_id}  - current_week:{current_week} - idx: {idx}")
                if idx==current_week:
                    front_page_url = get_course_home_url( front_page_url )
                else:
                    pass
            

            lines.append(f'<a href="{front_page_url}"><button>&#9664;</button></a>')
#            lines.append(f'<a href="{front_page_url}">{button_id}</a>')
            lines.append('</span>')
            lines.append('</div>')

        lines.append('<div class="fp-row-item center">')

        if (1):
            lines.append('<div class="fp-footer-container">')
            
            button_names = [ extract_id(modules[module_id]['name']) for module_id in modules.keys() if modules[module_id]['published'] ]
            button_ids = [ module_id for module_id in modules.keys() if modules[module_id]['published'] ]
            logger.debug(f"button_ids: {button_names}")

            for button_id, module_id in enumerate( button_ids ):

                button_string = f"{extract_id( modules[module_id]["name"])[:3].center(3)}"
                if button_names[button_id]=="welcome":
                    button_string = " 0 "

                logger.debug(f"button_id:{button_id}  current week:{current_week}  additional_weeks:{additional_weeks_to_show}" )

                if button_id <= current_week+additional_weeks_to_show:
                    logger.trace(modules[module_id])
                    s = get_frontpage_title( module_prefix_from_id(button_id) )
                    logger.debug(f"Searching for: {s}" )
                    key,page = find_key_and_page( s )                    
                    if not page is None:
                        logger.debug(page['url'])
                        front_page_url=page["html_url"]
                        logger.debug(f"{button_id} and {current_week}")
                        if (1):
                            if button_id==current_week:
                                lines.append('<div class="fp-footer-button-current">')
                                front_page_url = get_course_home_url( front_page_url )
                            else:
                                lines.append('<div class="fp-footer-button-available">')            
                            lines.append('<span class="fp-footer-button-text">')
                            s = f'<a href="{front_page_url}">{button_string}</a>'
                            logger.debug(s)
                            lines.append(s)
                            lines.append('</span>')
                            lines.append('</div>')
                    else:
                        logger.warning(f"Missing: {s}.  Try rebuilding front pages.")
                else:
                    lines.append('<div class="fp-footer-button-notavailable">')            
                    lines.append(f'<span class="fp-footer-button-text">{button_string}</span>')
                    lines.append('</div>')

            lines.append('</div>') # fp-footer-container
            lines.append('</div>') # fp-row-item center

            if config.show_frontpage_vcr_buttons:
                lines.append('<div class="fp-footer-button-available right">')
                lines.append('<span class="fp-footer-button-text">')
                #
                ### process right arrow button
                button_id = week_id
                button_names = [ extract_id(modules[module_id]['name']) for module_id in modules.keys() if modules[module_id]['published'] ]
                logger.debug( button_names )
                logger.debug( button_id )
                try:
                    idx = button_names.index( button_id )
                except ValueError:
                    idx = 0
                idx = idx + 1
                if idx>len(button_names)-1:
                    idx = 0
                button_id = button_names[idx]

                s = get_frontpage_title( module_prefix_from_id(button_id) )
                logger.debug(f"Searching for: {s}" )
                key,page = find_key_and_page( s )                    
                if not page is None:
                    logger.debug(page['url'])
                    front_page_url=page["html_url"]
                    logger.debug(f"button_id: {button_id}  - current_week:{current_week} - idx: {idx}")
                    if idx==current_week:
                        front_page_url = get_course_home_url( front_page_url )
                    else:
                        pass
                
                    #
                lines.append(f'<a href="{front_page_url}"><button>&#9654;</button></a>')
#                lines.append(f'<a href="{front_page_url}">{button_id}</a>')
                lines.append('</span>')
                lines.append('</div>')

            lines.append('</div>') # fp-row-container
        lines.append('</div>') # fp-wiki-page
    else:
        lines.append('<div class="fp-wiki-page">')
        lines.append("<div><hr/></div>")
        lines.append('</div>')
    if not is_front_page:
        lines.append('<div class="fp-right-side-placeholder">&nbsp;</div>')

    # this is the larger wrapper    
    lines.append("</div>")
    return "\n".join(lines)

if(0):
    x = f"""
<div id="dp-wrapper" class="dp-wrapper">
    <header class="dp-header dp-circle-left variation-2">
        <h2 class="dp-heading"><span class="dp-header-pre"> <span class="dp-header-pre-1">CMSC 408</span> </span> <span class="dp-header-title">Title</span></h2>
        <p class="dp-header-subtitle">10/6 to 10/13 - Normal forms</p>
        <div class="dp-header-description">
            <p>overview goes here</p>
        </div>
    </header>
    <div class="dp-column-container container-fluid">
        <div class="row">
            <div class="d-flex flex-row justify-content-start align-items-start text-start col-lg-4 col-md-4 col-sm-12">
                <div class="dp-column-liner w-100">
                    <h3>Column 1</h3>
                    <ul id="" class="">
                        <li class="">Contentx</li>
                    </ul>
                </div>
            </div>
            <div class="d-flex flex-row justify-content-start align-items-start text-start col-lg-4 col-md-4 col-sm-12">
                <div class="dp-column-liner w-100">
                    <h3>Column 2</h3>
                    <ul id="" class="">
                        <li class="">Contenty</li>
                    </ul>
                </div>
            </div>
            <div class="d-flex flex-row justify-content-start align-items-start text-start col-lg-4 col-md-4 col-sm-12">
                <div class="dp-column-liner w-100">
                    <h3>Column 3</h3>
                    <ul id="" class="">
                        <li class="">Contentz</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <hr class="dp-hr-solid-light dp-hr-color-dp-secondary" />
    <div class="dp-content-block">
        <h3>Content Block Heading</h3>
        <p>Content</p>
    </div>
    <p>&nbsp;</p>
</div>
"""
    