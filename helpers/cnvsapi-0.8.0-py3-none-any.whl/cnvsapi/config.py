""" Config - module for configuration
"""
import os
import re
import sys
import json
import click
import keyring
import keyring.errors
import keyrings.alt.file
import tomlkit
import argparse
import pandas as pd
import keyring.util.platform_ as keyring_platform

from loguru import logger
from canvasapi import Canvas
from datetime import date,datetime

from cnvsapi.utils import find_config_file,as_pretty_json, set_logger

program_name = os.path.splitext(os.path.basename( sys.argv[0] ))[0].lower()
program_name = "cnvsapi"

config_file_name = "." + (program_name).lower()

ENV_CONFIG = program_name.upper()
ENV_LOG_LEVEL = program_name+"_LOG_LEVEL"
ENV_TOKEN_NAME = "CANVAS_API_TOKEN"

# Values: "TRACE", "DEBUG", "INFO", "SUCCESS", "WARNING", "ERROR", "CRITICAL"
DEFAULT_LOG_LEVEL = 'SUCCESS'
DEFAULT_SPLIT_CODE = "::"


def sniff_log_level():
    """ take early look at command line, setting log_level as early as possible """
    # disable help, parse only known arguments.  You're sniffing early!
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('--log-level', type=str)

    args, unknown = parser.parse_known_args()
    log_level = args.log_level
    return log_level


logger.remove()
early_log_level = sniff_log_level()
if early_log_level is None:
    early_log_level=DEFAULT_LOG_LEVEL

set_logger( early_log_level )

if not early_log_level==DEFAULT_LOG_LEVEL:
    logger.success(f"Log level set to {early_log_level} by --log-level argument (early).")

plugin_folder = os.path.join(os.path.dirname(__file__))

DEFAULT_ATTRIBUTES = {
    "course_attributes" : {
        "outline_gsheet_key":{"missing_key_string":f"<Add gsheet ID for outline in {config_file_name}>"},
        "outline_google_folder":{"missing_key_string":f"<Add google folder ID containing outline in {config_file_name}>"},
        "syllabus_gdoc_key":{"missing_key_string":f"<Add google doc ID for syllabus in {config_file_name}>"},
        "syllabus_course_summary":{"missing_key_string":f"True"},
        "lecture_slides_template":{"missing_key_string":f"<Add filename for lecture template in {config_file_name}>"},
        "lecture_slides_endpoint":{"missing_key_string":f"<Add URL for lecture slide endpoint in {config_file_name}>"},
        "frontpage_additional_weeks":{"missing_key_string":f"<Weeks to show (99 to show all!) {config_file_name}>"},
        "zoom_lecture_url":{"missing_key_string":f"<Zoom URL for lectures. Add to {config_file_name}>"},
        "show_frontpage_vcr_buttons":{"missing_key_string":f"<True to show VCR left-right buttons on frontpage. Add to {config_file_name}>"},
        "use_outline_lectures_tab":{"missing_key_string":f"<True to use Lectures tab for lecture-slide contents. Add to {config_file_name}>"},
    },
}

class MyEnvCryptFileKeyring(keyrings.alt.file.EncryptedKeyring):
    def get_password(self, service, username):
        # Set the password from the environment variable
        password = os.getenv('CNVSAPI_KEYRING_PASSWORD')
        if not password:
            raise ValueError("Environment variable 'CNVSAPI_KEYRING_PASSWORD' not set.")
        #self._password = password
        self.keyring_key = password
        return super().get_password(service, username)
    
    
def set_keyring_backend():
    if os.name == 'nt':
#        raise EnvironmentError("This script is intended to be run on Linux (including WSL).")
        pass
    else:
        os.environ['CNVSAPI_KEYRING_PASSWORD'] = 'password'
        try:
            # Try to set CryptFileKeyring
            keyring.set_keyring(MyEnvCryptFileKeyring())
            logger.info("Using CryptFileKeyring")
        except Exception as e:
            logger.warning(f"Failed to set CryptFileKeyring: {e}")
            logger.warning("Falling back to PlaintextKeyring (not secure for production use).")
            keyring.set_keyring(keyrings.alt.file.PlaintextKeyring())

class Configuration:
    config = tomlkit.document()
    config_file = find_config_file( config_file_name )

    def __init__( self ):
        set_keyring_backend()
        self.config = tomlkit.document()

        if not os.path.exists( self.config_file ):
            logger.info(f"Creating internal configuration: {config_file_name}")
            self.config = tomlkit.loads(f"""# {program_name} config file ({config_file_name}). Auto-created: {date.today()}

# This is a strictly formatted TOML file. It contains configuration values for this 
# program. Highest level paramters control application run-time. Subsequent sections 
# contain parameters for services that interact with this program.
                                        
# Log_level: used for watching execution.  This tool uses loguru.
# Values: "TRACE", "DEBUG", "INFO", "SUCCESS", "WARNING", "ERROR", "CRITICAL"
# Default: "{DEFAULT_LOG_LEVEL}"
                                        
[application]
# Application configuration variables

log_level = "{DEFAULT_LOG_LEVEL}"
default_split_code = "{DEFAULT_SPLIT_CODE}"

[images]
# This is where VCU stores headshops.  Add a V###.jpg to complete the URL.
headshot_endpoint = "https://sasbimid2.vcu.edu/images"

[canvas]
# Campus default values for Canvas
# High level web address of campus canvas server

endpoint = "https://virginiacommonwealth.instructure.com"

[lecture]
default_qmd_template = "template0"
template0 = "template-lecture-0.qmd"
template0_extras = ['template-lecture-housekeeping.qmd','_quarto.yml','lectures.scss']
template1 = "template-lecture-0.qmd"
template1_folder = "C:/Users/jdleonard/Projects/ssg-canvas-cli/templates"
template1_extras = ['template-lecture-housekeeping.qmd','_quarto.yml','_extensions','assets']


[roster]
default_qmd_template = "template0"
template0 = "template-roster-0.qmd"

[assessment.rubric]
default = "report1"

[assessment.rubric.report1.assignment_group]
name = "ag_name"
[assessment.rubric.report1.assignment]
name = "assign_name"
[assessment.rubric.report1.user]
sortable_name = "sortable name"
sis_user_id = "VID"
[assessment.rubric.report1.rubric]
description = "Rubric description"
points = "total points"
[assessment.rubric.report1.rating]
description = "user description"
points = "user score"

[keyring]
# keyring is a local computer secure storage system leveraging tools from
# the local OS. Keyring works on windows, linux and mac.
# See: https://pypi.org/project/keyring/

# Namespace and entry are used with "keyring" to store canvas token in local
# computer secure password storage. Don't mess with these, they were carefully
# selected to work across all windows, linux, and mac platforms.

namespace = "cmsc-vcu-course-tools-api"
entry = "{ENV_TOKEN_NAME}"

[user_courses]
# this is a list of course available to the current user.
# Freshen this list with cnvsapi list courses --add-to-config
00000 = "Dummy course"


[course]
# this is the default course id.  Select from list above.


[course.00000]
# here is an example of the config information for a specific course
outline_gsheet_key = "1Ht4N1hxCj4SIyggCJg3xTtqmYJwMbgHbSQXeVBqEIDQ"
outline_google_folder = "1C-ZoZjMOefov00WoYVMJiCe4Avw8zg6c"
lecture_slides_endpoint = "https://lowkeylabs.github.io/cmsc408-fa2024-admin/lectures/"
syllabus_course_summary = true
lecture_slides_template = "template-lecture-0.qmd"
syllabus_gdoc_key = "1Ts04YflffdnW95O4YWCQTnY7VFZW40OiShb0tXY0bPU"
frontpage_additional_weeks=99
zoom_lecture_url="https://vcu.zoom.us"
show_frontpage_vcr_buttons = false
use_outline_lectures_tab = false

""")
            logger.debug("getting courses")
            courses = self.get_courses()
            logger.trace( as_pretty_json(courses) )
            comments = ""
            # hard code course ID check for this part of the config load.
            if (0):
                course_id=-1
                if "course" in self.config.keys():
                    if "course_id" in self.config["course"].keys():
                        course_id=self.config["course"]["course_id"]
                for id in courses.keys():
                    line = f"{'' if id==course_id else '# '}course_id={id:<8d} #  {courses[id]['name']}"
                # comments = comments + "\n" + line

            comments = comments + f"""


"""
            #self.addCourseComments( comments )

            if (0):
                logger.success(f"New configuration saved to: {self.config_file_name}")
                self.save()

#            if click.confirm(f"Create {config_file_name} config file in this folder?",err=True):
#                logger.info(f"User selected to save config file: {config_file_name}")
#                self.save()
#            else:
#                logger.info("User chose to NOT save config file.")
        else:
            logger.info(f"Loading config file: {self.config_file}")
            try:
                with open(self.config_file, 'r') as file:
                    self.config = tomlkit.loads(file.read())
            except Exception as e:
                logger.warning(f"\nError reading config file: \"{self.config_file}\" during startup.")
                logger.warning("-->",str(e))
                logger.warning("Edit the file and try again")
                sys.exit(1)
        
        # we've got a create self.config is is (or isn't) saved. Doesn't matter - it's in memory!

        if "application" not in self.config.keys():
            self["application"]["log_level"] = DEFAULT_LOG_LEVEL
        if "log_level" in self.config['application'].keys():
            set_logger( self.config["application"]["log_level"] )
            logger.info(f"Log level set to {self.config['application']['log_level']} by {self.config_file}")

        if self.token is None:
            logger.warning(f"""\nWARNING - {ENV_TOKEN_NAME} not found in environment or keyring.
You'll need a token from canvas to access the API using this program.
Visit: https://virginiacommonwealth.instructure.com/profile/settings  to get an API token.
Store the token using:
  cnvsapi token --canvas-api-token="<your token inside the double-quotes>"
""")

#            sys.exit(1)
    
    def serialize(self, file_path):
        with open(file_path, 'w') as file:
            file.write(tomlkit.dumps(self.config))

    def save( self ):
        logger.debug("Saving configuration")
        self.serialize( self.config_file )

    def reload( self ):
        if os.path.exists( self.config_file ):
            logger.info(f"Reloading {config_file_name}")
            try:
                with open(self.config_file, 'r') as file:
                    self.config = tomlkit.loads(file.read())
            except Exception as e:
                logger.warning(f"\nError reading config file: \"{self.config_file}\" during startup.")
                logger.warning("-->",str(e))
                logger.warning("Edit the file and try again")
                sys.exit(1)

    def createOrReplace(self,key,item ):
        if key in self.config.keys():
            self.config[key] = item
        else:
            self.config.add(key,item)

    def addCourseComments(self,comments):
        tab = tomlkit.table()
        header = """
# Course contains a list of potential courses that this canvas user
# can connect.  Use "cnvsapi courses --add-to-config" to freshen this section.
# Once freshened, the user should uncomment one of the courses to serve
# as default for further operations.
        """
        if "course" in self.config:
            tab = self.config["course"]
        tab.comment(f"{header}{comments}")
        self.createOrReplace("course",tab)

    @property
    def course_id( self ):
        missing_value_string = "<edit me, uncomment course_id above>"
        value = None
        if "course" in self.config.keys():
            if "course_id" in self.config["course"].keys():
                value = self.config["course"]["course_id"]
                if value==missing_value_string:
                    value = None
#        if value==None:
#            click.echo(f"Missing default course id. Edit {self.config_file_name}")
#            if not "course" in self.config.keys():
#                self.config["course"] = {}
#            if not "course_id" in self.config["course"].keys():
#                self.config["course"]["course_id"] = missing_value_string
#            self.save()
#            sys.exit(1)
        return value

    @course_id.setter
    def course_id( self, course_id ):
        if not "course" in self.config.keys():
            self.config["course"] = {}
        self.config["course"]["course_id"] = course_id

        # force creation of default attributes for current file
        # Nothing gets saved. The calling routine must manage saving.  This minimizes
        # creation of unneccesary config files.
        
        for key in DEFAULT_ATTRIBUTES['course_attributes'].keys():
            config.get_course_attribute(key)



    def get_canvas( self ):
        namespace = self.namespace
        token = keyring.get_password( namespace, self.config["keyring"]["entry"] )
        result = Canvas( self.config["canvas"]["endpoint"], token )
        return result

    def remove_html_tags(self,text):
        """ Clean a string of HTML chars from Canvas """
        clean_text = re.sub('<.*?>', '', text)  # Remove HTML tags using regex
        clean_text = re.sub(r'[\x00-\x08\x0B-\x0C\x0E-\x1F\x7F-\x9F]+', '', clean_text)  # Remove HTML tags using regex
        clean_text = re.sub(r'&nbsp;', ' ', clean_text, flags=re.IGNORECASE)
        clean_text = re.sub(r'  ', ' ', clean_text)
        return clean_text


    def get_python_object( self, objects ):

        if isinstance(objects,list):
            rlist = {}
            for object in objects:
                # some objects don't use "id" field.  Page uses "url" to connect with module-items
                logger.debug(object.__class__.__name__)
                if object.__class__.__name__=="Page":
                    id = object.url
                else:
                    id = object.id
                rlist[id] = { key:getattr(object,key) for key in vars(object) if not key in ["_requester"]}
        else:
            rlist = { key:getattr(objects,key) for key in vars(objects) if not key in ["_requester"]}
        return rlist

    def get_python_object_from( self, endpoint, *args, **kwargs ):
#        if not id1 is None:
#            objects = endpoint( id1 )
#        else:
#            objects = endpoint()
#        logger.debug(f"endpoint: {endpoint} :: args: {args} :: kwargs:{kwargs}")
        if len(args)==0 and len(kwargs.keys())==0:
            objects = endpoint()
        elif len(kwargs.keys())==0:
            objects = endpoint( *args )
        elif len(args)==0:
            objects = endpoint( **kwargs )
        else:
            objects = endpoint( *args, *kwargs )
        list = {}
        for object in objects:
            # some objects don't use "id" field.  Page uses "url" to connect with module-items
 #           logger.debug(object.__class__.__name__)
            if object.__class__.__name__=="Page":
                id = object.url
            else:
                id = object.id
            try:
                list[id] = { key:getattr(object,key) for key in vars(object) if not key in ["_requester"]}
            except:
                list = object
        return list
    
    def get_default_course_endpoint( self ):
        """ Returns the default course and an error if no default is set """
        #logger.debug(f"default course: {self.course_id}")
        if self.course_id is None:
            logger.warning(f"No default course_id has been set.  Use --course-id or edit {config_file_name} ")
            sys.exit( 1 )
        return self.get_canvas().get_course( self.course_id )
    
    def get_default_course( self ):
        """ returns a dictionary of canvas courses and attributes """
        logger.debug(f"default course: {self.course_id}")
        if self.course_id is None:
            logger.warning(f"No default course_id has been set.  Use --course-id or edit {config_file_name} ")
            sys.exit( 1 )
        return self.get_courses()[self.course_id]

    def get_courses( self, include=['syllabus_body','total_students','course_image','term','concluded'] ):
        """ returns a dictionary of canvas courses and attributes """
        try:
            courses = self.get_python_object_from( self.get_canvas().get_courses, include=include )
        except Exception as e:
            courses = {}
        return courses


    def get_users( self ):
        """ returns a dictionary of canvas users for the current course """
        try:
            users = self.get_python_object_from( self.get_default_course_endpoint().get_users )
        except Exception as e:
            users = {}
        return users
    
    def get_assignment_groups( self ):
        """ returns dictionary of assignment groups for the current course """
        try:
            ag = self.get_python_object_from( self.get_default_course_endpoint().get_assignment_groups )
        except Exception as e:
            ag = {}
        return ag
    
    def get_assignments( self ):
        try:
            assignment_groups = self.get_python_object_from( self.get_default_course_endpoint().get_assignment_groups )
        except Exception as e:
            assignment_groups = {}
            return assignment_groups
        for ag in assignment_groups.values():
            ag["assignments"] = {}
        try:
            assignments = self.get_python_object_from( self.get_default_course_endpoint().get_assignments )
        except Exception as e:
            return {}
        for as_id in assignments.keys():
            assignment_groups[assignments[as_id]["assignment_group_id"]]["assignments"][as_id] = assignments[as_id]
        return assignment_groups

    def get_quizzes( self ):
        try:
            q = self.get_python_object_from( self.get_default_course_endpoint().get_quizzes )
        except Exception as e:
            q = {}
        return q

    def get_quiz( self,quiz_id ):
        try:
            q = self.get_python_object( self.get_default_course_endpoint().get_quiz( quiz_id ) )
        except Exception as e:
            q = {}
        return q

    def get_modules( self ):
        try:
            modules = self.get_python_object_from( self.get_default_course_endpoint().get_modules )
        except Exception as e:
            modules = {}
        return modules

    def get_pages( self ):
        try:
            pages = self.get_python_object_from( self.get_default_course_endpoint().get_pages )
        except Exception as e:
            pages = {}
        return pages

    def get_page( self, page_id ):
        try:
            page = self.get_python_object( self.get_default_course_endpoint().get_page( page_id ) )
        except Exception as e:
            page = {}
        return page

    def get_module_items( self, for_module_id=None ):
        def get_mi( module_id ):
            """ return list of module items for given module """
            try:
                mi = self.get_python_object_from( self.get_default_course_endpoint().get_module( module_id ).get_module_items )
            except Exception as e:
                mi = {}
            return mi
        list = {}
        if for_module_id is None:
            modules = self.get_modules()
            for module_id in modules.keys():
                logger.debug(module_id)
                list[module_id] = modules[module_id]
                list[module_id]["module_items"] = get_mi( module_id )
        else:
            logger.debug( for_module_id )
            list[for_module_id] = {}
            list[for_module_id]["module_items"] = get_mi( for_module_id )

        return list

    def get_quiz_questions( self, quiz_id ):
        qq = {}
        logger.debug(f"retrieving data for quiz: {quiz_id}")
        try:
            questions = config.get_canvas().get_course(config.course_id).get_quiz( quiz_id ).get_questions()
        except Exception as e:
            questions = {}
            return questions
        qq[quiz_id] = {}
        for question in questions:
            logger.trace(f"{question}")
            ques_id = getattr(question,"id")
            qq[quiz_id][ques_id] = {}
            q = qq[quiz_id][ques_id]
            for var in vars(question):
                q[var] = getattr(question,var)
                if var=="answers":
                    answers = q[var]
                    q['answer_dict'] = {}
                    for answer in answers:
                        q['answer_dict'][answer['id']] = answer
            q["clean_text"] = self.remove_html_tags(getattr(question,"question_text"))
        logger.trace(f"{qq}")
        return qq[quiz_id]

    def get_quiz_responses( self, quiz_id ):
        """ Return quiz questions and responses as a dataframe """
        # get quiz questions and answers
        quiz = self.get_quiz_questions( quiz_id )
        users = self.get_users()
        # get assignment_id that corresponds to current quiz. Note that
        # quiz responses are stored in the assignment structure.

#        logger.debug(f"{quiz}")

        assignment_id = getattr(config.get_canvas().get_course(config.course_id).get_quiz( quiz_id ),'assignment_id')
        logger.debug(f"Assignment id: {assignment_id}")
        # create the final dataframe
        rows = []
        headers = None
        if not assignment_id is None:
            responses = config.get_canvas().get_course(config.course_id).get_assignment(assignment_id).get_submissions(include=['submission_history'])
            for response in responses:
                user_id = getattr(response,'user_id')
                sortable_name = 'zzz test user'
                email = 'missing'
                sis_user_id = 'missing'
                if user_id in users.keys():
                    sortable_name = users[user_id]['sortable_name'] if 'sortable_name' in users[user_id].keys() else 'missing'
                    email = users[user_id]['email'] if 'email' in users[user_id].keys() else 'missing'
                    sis_user_id = users[user_id]['sis_user_id'] if 'sis_user_id' in users[user_id].keys() else 'missing'
                new_row = [sortable_name,email,sis_user_id]
                new_header = ['sortable_name','email','sis_user_id/vid']
                if hasattr(response,'submission_history'):
                    history = None
                    id = None
                    # capture the latest submission. There may be multiple submissions,
                    # we'll use the last submission.
                    for temp_id,temp_history in enumerate(getattr(response,'submission_history')):
                        history = temp_history
                        id = temp_id
                    logger.trace(history)
                    if 'submission_data' in history.keys():
                        # print submissions
                        for answer in history['submission_data']:
                            logger.trace(f"{quiz[answer['question_id']]['clean_text']}")
                            possible_answers = quiz[answer['question_id']]['answers'] 
                            for possible_answer in possible_answers:
                                if 'text' in possible_answer.keys():
                                    logger.trace(f"{possible_answer['id']}::{possible_answer['text']}")
                            if 'answer_id' in answer.keys() and answer['text']==str(answer['answer_id']):
                                answer['text'] = quiz[answer['question_id']]['answer_dict'][answer['answer_id']]['text']
                            logger.trace(f"{getattr(response,'user_id')}::{quiz[answer['question_id']]['position']}::{quiz[answer['question_id']]['clean_text']}::{answer['question_id']}::{answer['text']}")
                            new_row.append(answer['text'])
                            new_header.append(quiz[answer['question_id']]['clean_text'])
                        if headers==None:
                            headers = new_header
                    else:
                        logger.trace(f"{quiz_id}::{assignment_id}::{getattr(response,'user_id')}::'missing submission_data'")
                else:
                    logger.trace(f"{quiz_id}::{assignment_id}::{getattr(response,'user_id')}::'missing submission_history'")
                rows.append( new_row )
        df = pd.DataFrame( rows, columns=headers )
        df["count"] = 1
        return df
   
    def create_page(self,title,**kwargs):
        """ create a page using defaults """
        defaults = {"title":title,"published":False,"notify_of_update":False,"editing_roles":"teachers","front_page":False,"body":title}
        wiki_page = defaults
        wiki_page["title"] = title
        for key in defaults.keys():
            wiki_page[key] = kwargs.get(key,defaults[key])
        page = self.get_default_course_endpoint().create_page( wiki_page )
        return self.get_python_object( page )

    def edit_page(self,url,**kwargs):
        """ edit a page using defaults """
        wiki_page = {}
        for key in kwargs.keys():
            wiki_page[key] = kwargs[key]
        page = self.get_default_course_endpoint().get_page( url ).edit( wiki_page=wiki_page )
        return self.get_python_object( page )
    
    def find_page( self, title ):
        """ search for page """
        # This routine scans the local pages variable
        logger.debug(f"{title}")
        pages = self.get_pages()
        page = None
        for key, value in pages.items():
            if ('title' in value.keys()) and (value['title'].lower() == title.lower()):
                page = value
                return page
        return page

    def edit_quiz( self, quiz_id, **kwargs):
        quiz = {}
        for key in kwargs.keys():
            quiz[key] = kwargs[key]
        page = self.get_default_course_endpoint().get_quiz( quiz_id ).edit( quiz=quiz )
        return self.get_python_object( page )
    
    def edit_assignment( self, assign_id, **kwargs):
        assignment = {}
        for key in kwargs.keys():
            assignment[key] = kwargs[key]
        page = self.get_default_course_endpoint().get_assignment( assign_id ).edit( assignment=assignment )
        return self.get_python_object( page )

    def edit_module_item(self,module_id, module_item_id,**kwargs):
        """ edit a module_item using defaults """
        module_item = {}
        for key in kwargs.keys():
            module_item[key] = kwargs[key]
        mod = self.get_default_course_endpoint().get_module( module_id ).get_module_item( module_item_id ).edit( module_item=module_item )
        return self.get_python_object( mod )


    def update_course( self, **kwargs ):
        """ update course attributes. See: https://canvas.instructure.com/doc/api/courses.html#method.courses.update """
        logger.debug(f"updating course: {kwargs}")
        defaults = {}
        fields = ["default_view","syllabus_body","syllabus_course_summary"]
        course = defaults
        for key in fields:
            if key in kwargs.keys():
                course[key] = kwargs[key]
        logger.debug(f"{course}")
        try:
            value = self.get_default_course_endpoint().update( course=course )
        except:
            logger.warning(f"Exception trapped while updating frontpage.  Rerun last command - a second pass should fix it.")
        return

    def update_course_settings( self, **kwargs ):
        """ update course attributes. See: https://canvas.instructure.com/doc/api/courses.html#method.courses.update_settings """
        logger.debug(f"updating course settings: {kwargs}")
        value = self.get_default_course_endpoint().update_settings( **kwargs )
        logger.debug(f"value: {value}")
        return

    def create_event(self,ce,**kwargs):
        return self.get_python_object( self.get_canvas().create_calendar_event( ce ) )

    def create_assignment(self,title,**kwargs):
        """ create an assignment using defaults """
        defaults = {"name":title,"published":False,"notify_of_update":False,"submission_types":["online_upload"],
                    "allowed_extensions":["html"],"grading_type":"points","points_possible":10,"due_at":None,
                    "description":title,"allowed_attempts":-1}
        assignment = defaults
        for key in defaults.keys():
            assignment[key] = kwargs.get(key,defaults[key])

        # Create the assignment and return it.
        page = self.get_default_course_endpoint().create_assignment( assignment )
        return self.get_python_object( page )

    def create_quiz(self,title,**kwargs):
        """ create a quiz using defaults """
        defaults = {"title":title,"quiz_type":"assignment","shuffle_answers":True,
                    "description":title+" has not been developed.","published":False,"due_at":None,
                    "allowed_attempts":-1,"scoring_policy":"keep_highest","published":False}
        quiz = defaults
        for key in defaults.keys():
            quiz[key] = kwargs.get(key,defaults[key])

#        if "due_at" in kwargs.keys():
#            datetime_string = kwargs["due_at"]
#            datetime_object = datetime.strptime(datetime_string, "%m/%d/%Y %H:%M:%S")
#            quiz["due_at"] = datetime_object
            
        # Create the assignment and return it.
        page = self.get_default_course_endpoint().create_quiz( quiz )
        return self.get_python_object( page )


    def create_module( self, name,**kwargs ):
        defaults = {"name":name,"unlock_at":datetime(2024,6,1),"position":999,"requires_sequential_progress":False,
                    "prerequisite_module_ids":[],"publish_final_grade":False, "published":True}
        modules = self.get_modules()
        if len(modules)==0:
            last_position = 0
        else:
            last_position = max([modules[id]["position"] for id in modules.keys() ] )
        module = defaults
        module["position"] = last_position + 1
        for key in defaults.keys():
            module[key] = kwargs.get(key,defaults[key])
        m = self.get_python_object( self.get_default_course_endpoint().create_module(module) )
        logger.debug( m )
        m1 = self.get_default_course_endpoint().get_module( m["id"] )
        m1.edit( module=module )
        return self.get_python_object( m1 )

    def create_module_item( self, module_id, **kwargs ):
        defaults = {"title":"new module item","type":"Page","content_id":None,"position":0,"indent":0,"page_url":"","external_url":"","new_tab":False,
                    "completion_requirement":[],"width":640,"height":480, "published":True}
        module = self.get_default_course_endpoint().get_module( module_id )
        module_items = self.get_python_object_from( module.get_module_items )
        if len(module_items)==0:
            last_position = 0
        else:
            last_position = max( [module_items[id]["position"] for id in module_items.keys()] )
        module_item = defaults
        module_item["position"] = last_position + 1
        for key in defaults.keys():
            module_item[key] = kwargs.get(key,defaults[key])
        m =  module.create_module_item(module_item)
        m.edit( module_item=module_item )
        return self.get_python_object( m )
    
    def delete_module_item( self, module_id, item_id ):
        return self.get_default_course_endpoint().get_module( module_id ).get_module_item( item_id ).delete()
    
    def delete_rubric( self, rubric_id ):
        return self.get_python_object_from( self.get_default_course_endpoint().delete_rubric( rubric_id ) )

    def get_calendar_events( self, **kwargs ):
        logger.debug(f"{kwargs}")
        try:
            ce = self.get_python_object_from( self.get_canvas().get_calendar_events, **kwargs )
        except Exception as e:
            ce = {}
        return ce


    def delete_calendar_event( self, event_id ):
        logger.debug(f"deleting: {event_id}")
        try:
            event = self.get_canvas().get_calendar_event( event_id ).delete()
#            logger.success(f"deleting event: {event['id']}  -  {event['title']}")
        except Exception as e:
            logger.error(f"Exception: {e}")
        return
    
    
    def delete_calendar_events( self,confirm=False ):
        objects = config.get_calendar_events( type="event", all_events=True, context_codes=["course_"+str(config.course_id)] )
        for id in objects.keys():
            if confirm:
                self.delete_calendar_event( id )
                logger.success(f"deleting event: {objects[id]['id']} - {objects[id]['title']}")
            else:
                logger.success(f"event: {objects[id]['id']} - {objects[id]['title']}")
        return len( objects.keys() )


    def delete_module( self, id ):
        logger.debug(f"{id}")
        return self.get_default_course_endpoint().get_module( id ).delete()

    def delete_modules( self, confirm=False ):
        objects = config.get_modules()
        for id in objects.keys():
            if confirm:
                logger.success(f"deleting module: {objects[id]['id']}  -  {objects[id]['name']}")
                obj = self.delete_module( id )
            else:
                logger.success(f"module: {objects[id]['id']}  -  {objects[id]['name']}")
        return len( objects.keys() )

    def delete_page( self, url ):
        try:
            page = self.get_default_course_endpoint().get_page( url )
            logger.debug(f"deleting page: {url}")
            wiki_page = {}
            wiki_page['front_page'] = False
            page.edit( wiki_page=wiki_page )
            page.delete()
        except:
            pass
        return 

    def delete_pages( self, confirm=False, with_words=[], all=False ):
        # reset frontpage to syllabus so all pages can be deleted
        self.update_course( default_view="syllabus" )
        logger.debug(f"all: {all}")
        # only delete paes that start with these tokens
        tokens = [['week-','overview'],['week-','resources'],['week-','complete'],['lecture-','slides'],['welcome-','complete'],
                  ['lecture-','video'],['week-','front-'],['dummy','resource'],['welcome-','overview-'],['instructor-','complete'],
                  ['instructor-','overview'],['instructor-','front-'],['welcome-','front-']]
        if not all and (not with_words==[] ):
            tokens = [ with_words ]
        logger.debug(f"{tokens}")
        objects = config.get_pages()
        count = 0
        for url in objects.keys():
            logger.debug(f"{url}")
            if all:
                count = count + 1
                logger.debug(f"ready to remove: {url}")
                if confirm:
                    logger.success(f"deleting page: {url}  -  {objects[url]['title']}")
                    obj = self.delete_page( url )
                else:
                    logger.success(f"page: {url}  -  {objects[url]['title']}")
            else:
                for pair in tokens:
                    logger.debug(f"checking pair: {pair}")
                    delete = True
                    for token in pair:
                        delete = delete and token in url.lower()
                    if delete:
                        count = count + 1
                        logger.debug(f"ready to remove: {url}")
                        if confirm:
                            logger.success(f"deleting page: {url}  -  {objects[url]['title']}")
                            obj = self.delete_page( url )
                        else:
                            logger.success(f"page: {url}  -  {objects[url]['title']}")
        return count

    def delete_assignment( self, id ):
        logger.debug(f"{id}")
        return self.get_default_course_endpoint().get_assignment( id ).delete()

    def delete_assignment_group( self, id ):
        logger.debug(f"{id}")
        return self.get_default_course_endpoint().get_assignment_group( id ).delete()

    def delete_assignments( self, confirm=False ):
        objects = config.get_assignments()
        count = 0
        for group_id in objects.keys():
            group = objects[group_id]
            for assign_id in group['assignments'].keys():
                assign = group['assignments'][assign_id]
                count = count + 1
                if confirm:
                    logger.debug(f"deleting assignment: {assign_id}  -  {assign['name']}")
                    obj = self.delete_assignment( assign_id )
                else:
                    logger.success(f"id: {assign_id}  -  {assign['name']}")
            count = count + 1
            if confirm:
                logger.debug(f"deleting group: {group_id}  -  {group['name']}")
                obj = self.delete_assignment_group( group_id )
                logger.success(f"deleting group: {group_id}  -  {group['name']}")
            else:
                logger.success(f"group: {group_id}  -  {group['name']}")
        return count

    def delete_syllabus( self, confirm=False ):
        syllabus_body = f""
        self.update_course( syllabus_body=syllabus_body )
        config.update_course_settings( syllabus_course_summary=False )
        config.update_course( default_view="syllabus" )
        logger.success("deleting syllabus")
        return 1
    
    def create_rubric( self, title, **kwargs ):
        default = {"rubric":{
                "title":title,
                "free_form_criterion_comments":False,
                "criteria":{
                "1":{
                    "description":"Criterion 1",
                    "ratings":{
                    "1":{
                        "description":"Full credit",
                        "points":1.0},
                    "2":{
                        "description":"No credit",
                        "points":0.0}
                    }},
                "2":{
                    "description":"Criterion 2",
                    "ratings":{
                    "1":{
                        "description":"Full credit",
                        "points":1.0},
                    "2":{
                        "description":"No credit",
                        "points":0.0}
                    }}

                    }},
            "rubric_association":{
                "association_type":"Course",
                "association_id":self.course_id,
                "use_for_grading": True,
                "hide_score_from_total":False}
                }
        rv = self.get_default_course_endpoint().create_rubric( rubric=default["rubric"],rubric_association=default["rubric_association"] )
    

    def get_enrollments( self ):
        return self.get_python_object_from( self.get_default_course_endpoint().get_enrollments )
  

    def get_roster_roles( self,enrollments ):
        """ return list of enrollment roles from current data structure """
        roles = {}
        for enrl in enrollments.values():
            if not enrl["role_id"] in roles.keys():
                # convert TeacherEnrollment to Teachers, StudentEnrollment to Students, etc.
                # replacing "Enrollment" with "s"
                roles[enrl["role_id"]] = enrl["role"].replace("Enrollment","s")
        return roles

    def get_roster_by_roles( self ):
        """ returns a python dictionary of course people by role (e.g., student, teacher, etc.) """
        people = self.get_enrollments()  # list of all course participants
        roles = self.get_roster_roles( people ) # amended list of roles
        used_names = []
        roster = []
        for role_id in sorted(roles.keys()):
            role = {}
            role['id'] = role_id
            role['name'] = roles[role_id]
            role['users'] = {}
            for id in people.keys():
                if people[id]["role_id"]==role_id and not people[id]["user"]["sortable_name"] in used_names:
                    user = people[id]["user"]
                    used_names.append( user["sortable_name"] )
                    user['enrollment_state'] = people[id]['enrollment_state']
                    user['image_url'] = ""
                    user['display_name'] = user["sortable_name"] + " (no VID access)" + " (" + people[id]['enrollment_state'] + ")"
                    if "sis_user_id" in user.keys():
                        if not user["sis_user_id"] is None:
                            image = config.config["images"]["headshot_endpoint"] + "/" + user["sis_user_id"]+".jpg"
                            user['image_url'] = image
                            user['display_name'] = user["sortable_name"] + " (" + user["sis_user_id"] + ")" + " (" + people[id]['enrollment_state'] + ")"
                    user["email"] = "(no email access)"
                    if "login_id" in user.keys():
                        if not user["login_id"] is None:
                            user['email'] = user['login_id'] + "@vcu.edu"

                    role['users'][ user['sortable_name'] ] = user
            roster.append( role )
        return roster


    def roster_qmd_from_template( self, template=None, dest_folder=None,overwrite=False ):
        """ Create a roster qmd file from a template """
        if template is None:
            template = config.config['roster']['default_qmd_template']

        template_folder = os.path.join(self.plugin_folder,"templates")
        src_file_name = os.path.join(template_folder, config.config['roster'][template])

        course = self.get_default_course()
        # logger.debug( course )
        dest_name = course['sis_course_id']+'-roster.qmd'
        if dest_folder is None:
            dest_folder = os.getcwd()
        dest_file_name = os.path.join(dest_folder,dest_name)
        if not os.path.exists(src_file_name):
            return(f"Error: template src file does not exist. {src_file_name}")
        if os.path.exists(dest_file_name) and not overwrite:
            return f"Error: dest exists. Try overwrite flag."
        
        search_strings = ['title: REPLACE_ME', 'config.course_id = REPLACE_ME']
        replace_strings = [f"title: Roster for {course['sis_course_id']}",f"config.course_id = {course['id']}"]

        modified_lines = []
        # Open the input file in read mode
        with open(src_file_name, 'r') as input_file:
            for line in input_file:
                # Check if any of the search strings are present in the line
                if any(search_string in line for search_string in search_strings):
                    # Replace the line with the corresponding replacement string
                    for search_string, replace_string in zip(search_strings, replace_strings):
                        line = line.replace(search_string,replace_string)
                # Append the modified or unmodified line to the list
                modified_lines.append(line)

        # Open the destination file in write mode and write the modified lines
        with open(dest_file_name, 'w') as destination_file:
            destination_file.writelines(modified_lines)        
        msg = f"QMD written to: {os.path.basename( dest_file_name)}"
        return msg

    def get_enrollments( self ):
        try:
            enrl = self.get_python_object_from( self.get_default_course_endpoint().get_enrollments )
        except Exception as e:
            logger.debug(f"{e}")
            enrl = {}
        return enrl
    
    def get_rubrics( self ):
        try:
            rubrics = self.get_python_object_from( self.get_default_course_endpoint().get_rubrics )
        except Exception as e:
            rubrics = {}
        return rubrics
    
    def get_groups( self ):
        try:
            categories = self.get_python_object_from( self.get_default_course_endpoint().get_group_categories )
        except Exception as e:
            categories = {}
            return categories
        try:
            groups = self.get_python_object_from( self.get_default_course_endpoint().get_groups )
        except Exception as e:
            groups = {}
            return groups
        for cat_id in categories.keys():
            categories[cat_id]["groups"] = {}
            for group_id in groups.keys():
                if groups[group_id]["group_category_id"]==cat_id:
                    categories[cat_id]["groups"][group_id] = groups[group_id]
        for cat_id in categories.keys():
            for group_id in categories[cat_id]["groups"].keys():
                try:
                    categories[cat_id]["groups"][group_id]["members"] = self.get_python_object_from( self.get_canvas().get_group( group_id ).get_users )
                except Exception as e:
                    categories[cat_id]["groups"][group_id]["members"] = {}
        return categories
    
    def get_callable_course_objects( self ):
        """ return list of canvas callable objects.  Used primarly by explore """
        dir_methods = dir(self.get_default_course_endpoint())
        var_methods = vars(self.get_default_course_endpoint())
        list = [method for method in dir_methods if (not method in var_methods) and (method[:2] != "__") ]
        return list

    def get_callable_canvas_objects( self ):
        """ return list of canvas callable objects.  Used primarly by explore """
        dir_methods = dir(self.get_canvas())
        var_methods = vars(self.get_canvas())
        list = [method for method in dir_methods if (not method in var_methods) and (method[:2] != "__") ]
        return list

    def get_course_object_by_name( self, method_name ):
        """ Call method by name """
        list = None
        if hasattr(self.get_default_course_endpoint(), method_name ):
            method = getattr(self.get_default_course_endpoint(), method_name)
            if callable(method):
                try:
                    list = self.get_python_object_from( method )
                except Exception as e:
                    list = f"Exception: {e}"
            else:
                logger.warning(f"{method_name} is not callable.")
        else:
            logger.warning(f"{method_name} does not exist in the class.")
        return list

    def get_canvas_object_by_name( self, method_name ):
        """ Call method by name """
        list = None
        if hasattr(self.get_canvas(), method_name ):
            method = getattr(self.get_canvas(), method_name)
            if callable(method):
                try:
                    list = self.get_python_object_from( method )
                except Exception as e:
                    list = f"Exception: {e}"
            else:
                logger.warning(f"{method_name} is not callable.")
        else:
            logger.warning(f"{method_name} does not exist in the class.")
        return list
    
    def get_status( self ):
        """ return string contain status of config """
        msg = f"{program_name} status".upper()
        for key in ["config_file","log_level","canvas_endpoint","headshot_endpoint",
                    "program_name","plugin_folder","gsecrets","course_id"]:
            msg = msg + f"\n{key}\t{getattr(self,key)}"
            if key in "gsecrets":
                try:
                    with open( getattr(self,key)) as file:
                        data = json.load( file )
                    msg = msg + f"\nclient email\t{data.get('client_email')} (from .gsecrets)"
                except Exception as e:
                    msg = msg + f"\nclient email not found, or missing .gsecrets file"


        for key in DEFAULT_ATTRIBUTES['course_attributes'].keys():
            msg = msg + f"\n{key}\t{config.get_course_attribute(key)}"

#           msg = msg + f"\n{vars(self)}"

        current_backend = keyring.get_keyring()
        msg = msg + f"\nBackend Name: {current_backend.name}"
        msg = msg + f"\nBackend Priority: {current_backend.priority}"

        return msg
    

    def get_course_attribute( self, attr=None ):
        if attr==None:
            logger.error(f"missing argument in call to get_course_attribute")
            sys.exit(1)
        if not attr in DEFAULT_ATTRIBUTES["course_attributes"].keys():
            logger.error(f"Missing {attr} in DEFAULT_ATTRIBUTES for course_attributes")
            sys.exit(1)
        missing_key_string = DEFAULT_ATTRIBUTES["course_attributes"][attr]["missing_key_string"]
        value = None
        if "course" in self.config.keys():
            if str(config.course_id) in self.config["course"].keys():
                if attr in self.config["course"][str(config.course_id)].keys():
                    value = self.config["course"][str(config.course_id)][attr]
                    if value==missing_key_string:
                        logger.warning( f"Edit {attr} with appropriate value")
        if value==None:
            logger.debug( f"Adding missing {attr} in {self.config_file_name}")
            if not "course" in self.config.keys():
                self.config["course"] = {}
            if not str(config.course_id) in self.config["course"].keys():
                self.config["course"][str(config.course_id)] = {}
            if not attr in self.config["course"][str(config.course_id)].keys():
                self.config["course"][str(config.course_id)][attr] = missing_key_string
        return value

    @property
    def show_frontpage_vcr_buttons( self ):
        value = self.get_course_attribute( attr="show_frontpage_vcr_buttons" )
        if value is None:
            value = False
        return value

    @property
    def use_outline_lectures_tab( self ):
        value = self.get_course_attribute( attr="use_outline_lectures_tab" )
        if value is None:
            value = False
        return value

    @property
    def outline_gsheet_key( self ):
        missing_key_string = "<add outline gsheet key>"
        value = None
        if "course" in self.config.keys():
            if str(config.course_id) in self.config["course"].keys():
                if "outline_gsheet_key" in self.config["course"][str(config.course_id)].keys():
                    value = self.config["course"][str(config.course_id)]["outline_gsheet_key"]
                    if value==missing_key_string:
                        logger.warning( f".cnvsapi -> Edit outline_gsheet_key with appropriate value")
        if value==None:
            logger.warning( f".cnvsapi -> Missing outline_gsheet_key in {self.config_file_name}")
            if not "course" in self.config.keys():
                self.config["course"] = {}
            if not str(config.course_id) in self.config["course"].keys():
                self.config["course"][str(config.course_id)] = {}
            if not "outline_gsheet_key" in self.config["course"][str(config.course_id)].keys():
                self.config["course"][str(config.course_id)]["outline_gsheet_key"] = missing_key_string
        # Force a return of None, without exit
        if value in [None, missing_key_string]:
            value = None
            sys.exit(1)
        return value

    
    @property
    def outline_google_folder( self ):
        missing_key_string = "<add outline google folder>"
        key = "outline_google_folder"
        value = None
        if "course" in self.config.keys():
            if str(config.course_id) in self.config["course"].keys():
                if key in self.config["course"][str(config.course_id)].keys():
                    value = self.config["course"][str(config.course_id)][key]
                    if value==missing_key_string:
                        logger.warning( f".cnvsapi -> Edit {key} with appropriate value")
                        sys.exit(1)
        if value==None:
            logger.warning( f".cnvsapi -> Missing {key} in {self.config_file_name}")
            if not "course" in self.config.keys():
                self.config["course"] = {}
            if not str(config.course_id) in self.config["course"].keys():
                self.config["course"][str(config.course_id)] = {}
            if not key in self.config["course"][str(config.course_id)].keys():
                self.config["course"][str(config.course_id)][key] = missing_key_string
            sys.exit(1)
        return value

    @property
    def syllabus_gdoc_key( self ):
        missing_key_string = "<add syllabus gdoc key>"
        key = "syllabus_gdoc_key"
        value = None
        if "course" in self.config.keys():
            if str(config.course_id) in self.config["course"].keys():
                if key in self.config["course"][str(config.course_id)].keys():
                    value = self.config["course"][str(config.course_id)][key]
                    if value==missing_key_string:
                        logger.warning( f".cnvsapi -> Edit {key} with appropriate value")
                        sys.exit(1)
        if value==None:
            logger.warning( f".cnvsapi -> Missing {key} in {self.config_file_name}")
            if not "course" in self.config.keys():
                self.config["course"] = {}
            if not str(config.course_id) in self.config["course"].keys():
                self.config["course"][str(config.course_id)] = {}
            if not key in self.config["course"][str(config.course_id)].keys():
                self.config["course"][str(config.course_id)][key] = missing_key_string
            sys.exit(1)
        return value

    @property
    def zoom_lecture_url( self ):
        missing_key_string = "<add zoom lecture url>"
        key = "zoom_lecture_url"
        value = None
        if "course" in self.config.keys():
            if str(config.course_id) in self.config["course"].keys():
                if key in self.config["course"][str(config.course_id)].keys():
                    value = self.config["course"][str(config.course_id)][key]
                    if value==missing_key_string:
                        logger.warning( f".cnvsapi -> Edit {key} with appropriate value")
                        sys.exit(1)
        if value==None:
            logger.warning( f".cnvsapi -> Missing {key} in {self.config_file_name}")
            if not "course" in self.config.keys():
                self.config["course"] = {}
            if not str(config.course_id) in self.config["course"].keys():
                self.config["course"][str(config.course_id)] = {}
            if not key in self.config["course"][str(config.course_id)].keys():
                self.config["course"][str(config.course_id)][key] = missing_key_string
            sys.exit(1)
        return value


    @property
    def lecture_slides_endpoint( self ):
        missing_key_string = "<add root URL to lecture slides>"
        value = None
        if "course" in self.config.keys():
            if str(config.course_id) in self.config["course"].keys():
                if "lecture_slides_endpoint" in self.config["course"][str(config.course_id)].keys():
                    value = self.config["course"][str(config.course_id)]["lecture_slides_endpoint"]
                    if value==missing_key_string:
                        value=None
        if value==None:
            logger.warning( f".cnvsapi -> Missing lecture_slide_endpoint. Edit {self.config_file_name}")
            if not "course" in self.config.keys():
                self.config["course"] = {}
            if not str(config.course_id) in self.config["course"].keys():
                self.config["course"][str(config.course_id)] = {}
            if not "lecture_slides_endpoint" in self.config["course"][str(config.course_id)].keys():
                self.config["course"][str(config.course_id)]["lecture_slides_endpoint"] = missing_key_string
            sys.exit(1)
        return value
    
    @property
    def default_split_code( self ):
        return self.config["application"]["default_split_code"]

    @property
    def log_level( self ):
        value = None
        if "application" in self.config.keys():
            if "log_level" in self.config["application"].keys():
                value = self.config["application"]["log_level"]
        return value
    
    @log_level.setter
    def log_level( self, log_level ):
        self.config["log_level"] = log_level            
        logger.remove()
        logger.add(sys.stderr, level=log_level)

    @property
    def headshot_endpoint( self ):
        """ returns headshot_endpoint from configuration """
        value = None
        if "images" in self.config.keys():
            if "headshot_endpoint" in self.config["images"].keys():
                value = self.config["images"]["headshot_endpoint"]
        return value

    @property
    def namespace( self ):
        return self.config["keyring"]["namespace"] + "/" + self.config["keyring"]["entry"]

    @property
    def token( self ):
        namespace = self.config["keyring"]["namespace"] + "/" + self.config["keyring"]["entry"]
        logger.info(f"Retriving token using: {namespace}" )
        try:
            token = keyring.get_password( namespace, self.config["keyring"]["entry"] )
        except keyring.errors.NoKeyringError as e:
            logger.error("No keyring installed.  Are you using WSL?")
            logger.error( e )
            current_backend = keyring.get_keyring()
            print(f"Backend Name: {current_backend.name}")
            print(f"Backend Priority: {current_backend.priority}")
            sys.exit(1)

        return token

    @token.setter
    def token( self, token ):
        namespace = self.config["keyring"]["namespace"] + "/" + self.config["keyring"]["entry"]
        keyring.set_password( namespace, self.config["keyring"]["entry"], token )
        logger.info(f"Token stored in local secure storage: {namespace}")
        return keyring.get_password( namespace, self.config["keyring"]["entry"] )
    
    
    @property
    def program_name( self ):
        return program_name
    
    @property
    def config_file_name( self ):
        return self.config_file
    
    @property
    def canvas_endpoint(self):
        return self.config["canvas"]["endpoint"]
    
    @property
    def plugin_folder( self ):
        value = plugin_folder; #from global in this file
        if "application" in self.config.keys():
            if "plugin_folder" in self.config["application"].keys():
                value = self.config["application"]["plugin_folder"]
        return value
    
    @property
    def gsecrets( self ):
        value = os.path.expanduser("~/.gsecrets/gsheets-credentials.json")
        if "application" in self.config.keys():
            if "gsecrets" in self.config["application"].keys():
                value = os.path.expanduser(self.config["application"]["gsecrets"])
        return value
    
    @property
    def lecture_slides_template( self ):

##           template_key = config.config["lecture"]["default_qmd_template"]
##        template_qmd_file = os.path.join(config.plugin_folder, config.config["lecture"][template_key] )

        missing_key_string = "<add template file for lecture slides>"
        value = None
        if "course" in self.config.keys():
            if str(config.course_id) in self.config["course"].keys():
                if "lecture_slides_template" in self.config["course"][str(config.course_id)].keys():
                    value = self.config["course"][str(config.course_id)]["lecture_slides_template"]
                    if value==missing_key_string:
                        value=None
                    elif not os.path.exists( value ):
                        value=None
        if value==None:
            logger.warning( f".cnvsapi -> Missing lecture_slide_template. Edit {self.config_file_name}")
            if not "course" in self.config.keys():
                self.config["course"] = {}
            if not str(config.course_id) in self.config["course"].keys():
                self.config["course"][str(config.course_id)] = {}
            if not "lecture_slides_template" in self.config["course"][str(config.course_id)].keys():
                self.config["course"][str(config.course_id)]["lecture_slides_template"] = missing_key_string
            sys.exit(1)
        return value

    def display_object( self, objects, id=None, as_json=False, elements=['id','title'], include=None, exclude=None, oneline=False ):
        """ Display object or objects """

        def build_string( obj,fields,delim=" - ",prefix="" ):
            """ assumes obj is a dictionary."""
            result = []
            # loop over elements in dictionary

            logger.debug( fields )
            logger.debug( f"{obj}" )
            if fields==[]:
                return
            
            if isinstance( obj,list):

                for item in obj:
                    logger.debug( item )
                    logger.debug( fields )
                    s = prefix
                    ss = None
#                    item = obj[key]
                    if not prefix in ["","\t"]:
                        s = s + delim
                    for idx, field in enumerate(fields):
                        logger.debug( f"idx: {idx}  field: {field}  item:{item}")
                        if isinstance( field, list ):
                            pass
                        elif isinstance( field, dict ):
    #                        logger.debug( f"dictionary: {next(iter(field))} values: {field[next(iter(field))]}")
                            ss = build_string( item[next(iter(field))],field[next(iter(field))],delim,prefix="\t")
                        elif isinstance( item, dict ):
    #                        logger.debug( f"{type(obj[key])}")
    #                        logger.debug(f"{obj}\n{obj[key]}\n{field}")
                            if idx==0:
                                s = s + str(item.get(str(field),f'(no key: {field})'))
                            else:
                                s = s + delim + str(item.get(str(field),f'(no key: {field})'))
                        else:
                            logger.debug(f"{item}")
                            if idx==0:
                                s = s + str(item)
                            else:
                                s = s + delim + str(item)
                                pass
                    if oneline:
                        result.append( s + " ... " )
                    else:
                        result.append(s)
                        if not ss is None:
                            result.extend( ss )
                    
            elif isinstance( obj[next(iter(obj))], dict ):

                for key in obj.keys():
                    s = prefix
                    ss = None
                    item = obj[key]
                    if not prefix in ["","\t"]:
                        s = s + delim
                    for idx, field in enumerate(fields):
                        logger.debug( f"key: {key}  idx: {idx}  field: {field}")
                        if isinstance( field, list ):
                            pass
                        elif isinstance( field, dict ):
                            logger.debug( key )
                            logger.debug( next(iter(field)) )
                            logger.debug( item[next(iter(field))] )
                            logger.debug( field[next(iter(field))] )
                            if item[next(iter(field))] != {}:
                                ss = build_string( item[next(iter(field))],field[next(iter(field))],delim,prefix="\t")
                        elif isinstance( item, dict ):
    #                        logger.debug( f"{type(obj[key])}")
    #                        logger.debug(f"{obj}\n{obj[key]}\n{field}")
                            if idx==0:
                                s = s + str(item.get(str(field),f'(no key: {field})'))
                            else:
                                s = s + delim + str(item.get(str(field),f'(no key: {field})'))
                        else:
                            logger.debug(f"{item}")
                            if idx==0:
                                s = s + str(item)
                            else:
                                s = s + delim + str(item)
                            pass
                    if oneline:
                        if isinstance( ss,list ):
                            sss = delim.join( ss )
                        elif ss is None:
                            sss = ""
                        else:
                            sss = ss
                        if len(sss)>0:
                            sss = delim + sss.strip()
                        result.append( s.strip() + sss )
                    else:
                        result.append( s )
                        if not ss is None:
                            result.extend( ss )
            else:
                s = prefix
                for idx,field in enumerate( fields ):
                    if idx==0:
                        s = s + str(obj.get(field,f"(no key: {field})"))
                    else:
                        s = s + delim + str(obj.get(field,f"(no key: {field})"))
                result.append( s )

            return result

        result = []
        if objects in [{}, None]:
            return "Nothing to show."
        if id is None:
            if as_json:
                result.append( as_pretty_json( objects ))
            else:
                s = build_string( objects, elements )
                result.extend( s )
        else:
            if as_json:
                result.append( as_pretty_json( objects[id] ))
            else:
                try:
                    s = build_string( {id:objects[id]}, elements)
                except KeyError as e:
                    logger.warning( f"Invalid id: {id}.  Did you input the correct id?  Try the other one." )
                    sys.exit(1)
                except Exception as e:
                    logger.warning( e )
                    sys.exit(1)
                result.extend( s )

        include_strings = []
        if isinstance(include,str):
            include_strings = include.split(",")
        elif not include is None:
            logger.warning(f"Unusable include in display.object: {include}")

        exclude_strings = []
        if isinstance(exclude,str):
            exclude_strings = exclude.split(",")
        elif not exclude is None:
            logger.warning(f"Unusable exclude in display.object: {exclude}")

        filtered_result = result
        if len(include_strings)>0:
            # this code adds strings to an empty list
            filtered_result = [item for item in result if any(f in item for f in include_strings)]
        if len(exclude_strings)>0:
            # this code removes strings from a starting list
            filtered_result[:] = [item for item in filtered_result if not any(f in item for f in exclude_strings)]

        logger.debug( filtered_result )
        return "\n".join( filtered_result )


class ExternalCommandClass(click.MultiCommand):
    """ ExternalCommandClass docstring """
    def __init__( self, plugin_folder, **kwargs ):
        super().__init__( **kwargs )
        self.plugin_folder = plugin_folder

    def list_commands(self, ctx):
        rv = []
        for filename in os.listdir(self.plugin_folder):
            if filename.startswith("cmd_") and filename.endswith('.py'):
                rv.append(filename[4:-3])
        rv.sort()
        return rv

    def get_command(self, ctx, name):
        ns = {}
        fn = os.path.join(self.plugin_folder, "cmd_"+ name + '.py')
        logger.debug(f"Loading plugin info: {fn}")
        if os.path.exists(fn):
            with open(fn) as f:
                code = compile(f.read(), fn, 'exec')
                eval(code, ns, ns)
            ns = ns['cli']
        else:
            ns = None
        return ns

config = Configuration()

