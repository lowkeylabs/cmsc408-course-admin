""" docstring for cmd_assessment
"""
import os
import re
import json
import click

from loguru import logger
import markdown
import pandas as pd

from cnvsapi.utils import as_pretty_json
from cnvsapi.config import config, DEFAULT_LOG_LEVEL,ENV_TOKEN_NAME

@click.group(invoke_without_command=True)
#@click.option("--course-id",help="Display details for this outcome ID",default=None,type=int)
#@click.option("--courses",help="Display courses and ids",is_flag=True, default=False)
@click.pass_context
#def cli(ctx,course_id,courses):
def cli( ctx ):
    """ Example usage of cnvsapi commands.

    > List courses available to your canvas account.  Refer to these course_ids for later commands.

        cnvsapi list courses

    > List modules and module-items for course 10001

        cnvsapi --course-id=10001 list module-items

    > Create a local configuration file and set a default course-id

        cnvsapi --course-id=10001 --save

    or

        cnvsapi config course-id=10001 --save


        

    """
    if ctx.invoked_subcommand is None:
        print(f"Default course id: {config.course_id}")
        print(f"Default plugin folder: {config.plugin_folder}")
        click.echo(ctx.get_help())

if (0):
    @cli.command()
    @click.option("--overwrite",help="Overwrite destination file",default=False, is_flag=True )
    @click.pass_context
    def general(ctx,overwrite):
        """ List general examples

        List canvas courses available to your account:

            cnvsapi list courses
        

        """
        msg = config.roster_qmd_from_template(overwrite=overwrite)
        if not msg is None:
            click.echo( msg )


if __name__ == '__main__':
    cli(obj={})


