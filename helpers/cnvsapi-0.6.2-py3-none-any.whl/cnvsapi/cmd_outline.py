""" docstring for cmd_outline
"""
import os
import re
import json
import click

from loguru import logger
import markdown
import pandas as pd
from datetime import datetime

from cnvsapi.build_utils import extract_lectures,extract_quizzes,extract_homeworks, extract_meetings, extract_weeks, extract_overviews, extract_resources, extract_projects
from cnvsapi.utils import as_pretty_json
from cnvsapi.config import config, DEFAULT_LOG_LEVEL, ENV_TOKEN_NAME, DEFAULT_ATTRIBUTES

@click.group(invoke_without_command=True)
@click.option("--course-id",help="Display details for this outcome ID",default=None,type=int)
@click.option("--courses",help="Display courses and ids",is_flag=True, default=False)
@click.pass_context
def cli(ctx,course_id,courses):
    """ List outline settings.

    An outline is a google workbook containing course configuration information.  It's 
    much easier to modify the outline and let this tools modify canvas directly.
    
    """
    if courses:
        crses = config.get_courses()
        comments = ""
        for id in crses.keys():
            line = f"{'' if id==config.course_id else '# '}course_id={id:<8d} #  {crses[id]['name']}"
            print( line )
            comments = comments + "\n" + line
        return
    elif not course_id is None:
        ctx.obj["COURSE_ID"] = course_id
        config.course_id = course_id
    if ctx.invoked_subcommand is None:
        click.echo(f"Course id: {config.course_id} {' --> Select course from .cnvsapi' if config.course_id==None else '' }")

        click.echo(" ")
        for key in DEFAULT_ATTRIBUTES['course_attributes'].keys():
            click.echo(f"{key} : {config.get_course_attribute(key)}")
        click.echo(" ")

        click.echo(ctx.get_help())


@cli.command()
@click.pass_context
def lectures(ctx):
    """ List lectures found in google sheet """
    df = extract_lectures()
    for i,row in df.iterrows():
        datetime_string = row["DateCanvas"]
#        datetime_object = datetime.strptime(datetime_string, "%m/%d/%Y %H:%M:%S")
#        formatted_date = datetime_object.strftime("%a, %b. %d")
        click.echo(f"Lecture {str(row['Lecture ID']):2}: {row['Lecture Title / Topics']}, {datetime_string}")


@cli.command()
@click.pass_context
def quizzes(ctx):
    """ List quizzes found in google sheet """
    df = extract_quizzes()
    for i,row in df.iterrows():
        datetime_string = row["DateCanvas"]
#        datetime_object = datetime.strptime(datetime_string, "%m/%d/%Y %H:%M:%S")
#        formatted_date = datetime_object.strftime("%a, %b. %d")
        click.echo(f"{row['Quiz+Title']}, due {datetime_string}")

@cli.command()
@click.pass_context
def homeworks(ctx):
    """ List homeworks found in google sheet """
    df = extract_homeworks()
    for i,row in df.iterrows():
        datetime_string = row["DateCanvas"]
#        datetime_object = datetime.strptime(datetime_string, "%m/%d/%Y %H:%M:%S")
#        formatted_date = datetime_object.strftime("%a, %b. %d")
        click.echo(f"{row['HW+Title']}, due {datetime_string}")

@cli.command()
@click.pass_context
def projects(ctx):
    """ List projects found in google sheet """
    df = extract_projects()
    for i,row in df.iterrows():
        datetime_string = row["DateCanvas"]
#        datetime_object = datetime.strptime(datetime_string, "%m/%d/%Y %H:%M:%S")
#        formatted_date = datetime_object.strftime("%a, %b. %d")
        click.echo(f"{row['Prj+Title']}, due {datetime_string}")


@cli.command()
@click.pass_context
def meetings(ctx):
    """ List class meetings found in google sheet """
    df = extract_meetings()
    for i,row in df.iterrows():
        datetime_string = row["DateCanvas"]
#        datetime_object = datetime.strptime(datetime_string, "%m/%d/%Y %H:%M:%S")
#        formatted_date = datetime_object.strftime("%a, %b. %d")
        click.echo(f"Meeting {str(row['Meeting ID']):2}: {row['Classroom Activity']} - {datetime_string}")

@cli.command()
@click.pass_context
def weeks(ctx):
    """ List weeks / modules found in google sheet """
    df = extract_weeks()
    for i,row in df.iterrows():
        datetime_string = row["DateCanvas"]
#        datetime_object = datetime.strptime(datetime_string, "%m/%d/%Y %H:%M:%S")
#        formatted_date = datetime_object.strftime("%Y-%m-%d")
        click.echo(f"Week {str(row['WK']):2}: {row['Module']} ({datetime_string})")

@cli.command()
@click.pass_context
def overviews(ctx):
    """ List overviews found in google sheet """
    df = extract_overviews()
    for i,row in df.iterrows():
        click.echo(f"Week {str(row['Week']):2}: {row['Overview']}")


@cli.command()
@click.pass_context
def resources(ctx):
    """ List overviews found in google sheet """
    df = extract_resources()
    for i,row in df.iterrows():
        click.echo(f"Week {str(row['Week']):2}: {row['Title']}")


if __name__ == '__main__':
    cli(obj={})


