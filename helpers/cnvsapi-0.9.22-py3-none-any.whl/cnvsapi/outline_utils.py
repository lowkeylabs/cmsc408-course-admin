"""
Outline utilities for present lists based on outline data
"""

import textwrap
from loguru import logger
from tabulate import tabulate
from datetime import datetime

from cnvsapi.config import config


from cnvsapi.utils import order_weeks_by_week, local_time_difference, find_quiz_in_quizzes, as_pretty_json, \
                            get_title, find_page_in_pages, find_assignment_in_assignments
from cnvsapi.build_utils import extract_outline, get_outline_objects, extract_overviews

def outline_instructor_checklist( include_weeks=None,exclude_weeks=None,only_not_ok=False,within_days=1000 ):
    """ returns an instructor checklist for desired weeks """

    logger.debug(f"Including weeks: {include_weeks}")
    logger.debug(f"Excluding weeks: {exclude_weeks}")

    outline_df = extract_outline()
    weeks_list = order_weeks_by_week( outline_df, prefix=['instructor','welcome'],include_weeks=include_weeks, exclude_weeks=exclude_weeks )
    logger.debug( weeks_list )

    combined_df = get_outline_objects()
    combined_df = combined_df.sort_values(by='canvas_unlock_at', ascending=True)
    logger.trace( combined_df )


    canvas_quizzes = config.get_quizzes()
    canvas_pages = config.get_pages()
#    canvas_assignments = config.get_assignments()
    canvas_assignments = config.get_assignment_groups(include=['assignments']) # from Canvas


    results = []
    for id,row in combined_df.iterrows():

        if not row['week_id'] in weeks_list:
            continue
        if row['source_tab'] in ['resources']:
            continue

        diff = local_time_difference( row['canvas_unlock_at'] )
        outline_entry = row['outline_entry']
        status = ['(not calculated)']

        # process surveys and quizzes
        if row['source_tab'] in ['surveys','quizzes']:
            if not row['google_doc_id']:
                status.append("Missing google_doc_id")
            quiz = find_quiz_in_quizzes( canvas_quizzes,title=row['canvas_title'])
            if not quiz:
                status.append("Quiz not found in canvas")
            else:
                logger.trace( as_pretty_json( quiz ) )
                if not quiz['published']:
                    status.append("Not published")
                if not quiz['question_count']>0:
                    status.append("No questions found")

            # Set to OK if nothing was appended.
            if len(status)>1:
                status = status[1:]
            else:
                status = ['Ok']

        # process lectures
        elif row['source_tab'] in ['lectures']:
            try:
                if not int(row['topic_count'])>0:
                    status.append("Add topics to tab")
            except:
                status.append("Add topics to tab")

            if not row['content_url']:
                status.append("Add content_url to tab")

            # Verify lecture is published
            title = get_title("lecture_slide",id=row['id'])
            page = find_page_in_pages( canvas_pages,title=title)
            if not page:
                status.append(f"Create lecture page ({title})")
            else:
                logger.trace( as_pretty_json( page ) )
                if not page['published']:
                    status.append("Publish lecture")

            title = get_title("lecture_video",id=row['id'])
            page = find_page_in_pages( canvas_pages,title=title)
            page = config.get_page( page['url'] )
            if not page:
                status.apend(f"Create video page ({title})")
            else:
                if not page['published']:
                    status.append("Publish video page")
                if "external_tools" not in page['body'].lower():
                    status.append("Link kaltura video")

            # Last thing to do.  If nothing added, mark it OK.
            if len(status)>1:
                status = status[1:]
            else:
                status = ['Ok']

        # process discussions
        elif row['source_tab'] in ['discussions']:
            if not row['google_doc_id']:
                status.append("Missing google_doc_id")
            title = row['canvas_title']
            assign = find_assignment_in_assignments( canvas_assignments, title=title )
            if not assign:
                status.append(f"Missing assignment ({title})")
            else:
                logger.trace( as_pretty_json( assign ) )
                if not assign['published']:
                    status.append('Not published')
                submission_types = assign.get("submission_types",[])
                if (len(submission_types)>0) and submission_types[0]=="external_tool":
                    external_tool_tag_attributes = assign.get("external_tool_tag_attributes",{})
                    if not external_tool_tag_attributes:
                        status.append('External tool not assigned')
                    else:
                        url = external_tool_tag_attributes.get("url","")
                        if not url:
                            status.append('External tool missing url')
            # Last thing to do.  If nothing added, mark it OK.
            if len(status)>1:
                status = status[1:]
            else:
                status = ['Ok']

        # process overviews
        elif( row['source_tab'] in ['overviews']):
            if not row['overview']:
                status.append("Add overview text")
            if not row['module']:
                status.append("Ass module to overview")

            # Last thing to do.  If nothing added, mark it OK.
            if len(status)>1:
                status = status[1:]
            else:
                status = ['Ok']
    
        # process homeworks and projects
        elif( row['source_tab'] in ['homeworks','projects']):
            if not row['outline_entry']:
                status.append("Missing outline_entry")
            if not row['google_doc_id']:
                status.append("Add google_doc_id")
            if row['canvas_submission_types']:
                if row['canvas_submission_types'].lower()=="external_tool" and not row['has_gradescope_page']:
                    status.append("External tool and not has_gradescope_page")
            if row['has_gradescope_page']:
                if not "https:" in row['has_gradescope_page']:
                    status.append("Add GH classroom URL")

            # check non-gradescope assignment
            title = row['canvas_title']
            assign = find_assignment_in_assignments( canvas_assignments, title=title)
            if not assign:
                status.append(f"Assignment not found ({title})")
            else:
                logger.debug( as_pretty_json( assign ))
                if not assign['published']:
                    status.append("Not published")
                    # verify external tool attached
                submission_types = assign.get("submission_types",[])
                if not ( (len(submission_types)==1) and (submission_types[0]=="online_upload")):
                    status.append("Not online upload")
                allowed_extensions = assign.get("allowed_extensions",[])                
                if not ( (len(allowed_extensions)==1) and (allowed_extensions[0]=="html")):
                    status.append("Fix upload to HTML only")
                use_rubric_for_grading = assign.get("use_rubric_for_grading", False )
                if not use_rubric_for_grading:
                    status.append("Set use_rubric_for_grading to True")
                rubric = assign.get("rubric",[])
                if not rubric:
                    status.append("Missing or invalid rubric")

            # check gradescope portion of assignment
            if row['has_gradescope_page']:
                title = get_title("gradescope",title=row['canvas_title'])
                assign = find_assignment_in_assignments( canvas_assignments, title=title)
                if not assign:
                    status.append(f"Create GS assignment ({title})")
                else:
                    logger.debug( as_pretty_json( assign ))
                    if not assign['published']:
                        status.append("Publish GS assignment")
                    # verify external tool attached
                    submission_types = assign.get("submission_types",[])
                    if (len(submission_types)==1) and submission_types[0]=="external_tool":
                        external_tool_tag_attributes = assign.get("external_tool_tag_attributes",{})
                        if not external_tool_tag_attributes:
                            status.append('Assign GS external tool')
                        else:
                            url = external_tool_tag_attributes.get("url","")
                            if not url:
                                status.append('Assign GS external tool')
                    else:
                        status.append("Assign GS external")


            # Last thing to do.  If nothing added, mark it OK.
            if len(status)>1:
                status = status[1:]
            else:
                status = ['Ok']

        if not status:
            status.append("Ok")
        if outline_entry:
            outline_entry = outline_entry[:25]

        msg = "; ".join( status )
        if not msg=="Ok":
            msg += "."
        group = ""
        if row['canvas_assignment_group']:
            group = textwrap.fill(row['canvas_assignment_group'],10)

        results.append( [ row['week_id'],outline_entry,diff,row['source_tab'], msg ])

    # Details don't have tabs in outline, so we'll check them here
    # and add any messages to the results list.
    #  week : title : days_until : source : group : message 

    overviews = extract_overviews()
    for week_id in weeks_list:
        title = get_title("details",id=week_id)
        page = find_page_in_pages( canvas_pages, title )
        page = config.get_page( page['url'] )
        overview_row = overviews[ overviews['week_id']==str(week_id)]
        status = []
        if not overview_row.empty:
            diff = local_time_difference( str(overview_row['canvas_unlock_at'].iloc[0]) )
        else:
            diff = 0.0
        if page:
            if "welcome to a new week" in page["body"].lower():
                status.append("Freshen details file")

        if not status:
            status.append("Ok")
        msg = "; ".join( status )
        if not msg=="Ok":
            msg += "."

        results.append( [week_id,title,diff,"details", msg])


    # sort and format table, then return it.

    headers = ['Week', 'Outline Entry', 'Unlocks\n(days)','Group','Status']
    colalign = ['center', 'left', 'right','left','left']

    if only_not_ok:
        results = [row for row in results if not row[4]=="Ok"]
    results = [row for row in results if float(row[2])<=float(within_days) ]
    results = sorted(results, key=lambda x: float(x[2]))
    for row in results:
        row[4] = textwrap.fill( row[4],width=45 )

    return tabulate(results, headers=headers, tablefmt="pretty",colalign=colalign)
