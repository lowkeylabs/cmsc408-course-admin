""" docstring for cmd_update
"""
import os
import json
import click

from loguru import logger

from cnvsapi.config import config, DEFAULT_LOG_LEVEL,ENV_TOKEN_NAME
from cnvsapi.utils import edit_list_with_editor, update_modules, update_moduleitems
from cnvsapi.bridge import bridge

@click.group(invoke_without_command=True)
@click.pass_context
def cli(ctx):
    """ Update assets on Canvas
        
    """
    logger.debug(f"UPDATE: invoked subcommand: {ctx.invoked_subcommand}")
    logger.debug(f"UPDATE: Inside token routine")

    if ctx.invoked_subcommand is None:
        print(json.dumps(config.config["course"],indent=2))


@cli.command()
def details():
    print(config.config["course"])


@cli.command()
def syllabus():
    """ Update syllabus using data from .cnvsapi """
    data = config.config["course"][str(config.course_id)]["syllabus"]
    logger.debug(f"{data}")
    logger.debug(f"{data.keys()}")
    if "google_doc" in data.keys() and "local_file" in data.keys():
        print("Error: syllabus is defined from two sources.  See .cnvsapi")
    elif not "google_doc" in data.keys() and not "local_file" in data.keys():
        print("Error: syllabus missing source. Add 'google_doc' or 'local_file'")
    elif "local_file" in data.keys():
        bridge.update_syllabus_from_file( data["local_file"] )
        logger.info(f"Syllabus updated using 'local_file': {data['local_file']}")
    elif "google_doc" in data.keys():
        bridge.update_syllabus_from_google ( data["google_doc"] )
        logger.info(f"Syllabus updated using 'goggle_doc': {data['google_doc']}")


@cli.command()
def pages():
    for page in config.config["course"][str(config.course_id)]["pages"]:
        if "google_doc" in page.keys() and "local_file" in page.keys():
            print("Error: page is defined with two sources.  See .cnvsapi")
        elif not "google_doc" in page.keys() and not "local_file" in page.keys():
            print("Error: page defined without any sources. Add 'google_doc' or 'local_file' to .cnvsapi")
        elif "local_file" in page.keys():
            bridge.update_page_from_file( page["local_file"] )
            logger.info(f"Page updated using 'local_file': {page['local_file']}")
        elif "google_doc" in page.keys():
            bridge.update_page_from_google ( page["google_doc"] )
            logger.info(f"Page updated using 'goggle_doc': { page['google_doc'] }")



if __name__ == '__main__':
    cli(obj={})


