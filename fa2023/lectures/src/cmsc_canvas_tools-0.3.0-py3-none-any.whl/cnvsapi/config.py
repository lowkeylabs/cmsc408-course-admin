""" Config - module for configuration
"""
import sys
import os
import keyring
import tomlkit
from loguru import logger
import click
import keyring.util.platform_ as keyring_platform
from canvasapi import Canvas
from datetime import date

program_name = os.path.splitext(os.path.basename( sys.argv[0] ))[0].lower()
program_name = "cnvsapi"

config_file_name = "." + (program_name).lower()

ENV_CONFIG = program_name.upper()
ENV_LOG_LEVEL = program_name+"_LOG_LEVEL"
ENV_TOKEN_NAME = "CANVAS_API_TOKEN"

DEFAULT_LOG_LEVEL = 'WARNING'
DEFAULT_SPLIT_CODE = "::"

logger.remove()
logger.add(sys.stderr, level=DEFAULT_LOG_LEVEL)

plugin_folder = os.path.join(os.path.dirname(__file__))

class Configuration:
    config = tomlkit.document()
    config_file = config_file_name

    def __init__( self ):
        self.config = tomlkit.document()

        if not os.path.exists( self.config_file ):
            logger.info(f"Creating internal configuration: {config_file_name}")
            self.config = tomlkit.loads(f"""# {program_name} config file ({config_file_name}). Auto-created: {date.today()}

# This is a strictly formatted TOML file. It contains configuration values for this 
# program. Highest level paramters control application run-time. Subsequent sections 
# contain parameters for services that interact with this program.
                                        
# Log_level: used for watching execution.  This tool uses loguru.
# Values: "TRACE", "DEBUG", "INFO", "SUCCESS", "WARNING", "ERROR", "CRITICAL"
# Default: "WARNING"
                                        
[application]
# Application configuration variables

log_level = "{DEFAULT_LOG_LEVEL}"
default_split_code = "{DEFAULT_SPLIT_CODE}"


[canvas]
# Campus default values for Canvas

# Url: high level web address of campus canvas server

url = "https://virginiacommonwealth.instructure.com"


[keyring]
# keyring is a local computer secure storage system leveraging tools from
# the local OS. Keyring works on windows, linux and mac.
# See: https://pypi.org/project/keyring/

# Namespace and entry are used with "keyring" to store canvas token in local
# computer secure password storage. Don't mess with these, they were carefully
# selected to work across all windows, linux, and mac platforms.

namespace = "cmsc-vcu-course-tools-api"
entry = "{ENV_TOKEN_NAME}"

""")
            if click.confirm(f"Create {config_file_name} config file in this folder?",err=True):
                logger.info(f"User selected to save config file: {config_file_name}")
                self.save()
            else:
                logger.info("User chose to NOT save config file.")
        else:
            logger.info(f"Loading config file: {self.config_file}")
            try:
                with open(self.config_file, 'r') as file:
                    self.config = tomlkit.loads(file.read())
            except Exception as e:
                print(f"\nError reading config file: \"{self.config_file}\" during startup.")
                print("-->",str(e))
                print("Edit the file and try again")
                sys.exit(1)
        
        # we've got a create self.config is is (or isn't) saved. Doesn't matter - it's in memory!

        if "application" not in self.config.keys():
            self["application"]["log_level"] = DEFAULT_LOG_LEVEL
        if "log_level" in self.config['application'].keys():
            logger.remove()
            logger.add(sys.stderr, level=self.config["application"]["log_level"])
            logger.info(f"Log level set to {self.config['application']['log_level']} by {self.config_file}")

        if self.token is None:
            print(f"""\nWARNING - {ENV_TOKEN_NAME} not found in environment or keyring.
You'll need a token from canvas to access the API using this program.
Visit: https://virginiacommonwealth.instructure.com/profile/settings  to get an API token.
Store the token using:
  cnvsapi token --canvas-api-token="<your token inside the double-quotes>"
""")

#            sys.exit(1)
    
    def serialize(self, file_path):
        with open(file_path, 'w') as file:
            file.write(tomlkit.dumps(self.config))

    def save( self ):
        self.serialize( self.config_file )

    def createOrReplace(self,key,item ):
        if key in self.config.keys():
            self.config[key] = item
        else:
            self.config.add(key,item)

    def addCourseComments(self,comments):
        tab = tomlkit.table()
        header = """
# Course contains a list of potential courses that this canvas user
# can connect.  Use "cnvsapi courses --add-to-config" to freshen this section.
# Once freshened, the user should uncomment one of the courses to serve
# as default for further operations.
        """
        tab.comment(f"{header}{comments}")
        self.createOrReplace("course",tab)
        self.save()

    @property
    def course_id( self ):
        value = None
        if "course" in self.config.keys():
            if "course_id" in self.config["course"].keys():
                value = self.config["course"]["course_id"]
        return value

    @course_id.setter
    def course_id( self, course_id ):
        self.config["course"]["course_id"] = course_id

    def get_canvas( self ):
        namespace = self.namespace
        return Canvas( self.config["canvas"]["url"],keyring.get_password( namespace, self.config["keyring"]["entry"] )  )

    def get_course( self ):
        value = self.course_id
        logger.debug(value)
        if value is not None:
            value = self.get_canvas().get_course( value )
        return value
    
    def get_module( self, module_id ):
        value = self.get_course()
        if value is not None:
            value = value.get_module( module_id )()
        return value

    def get_modules( self, module_id ):
        value = self.get_course()
        if value is not None:
            value = (self.get_course()).get_course( module_id ).get_modules()
        return value
    
    @property
    def default_split_code( self ):
        return self.config["application"]["default_split_code"]

    @property
    def log_level( self ):
        value = None
        if "application" in self.config.keys():
            if "log_level" in self.config["application"].keys():
                value = self.config["application"]["log_level"]
        return value
    
    @log_level.setter
    def log_level( self, log_level ):
        self.config["log_level"] = log_level            
        logger.remove()
        logger.add(sys.stderr, level=log_level)

    @property
    def namespace( self ):
        return self.config["keyring"]["namespace"] + "/" + self.config["keyring"]["entry"]

    @property
    def token( self ):
        namespace = self.config["keyring"]["namespace"] + "/" + self.config["keyring"]["entry"]
        logger.info(f"Retriving token using: {namespace}" )
        return keyring.get_password( namespace, self.config["keyring"]["entry"] )

    @token.setter
    def token( self, token ):
        namespace = self.config["keyring"]["namespace"] + "/" + self.config["keyring"]["entry"]
        keyring.set_password( namespace, self.config["keyring"]["entry"], token )
        logger.info(f"Token stored in local secure storage: {namespace}")
        return keyring.get_password( namespace, self.config["keyring"]["entry"] )
    
    @property
    def program_name( self ):
        return program_name
    
    @property
    def config_file_name( self ):
        return self.config_file
    
    @property
    def canvas_url(self):
        return self.config["canvas"]["url"]
    
    @property
    def plugin_folder( self ):
        value = plugin_folder; #from global in this file
        if "application" in self.config.keys():
            if "plugin_folder" in self.config["application"].keys():
                value = self.config["application"]["plugin_folder"]
        return value
    
    @property
    def gsecrets( self ):
        value = os.path.expanduser("~/.gsecrets/gsheets-credentials.json")
        if "application" in self.config.keys():
            if "gsecrets" in self.config["application"].keys():
                value = os.path.expanduser(self.config["application"]["gsecrets"])
        return value

class ExternalCommandClass(click.MultiCommand):

    def __init__( self, plugin_folder, **kwargs ):
        super().__init__( **kwargs )
        self.plugin_folder = plugin_folder

    def list_commands(self, ctx):
        rv = []
        for filename in os.listdir(self.plugin_folder):
            if filename.startswith("cmd_") and filename.endswith('.py'):
                rv.append(filename[4:-3])
        rv.sort()
        return rv

    def get_command(self, ctx, name):
        ns = {}
        fn = os.path.join(self.plugin_folder, "cmd_"+ name + '.py')
        logger.debug(f"fn:{fn}")
        if os.path.exists(fn):
            with open(fn) as f:
                code = compile(f.read(), fn, 'exec')
                eval(code, ns, ns)
            ns = ns['cli']
        else:
            ns = None
        return ns


config = Configuration()

