""" docstring for cmd_update
"""
import os
import json
import click

from loguru import logger
import markdown

from cnvsapi.config import config, DEFAULT_LOG_LEVEL,ENV_TOKEN_NAME
from cnvsapi.utils import edit_list_with_editor, update_modules, update_moduleitems
from cnvsapi.bridge import bridge


def toFrame( url, style, codes ):
    return f"""
    <iframe style="{style}"  {codes} src="{url}" allowfullscreen="allowfullscreen" 
    allow="geolocation *; microphone *; camera *; midi *; encrypted-media *; autoplay *; clipboard-write *; display-capture *">
    </iframe>
    """

@click.group(invoke_without_command=True)
@click.option("--url",help="display details for this page URL",default=None)
@click.pass_context
def cli(ctx,url):
    """ Update assets on Canvas
        
    """
    logger.debug(f"PAGES: invoked subcommand: {ctx.invoked_subcommand}")
    logger.debug(f"PAGES: Inside cli routine")

    if ctx.invoked_subcommand is None and url is None:
        print(json.dumps(config.config["course"],indent=2))

    if url is not None:
        bridge.print_item("page",url,ctx)

@cli.command()
@click.pass_context
def sync(ctx):
    """ update local config file using values pulled from Canvas """
    
    # Loop over pages in Canvas adding any missing pages to the config file.
    def item_count( list,items ):
        """ returns count of items in list """
        value = 0
        for item in items:
            value = value + (1 if item in list.keys() else 0)
        return value
    logger.debug(f"course id: {config.course_id}")
    pages = config.get_canvas().get_course(config.course_id).get_pages()
    if not "course" in config.config.keys():
        config.config["course"] = {str(config.course_id):{"pages":{}}}
    if not str(config.course_id) in config.config["course"].keys():
        config.config["course"][str(config.course_id)] = {"pages":{}}
    if not "pages" in config.config["course"][str(config.course_id)].keys():
        config.config["course"][str(config.course_id)]["pages"] = {}
    cnf = config.config["course"][str(config.course_id)]["pages"]
    lookup = {}
    for page in pages:
        if not getattr(page,"url") in cnf.keys():
            cnf[getattr(page,'url')] = {"title":getattr(page,"title")}
        else:
            cnf[getattr(page,'url')]["title"] = getattr(page,"title")
        lookup[getattr(page,'url')] = getattr(page,"url")

    # loop over pages in config file, adding any missing pages to Canvas.
    for cp in cnf.keys():
        if not cp in lookup.keys():
            print(f"not found in lookup: {cp}")
            page = config.get_canvas().get_course(config.course_id).create_page(wiki_page={"title":cnf[cp]["title"],"body":"(empty page created by sync)"})
            # be careful to not wipe out any other attributes stored in local config file, e.g., google_doc or local_file
            if not cp==getattr(page,'url'):
                logger.warning(f"Invalid URL used to create page. Clean up your .cnvsapi (config:{cp}, canvas:{getattr(page,'url')})")
            if not getattr(page,'url') in cnf[cp].keys():
                cnf[cp][getattr(page,'url')] = {"title":getattr(page,"title")}
            if "title" in cnf[cp][getattr(page,'url')]:
                cnf[cp][getattr(page,'url')]["title"] = getattr(page,"title")

    # Update page bodies using attributes in file
    for cp in cnf.keys():
        page = cnf[cp]
        body = None
        method = None
        if item_count( page,['google_doc','local_file','iframe','url'])>1:
            print(f"Error: page may have only one source: {cp} - count: {item_count( page,['google_doc','local_file','iframe'])}")
        elif "google_doc" in page.keys():
            body = bridge.get_contents_from_google( page["google_doc"] )
            method = "google_doc"
        elif "local_file" in page.keys():
            body = bridge.get_contents_from_file( page["local_file"])
            method = "local_file"
        elif "iframe" in page.keys():
            body = page["iframe"]
            method = "iframe"
        elif "slideframe" in page.keys():
            method = "slideframe"
            style = "width:900px; height:500px" if not "style" in page.keys() else page["style"]
            extras = "" if not "codes" in page.keys() else (" "+page["codes"]+" ")
            body = toFrame( page["slideframe"],style,extras )
            body = ("" if not "text-above" in page.keys() else "<br/>"+markdown.markdown(page["text-above"])) + body
            body = body + ("" if not "text-below" in page.keys() else "<br/>"+markdown.markdown(page["text-below"]))
        elif "url" in page.keys():
            method = "url"
            style = "width:750px; height:750px" if not "style" in page.keys() else page["style"]
            extras = "" if not "codes" in page.keys() else (" "+page["codes"]+" ")
            body = toFrame( page["url"],style,extras)
            body = ("" if not "text-above" in page.keys() else "<br/>"+markdown.markdown(page["text-above"])) + body
            body = body + ("" if not "text-below" in page.keys() else "<br/>"+markdown.markdown(page["text-below"]))
        if body is not None:
            logger.debug(f"{config.course_id} :: {cp}")
            page = config.get_canvas().get_course(config.course_id).get_page(cp).edit(wiki_page={"body":body})
            logger.info(f"Updated contents of page: {cp} using {method}")
    
    config.save()

if __name__ == '__main__':
    cli(obj={})


