""" docstring for _main.py
"""
import os
import sys
import json
import click
from pprint import pprint
from collections.abc import Iterable

from loguru import logger
from canvasapi import Canvas

from cnvsapi.config import config, DEFAULT_LOG_LEVEL,ENV_TOKEN_NAME, ExternalCommandClass
from cnvsapi.utils import edit_list_with_editor, update_modules, update_moduleitems

from cnvsapi.bridge import bridge

@click.group()
def cli1():
    # this group callback is never called.
    pass


@cli1.command()
@click.option("--id",help="Course id to display",required=False,default=None)
@click.option("--add-to-config",help="Add available courses to config file",default=False,is_flag=True,show_default=True )
@click.pass_context
def courses( ctx,id,add_to_config ):
    """ List courses for a token
    """
#    logger.debug(f"ctx.obj['COURSE_ID']: {ctx.obj['COURSE_ID']}")
    if id is None:
        courses = config.get_canvas().get_courses()

        comments = ""
        for course in courses:
            line = f"{'' if course.id==config.course_id and not add_to_config else '# '}course_id={course.id:<8d} #  {course.name}"
            print( line )
            comments = comments + "\n" + line

        if add_to_config:
            config.addCourseComments( comments )
            click.echo("\nEdit config file and uncomment the desired course")
    else:
        bridge.print_item("course",id,ctx)


@cli1.command()
@click.option("--id",help="Assignment group id to display",required=False,default=None)
@click.pass_context
def assignmentgroups( ctx,id ):
    """ List assignment groups for a course
    """
    if id is None:
        bridge.print_list("assignment_groups",ctx)
    else:
        bridge.print_item("assignment_group",id,ctx)

@cli1.command()
@click.option("--id",help="User id to display",required=False,default=None)
@click.pass_context
def users( ctx, id ):
    """ List users for a course
    """
    if id is None:
        bridge.print_list("users",ctx)
    else:
        bridge.print_item("user",id,ctx)


@cli1.command()
@click.option("--edit",help="Edit list or individual module",required=False,is_flag=True)
@click.option("--id",help="Module id to display",required=False,default=None)
@click.pass_context
def modules( ctx,id,edit ):
    """ List modules for a course
    """
    if id is None:
        if edit:
            list = bridge.build_list("modules")
            modified_list = edit_list_with_editor( list )
            if list != modified_list:
                update_modules( ctx,modified_list )
            bridge.print_list("modules",ctx)
        else:
            bridge.print_list("modules",ctx)
    else:
        bridge.print_item("module",id,ctx)


@cli1.command()
@click.option("--id",help="Id of item to display",required=False,default=None)
@click.option("--parent-id",help="Id of parent module",required=False,default=None)
@click.option("--edit",help="Edit list or individual module",required=False,is_flag=True)
@click.pass_context
def moduleitems( ctx,id,parent_id,edit):
    """ List moduleitems for a course
    """
    if id is None:
        if edit:
            list = bridge.build_list("moduleitems")
            modified_list = edit_list_with_editor( list )
            if list != modified_list:
                update_moduleitems( ctx, modified_list )
            bridge.print_list("moduleitems",ctx)
        else:
            bridge.print_list("moduleitems",ctx)
    else:
        bridge.print_item("moduleitem",id,ctx,parent_id=parent_id)


@cli1.command()
@click.option("--id",help="Assignment id to display",required=False,default=None)
@click.pass_context
def rubrics( ctx,id ):
    """ List rubrics for a course
    """
    if id is None:
        bridge.print_list("rubrics",ctx)
    else:
        bridge.print_item("rubric",id,ctx)

@cli1.command()
@click.option("--id",help="Assignment id to display",required=False,default=None)
@click.pass_context
def outcomes( ctx,id ):
    """ List outcomes for a course
    """
    print("Not implemented yet. Tricky, outcomes cross multiple courses!")


@cli1.command()
@click.option("--endpoint",help="Canvas endpoint: canvas, course")
@click.option("--getter",help="function getter name")
@click.option("--arg1",help="Arbitrary arg 1 required by getter")
@click.pass_context
def explore(ctx, endpoint,getter,arg1 ):
    """ Access the canvas API directly. See --help for more details.
    """
    if endpoint in ["canvas","course"]:
        value = getattr(config,f"get_{endpoint}")()

        try:
            if getter is None:
                pprint(value)
                pprint(vars(value))
                pprint(dir(value))
                if isinstance(value,Iterable):
                    for item in value:
                        print(item)
            elif arg1 is None:
                for item in getattr(value,getter)():
                    print(item)
            else:
                pprint(getattr(value,getter)(arg1))
                if isinstance(value,Iterable):
                    for item in value:
                        print(item)
        except Exception as e:
            print(str(e))

    else:
        print(f"Unknown endpoint: {endpoint}")


@cli1.command()
@click.pass_context
def status( ctx ):
    """ Provide details about current program operation"""
    logger.debug(f"inside status: log_level:{ctx.obj['LOG_LEVEL']}")
    bridge.print_status()

@cli1.command()
@click.option("--id",help="id to display",required=False,default=None)
@click.pass_context
def enrollments( ctx,id ):
    """ List enrollments in course
    """
    if id is None:
        bridge.print_list("enrollments",ctx)
    else:
        bridge.print_item("enrollment",id,ctx)


@cli1.command()
@click.option("--from-file",help="local file to upload to syllabus",required=False,default=None,type=click.Path())
@click.option("--from-google",help="google doc to upload",required=False,default=None)
@click.pass_context
def syllabus( ctx, from_file, from_google ):
    """ Manage the syllabus. """
    if from_file is None and from_google is None:
        bridge.print_syllabus()
    elif from_file is not None:
        bridge.update_syllabus_from_file( from_file )
    elif from_google is not None:
        bridge.update_syllabus_from_google ( from_google )

@cli1.command()
@click.pass_context
def pull( ctx ):
    """ Pull data from Canvas to the .cnvsapi file """
    bridge.pull_from_canvas()

@cli1.command()
@click.pass_context
def push( ctx ):
    """ Push .cnvsapi data to Canvas """
    bridge.push_to_canvas()

@click.command( cls=ExternalCommandClass, plugin_folder=config.plugin_folder )
def cli2():
    """ This structure pulls in the externally stored commands. See config.py """
    pass

@click.group(cls=click.CommandCollection,sources=[cli1,cli2])
@click.version_option( package_name="cnvsapi" )
@click.option('--log-level', help="Set log level (TRACE, DEBUG, INFO, SUCCESS, WARNING, ERROR, CRITICAL)", default=config.log_level )
@click.option('--debug-vars', help="Show debug var details",default=False,is_flag=True)
@click.pass_context
def cli(ctx,log_level,debug_vars):
    """ Canvas CLI. 
    \n\n
    This command line interface (CLI) provides access to Canvas through the published canvas API.
    Some things are best left to the Canvas user interface, so this application doesn't try to do everything.
    However, sometimes the Canvas GUI is just too heavy or cludgy. So - this tool was created.
    
    """
    ctx.ensure_object( dict )
    ctx.obj['LOG_LEVEL'] = log_level
    ctx.obj['DEBUG_VARS'] = debug_vars

    if config.log_level != log_level:
        config.log_level = log_level
        logger.info(f"Log level set to {log_level} by --log-level argument.")

    logger.info(f"Subcommand:{ctx.invoked_subcommand}")

#    if ctx.invoked_subcommand in ['token','status','courses']:
#        pass
#    elif config.token is None:
#        sys.exit(1)
#    else:
#        ctx.obj['CANVAS'] = config.get_canvas()
#        if config.course_id is None:
#            click.echo(f"\nError: Missing option '--course-id' (require by {ctx.invoked_subcommand}, add option or edit .cnvsapi config file)")
#            sys.exit(1)
#        else:
#           ctx.obj['COURSE_ID'] = course_id
#            ctx.obj['COURSE'] = ctx.obj['CANVAS'].get_course( course_id )



if __name__ == "__main__":
    cli()
