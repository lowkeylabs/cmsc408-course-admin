""" docstring for cmd_assignments
"""
import os
import json
import click

from loguru import logger

from cnvsapi.config import config, DEFAULT_LOG_LEVEL,ENV_TOKEN_NAME
from cnvsapi.utils import edit_list_with_editor, update_modules, update_moduleitems
from cnvsapi.bridge import bridge, remove_html_tags

@click.group(invoke_without_command=True)
@click.option("--assign-id",help="display assignments info",type=int)
@click.pass_context
def cli(ctx,assign_id):
    """ List assignments for a course
    """
    ctx.obj["ASSIGN_ID"] = assign_id
    if ctx.invoked_subcommand is None:
        if assign_id is None:
            bridge.print_list("assignments",ctx)
        else:
            bridge.print_item("assignment",assign_id,ctx)

@cli.command()
@click.pass_context
def submissions(ctx):
    assign_id = ctx.obj["ASSIGN_ID"]
    logger.debug(f"assignment {assign_id}")
    assignment = config.get_canvas().get_course(config.course_id).get_assignment( assign_id )
    print(remove_html_tags( getattr(assignment,"description") ))
    if not getattr(assignment,"has_submitted_submissions"):
        print("Assignment has no submitted submissions.")
        return
#    if getattr(assignment,"is_quiz_assignment"):

    if 'online_quiz' in getattr(assignment,'submission_types'):
        responses = config.get_canvas().get_course(config.course_id).get_assignment( assign_id ).get_submissions(include=['submission_history'])
        questions = bridge.get_quiz_questions( getattr(assignment,"quiz_id"))
        users = bridge.get_users()
        for response in responses:
            if getattr(response,'missing'):
                print(f"{getattr(response,'user_id')} :: missing")
            else:
                user_id = getattr(response,'user_id')
                print(f"------ User: {user_id} :: FOUND")
                submission_history = getattr(response,'submission_history')
                submission =submission_history[len(submission_history)-1]
                logger.trace(submission)
                for answer in submission["submission_data"]:
                    logger.trace(answer)
                    logger.trace(questions)
                    username = f"(userid:{user_id})"
                    if user_id in users.keys():
                        username = users[user_id]['sortable_name']
                    question_text = f"(question:{answer['question_id']})"
                    if answer['question_id'] in questions.keys():
                        question_text = questions[answer['question_id']]['clean_text']
                    print(f"{username} :: {question_text} :: {answer['text']} {'(correct)' if answer['correct'] else '(incorrect)'}")


#        print(f"{users}")

if __name__ == '__main__':
    cli(obj={})


