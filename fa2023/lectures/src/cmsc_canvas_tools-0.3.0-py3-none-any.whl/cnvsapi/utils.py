"""
"""
import os
from loguru import logger
import tempfile
import subprocess
from pprint import pprint

from cnvsapi.config import config
from cnvsapi.bridge import bridge

def edit_list_with_editor(data):
    """ write a list to a file, edit it, and check for changes
    """
    # Create a temporary file
    with tempfile.NamedTemporaryFile(mode='w', delete=False,encoding="utf-8") as temp_file:
        # Write the list data to the temporary file
        temp_file.writelines('\n'.join(data))

    logger.trace(data)

    # Open the temporary file with the system editor
    editor = os.environ.get('EDITOR', 'notepad')  # Default to 'notepad' if the editor is not set
    subprocess.run([editor, temp_file.name])

    # Check if the file was modified
    with open(temp_file.name, 'r') as edited_file:
        modified_data = edited_file.readlines()
        modified_data = [line.strip() for line in modified_data]

    logger.trace(modified_data)
    # Compare the modified data with the original data
    return modified_data

def build_dict_of_module_changes( list,key_field ):
    dict = {}
    for i,line in enumerate(list):
        fields = line.split( config.get_default_split_code() )
        fields = [part.strip() for part in fields]
        d = {"id":int(fields[0]),"published":fields[1],"position":i+1,"unlock_at":fields[3],"name":fields[4]}
        d["published"] = True if d["published"]=="T" else False
        d["unlock_at"] = None if d["unlock_at"].lower() in ["","none"] else d["unlock_at"] 
        dict[d[key_field]] = d
    return dict

def build_dict_of_dicts( objects,key_field ):
    dict = {}
    for object in objects:
        d = {}
        for var in vars(object):
            d[var] = getattr(object,var)
        if key_field in d.keys():
            dict[d[key_field]] = d
        else:
            logger.debug(f"Missing {key_field} field in object: {str(object)}")
    return dict

def update_modules( ctx, list ):
    logger.info('Updating modified list')
    modules = ctx.obj['COURSE'].get_modules()
    original = build_dict_of_dicts( modules,"id" )
    modified = build_dict_of_module_changes( list, "id" )

    # build list of changes in order of 
    list_of_changes = {}
    for mod in modified.values():
        id = mod["id"]
        changes = {}
        for key in mod.keys():
            if mod[key] != original[id][key]:
                logger.debug(f"changing: id:{id} field:{key} from:{original[id][key]} to:{mod[key]}")
                changes[key] = "" if mod[key] is None else mod[key]
        if len(changes)>0:
            list_of_changes[id] = changes

    # process the list, one module at a time.
    for module in modules:
        if module.id in list_of_changes.keys():
            changed = module.edit( module=list_of_changes[module.id] )
            logger.debug(f"changed: {changed}" )

    return


def update_moduleitems( ctx, list ):
    logger.info('Updating modified module_items')
    print("Moduleitems update is not implemented.")
    # this should look a lot like update_modules!
    return


def update_syllabus( ctx, syllabus_file ):
    logger.info("Updates syllabus")
    print("update syllabus not implemented. See utils.py")
    return
