"""
"""
import os
import re
import sys
import json
import pprint
import warnings
import pandas as pd
from loguru import logger
from cnvsapi.config import config
from canvasapi import Canvas

from oauth2client.service_account import ServiceAccountCredentials
from googleapiclient.discovery import build
from google.oauth2 import service_account
import gspread
from bs4 import BeautifulSoup

def remove_html_tags(text):
    clean_text = re.sub('<.*?>', '', text)  # Remove HTML tags using regex
    clean_text = re.sub(r'[\x00-\x08\x0B-\x0C\x0E-\x1F\x7F-\x9F]+', '', clean_text)  # Remove HTML tags using regex
    clean_text = re.sub(r'&nbsp;', ' ', clean_text, flags=re.IGNORECASE)
    clean_text = re.sub(r'  ', ' ', clean_text)
    return clean_text

def dump_object( obj ):
    longest_field_name = len(max(vars(obj),key=len))
    fmt = f">{longest_field_name}s"
    for key in vars(obj):
        ff = f"{str(key):{fmt}}"
        print(f"{ff} {config.default_split_code} {getattr(obj,key)}")


class MyModuleWrapper:
    """ Mutator class. Ensures consistence of class across different canvasapi objects """
    def __str__(self):
        return f"{self._object.name} ({self._object.id})"
    
    def __init__(self,object):
        self._object = object
    
    @property
    def id(self):
        return self._object.id

    @property
    def module_id(self):
        return self._object.id
    
    @property
    def title(self):
        return self._object.name
    
    @property
    def type(self):
        return "Module"

    @property
    def position(self):
        return 0

    @property
    def published(self):
        return self._object.published

    @property
    def indent(self):
        return 0


class CanvasBridge(dict):
    """ A abstract mapper to streamline calls to the canvas api.
    The class itself is a dictionary of canvas object names. For each name
    the class stores the canvasapi method to retrieve the data, and highlights
    select fields to include in the __str__ printout.
    This routine is used extensively by 'bridge.get_object'
    """
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self["modules"] = {
            "getter":"get_modules",
            "fields": [
                {"field":"id","fmt":"7s"},
                {"field":"published","bool":True},
                {"field":"position","fmt":">2s"},
                {"field":"unlock_at","fmt":"<20s"},
                {"field":"name"}
            ]
        }

        self["moduleitems"] = {
            "getter":"get_modules",
            "subgetter":"get_module_items",
            "fields": [
                {"field":"module_id","fmt":">7s"},
                {"field":"id","fmt":">7s"},
                {"field":"published","bool":True},
                {"field":"position","fmt":">2s"},
                {"field":"indent","fmt":"1s"},
                {"field":"type","fmt":"<10s"},
                {"field":"title"}
            ]
        }

        self["moduleitem"] = {
            "getter":"get_module",
            "subgetter":"get_module_item"
        }

        self["courses"] = {
            "endpoint": "get_canvas",
            "getter":"get_courses",
        }

        self["course"] = {
            "endpoint":"get_canvas",
            "getter":"get_course",
            "fields": [
                {"field":"id","fmt":"7s"},
                {"field":"published","bool":True},
                {"field":"position","fmt":">2s"},
                {"field":"unlock_at","fmt":"<20s"},
                {"field":"name"}
            ]
        }

        self["assignment_groups"] = {
            "getter":"get_assignment_groups",
            "fields": [
                {"field":"id","fmt":"7s"},
                {"field":"position","fmt":">2s"},
                {"field":"group_weight","fmt":">6s"},
                {"field":"name"}
            ]
        }

        self["assignment_group"] = {
            "getter":"get_assignment_group",
            "fields": [
                {"field":"id","fmt":"7s"},
                {"field":"position","fmt":">2s"},
                {"field":"group_weight","fmt":">6s"},
                {"field":"name"}
            ]
        }

        self["users"] = {
            "getter":"get_users",
            "fields": [
                {"field":"id","fmt":">7s"},
                {"field":"name"},
                {"field":"email"}
            ]
        }

        self["user"] = {
            "getter":"get_user",
        }

        self["pages"] = {
        }

        self["page"] = {
        }

        self["assignments"] = {
            "getter":"get_assignments",
            "fields": [
                {"field":"assignment_group_id","fmt":"7s"},
                {"field":"id","fmt":"7s"},
                {"field":"published","bool":True},
                {"field":"points_possible","fmt":">5s"},
                {"field":"submission_types","fmt":"<25s"},
                {"field":"name"}
            ]
        }

        self["assignment"] = {
        }

        self["quizzes"] = {
        }

        self["quiz"] = {
        }

        self["outcomes"] = {
        }

        self["enrollments"] = {
            "getter":"get_enrollments",
            "fields":[
                {"field":"id","fmt":"7s"},
                {"field":"sis_user_id","fmt":"10s"},
                {"field":"enrollment_state","fmt":"9s"},
                {"field":"type","fmt":"21s"},
                {"field":"grades","subfield":"current_score","fmt":">7s"},
                {"field":"total_activity_time","fmt":">8s"},
                {"field":"last_activity_at","fmt":"<20s"},
                {"field":"user","subfield":"name","fmt":"15s"},
                {"field":"user","subfield":"login_id","fmt":"12s"}
            ]
        }

    def get_object( self, list_name, id=None, id2=None ):
        endpoint,getter,subgetter = self.get_connections( list_name )
        logger.debug(f"{list_name}: endpoint:{endpoint}, getter:{getter}")
        self.verify_getter( list_name,getter )
        list = (getattr(getattr(config,endpoint)(),getter))();
        if subgetter is not None:
            templist = []
            for item in list:
                logger.debug(f"item: {item}")
                templist.append( MyModuleWrapper(item) )
                sublist = getattr(item,subgetter)()
                for subitem in sublist:
                    templist.append( subitem )
            list = templist
        return list


    def format_list_item( self, item, name ):
        line = ""
        if name not in self:
            return str(item)
        elif "fields" not in self[name]:
            return str(item)
        else:
            for i,field in enumerate(self[name]["fields"]):
                if i>0:
                    line = f"{line} {config.default_split_code} "
                formatted_field = None
                f1 = None
                f2 = None
                if "field" in field.keys():
                    f1 = field['field']
                    if "subfield" in field.keys():
                        f2 = field['subfield']
                if f1 is not None and hasattr(item,f1):
                    formatted_field = f"{getattr(item,f1)}"
                    if f2 is not None and isinstance(getattr(item,f1),dict) and f2 in getattr(item,f1).keys():
                        formatted_field = f"{getattr(item,f1)[f2]}"
                if formatted_field is None or formatted_field=="None":
                    formatted_field = ""
            
                if "fmt" in field.keys():
                    formatted_field = f"{str(formatted_field):{field['fmt']}}"
                if "bool" in field.keys():
                    formatted_field = f"{'T' if getattr(item,f1) else 'F'}"
                if "type" in field.keys():
                    formatted_field = f"type:{type(getattr(item,f1))}"

                line = f"{line}{formatted_field}"
        return line

    def verify_name( self,list_name ):
        if list_name not in self:
            logger.warning(f"Missing bridge entry for: {list_name}. Edit bridge.py")
        elif "fields" not in self[list_name]:
            logger.warning(f"Missing field entries for: {list_name}. Edit bridge.py")
        return list_name

    def verify_getter( self, list_name, getter ):
        ln = self.verify_name( list_name )
        if list_name not in self:
            logger.warning(f"Missing bridge entry for: {list_name}")
        elif "fields" not in self[list_name]:
            logger.warning(f"Missing field entry for: {list_name}")

    def get_connections( self, list_name ):
        endpoint = "get_course"
        getter = f"get_{list_name}"
        subgetter = None
        subgetter_id = None
        if list_name in self.keys():
            if "getter" in self[list_name]:
                getter = self[list_name]["getter"]
            if "endpoint" in self[list_name]:
                endpoint = self[list_name]["endpoint"]
            if "subgetter" in self[list_name]:
                subgetter = self[list_name]["subgetter"]
        return endpoint, getter, subgetter
    
    def build_list( self, list_name ):
#        endpoint,getter = self.get_connections( list_name )
#        logger.debug(f"{list_name}: endpoint:{endpoint}, getter:{getter}")
#        self.verify_getter( list_name,getter )
#        list = (getattr(getattr(config,endpoint)(),getter))();
        list = self.get_object( list_name )

        text = []
        for item in list:
            text.append( self.format_list_item( item,list_name ) )

        return text
    
    def build_item( self,name,id,ctx,parent_id=None ):
        endpoint,getter,subgetter = self.get_connections( name )
        logger.debug(f"{name}: endpoint:{endpoint}, getter:{getter}")
        self.verify_getter( name,getter )
        temp_id = id
        if subgetter is not None:
            temp_id = parent_id

        item = (getattr(getattr(config,endpoint)(),getter))(temp_id);

        if subgetter is not None:
            item = getattr( item,subgetter )( id )
        
        longest_field_name = len(max(vars(item),key=len))
        fmt = f">{longest_field_name}s"
        logger.debug(f"longest_field_name: {longest_field_name}, fmt:{fmt}")
        text = []
        for field in vars(item):
            if field not in ['_requester']:
                ff = f"{str(field):{fmt}}"
                text.append(f"{ff} {config.default_split_code} {getattr(item,field)}")
        return text
    
    def get_item( self,name,id,parent_id=None,**kwargs):
        endpoint,getter,subgetter = self.get_connections( name )
        logger.debug(f"{name}: endpoint:{endpoint}, getter:{getter}")
        self.verify_getter( name,getter )
        temp_id = id
        if subgetter is not None:
            temp_id = parent_id

        item = (getattr(getattr(config,endpoint)(),getter))(temp_id,**kwargs);

        if subgetter is not None:
            item = getattr( item,subgetter )( id )
        
        list = {}
        for field in vars(item):
            if field not in ['_requester']:
                list[field] = getattr(item,field)

        return list


    def print_item( self,name,id,ctx,parent_id=None ):
        fields = self.build_item( name, id, ctx, parent_id)
        for field in fields:
            print(field)

    def print_list( self, list_name, ctx ):
        list = self.build_list( list_name )
        for item in list:
            print( item )

    def get_status( self ):
        list = {}
        list["program_name"] = config.program_name
        list["config_file"] = f"{config.config_file_name} ({'exists' if os.path.isfile( config.config_file_name ) else 'not exists'})"
        list["current_dir"] = os.getcwd()
        list["log_level"] = config.log_level
        list["keyring namespace"] = config.namespace
        list["token"] = f"({'Found' if config.token is not None else 'Not found. See: cnvsapi token'})"
        list["canvas_url"] = config.canvas_url
        list["course_id"] = config.course_id
        list["course_name"] = None
        if list["course_id"] is not None:
            temp = self.get_item("course", id=list["course_id"])
            list["course_name"] = temp["name"]
        return list

    def print_status( self ):
        data = self.get_status()
        max_key_length = max(len(key) for key in data.keys()) + 1
        for key, value in data.items():
            print(f'{key.rjust(max_key_length)}: {value}')

    def print_syllabus( self ):
        course = self.get_item("course",config.course_id,include=['syllabus_body'])
#        course = config.get_canvas().get_course(config.course_id,include=['syllabus_body'])
        print(f"{course['syllabus_body']}")

    def update_syllabus_from_file( self, syllabus_filename ):
        """ Update syllabus on Canvas using a local file. """
        with open(syllabus_filename,'r') as file:
            syllabus_body = file.read()
            course = config.get_canvas().get_course(config.course_id).update(course={'syllabus_body':f"{syllabus_body}"})
            file.close()
        self.print_syllabus()

    def write_df_to_gsheet( self, df, gsheet_id, gsheet_tab='Source data' ):
        """ write dataframe to google sheets """
        # Set up credentials
        logger.debug(f"sheet_id: {gsheet_id}  ::  gsheet_tab:{gsheet_tab}")
        scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/spreadsheets",
                "https://www.googleapis.com/auth/drive.file", "https://www.googleapis.com/auth/drive"]
        creds = ServiceAccountCredentials.from_json_keyfile_name(config.gsecrets, scope)
        client = gspread.authorize(creds)

        # Open the Google Sheet and create/use the tab. Add it if it doesn't exist.
        spreadsheet = client.open_by_key(gsheet_id)
        try:
            worksheet = spreadsheet.worksheet(gsheet_tab)  # You can specify the worksheet index (0 for the first sheet)
        except gspread.exceptions.WorksheetNotFound:
            worksheet = spreadsheet.add_worksheet(title=gsheet_tab,rows=1000,cols=10)

        # Clear existing content (optional)
        worksheet.clear()

        # Write DataFrame to Google Sheet
        warnings.filterwarnings("ignore", category=UserWarning, message=".*[Dd]eprecated.*")
        worksheet.update([df.columns.tolist()] + df.values.tolist())
        warnings.resetwarnings()

    def get_contents_from_google( self, google_doc_id ):
        """ Update syllabus on Canvas using a Google doc """
        credentials = service_account.Credentials.from_service_account_file(
            config.gsecrets,
            scopes=['https://www.googleapis.com/auth/drive.readonly']
        )

        service = build('drive', 'v3', credentials=credentials)
        logger.debug(f"service: {service}")

        # Request the Google Doc's content as HTML
        response = service.files().export(fileId=google_doc_id, mimeType='text/html').execute()

        # Parse the HTML response using BeautifulSoup
        html_content = response.decode('utf-8')  # Decode the response as it's returned as bytes
        soup = BeautifulSoup(html_content, 'html.parser')

        # Perform any required modifications to the HTML
        # ...

        # Save the modified HTML to a file
#        output_file = 'temp-syllabus.html'
#        with open(output_file, 'w', encoding='utf-8') as file:
#            file.write(str(soup))
   
        return str(soup)
    
    def get_contents_from_file( self, filename ):
        """ Update page on Canvas using a local file. """
        body = None
        with open(filename,'r',encoding="utf-8") as file:
            body = file.read()
            file.close()
        return body

    def update_syllabus_from_google( self, google_doc_id ):
        """ Update syllabus on Canvas using a Google doc """
        credentials = service_account.Credentials.from_service_account_file(
            config.gsecrets,
            scopes=['https://www.googleapis.com/auth/drive.readonly']
        )

        service = build('drive', 'v3', credentials=credentials)
        logger.debug(f"service: {service}")

        # Request the Google Doc's content as HTML
        response = service.files().export(fileId=google_doc_id, mimeType='text/html').execute()

        # Parse the HTML response using BeautifulSoup
        html_content = response.decode('utf-8')  # Decode the response as it's returned as bytes
        soup = BeautifulSoup(html_content, 'html.parser')

        # Perform any required modifications to the HTML
        # ...

        # Save the modified HTML to a file
        output_file = 'temp-syllabus.html'
        with open(output_file, 'w', encoding='utf-8') as file:
            file.write(str(soup))
            
        print(f"Google Doc converted to HTML and saved to {os.path.abspath(output_file)}")

        course = config.get_canvas().get_course(config.course_id).update(course={'syllabus_body':f"{str(soup)}"})
#        self.print_syllabus()


    def update_page_from_file( self, filename ):
        """ Update page on Canvas using a local file. """
        with open(filename,'r') as file:
            syllabus_body = file.read()
            file.close()
            pages = config.get_canvas().get_course(config.course_id).get_pages()
            for page in pages:
                print(f"Updated page from file: {getattr(page,'title')}")

    def update_page_from_google( self, google_doc_id ):
        print(f"updating page from google doc: {google_doc_id}")

    def freshen_from_canvas_pages( self ):
        pages = config.get_canvas().get_course(config.course_id).get_pages()
        print(f"pages")

    def get_quiz_questions( self, quiz_id ):
        qq = {}
        logger.debug(f"retrieving data for quiz: {quiz_id}")
        questions = config.get_canvas().get_course(config.course_id).get_quiz( quiz_id ).get_questions()
        qq[quiz_id] = {}
        for question in questions:
            logger.trace(f"{question}")
            ques_id = getattr(question,"id")
            qq[quiz_id][ques_id] = {}
            q = qq[quiz_id][ques_id]
            for var in vars(question):
                q[var] = getattr(question,var)
                if var=="answers":
                    answers = q[var]
                    q['answer_dict'] = {}
                    for answer in answers:
                        q['answer_dict'][answer['id']] = answer
            q["clean_text"] = remove_html_tags(getattr(question,"question_text"))
        logger.trace(f"{qq}")
        return qq[quiz_id]

    def get_all_quizzes_and_questions( self ):
        qq = {}
        logger.debug("starting query for all quizzes and questions")
        quizzes = self.get_object("quizzes")
        for quiz in quizzes:
            quiz_id = getattr(quiz,"id")
            qq[quiz_id] = self.get_quiz_questions( quiz_id )
        return qq
    
    def get_quiz_responses( self, quiz_id ):
        """ Return quiz questions and responses as a dataframe """
        # get quiz questions and answers
        quiz = self.get_quiz_questions( quiz_id )
        users = self.get_users()
        # get assignment_id that corresponds to current quiz. Note that
        # quiz responses are stored in the assignment structure.
        assignment_id = getattr(config.get_canvas().get_course(config.course_id).get_quiz( quiz_id ),'assignment_id')
        responses = config.get_canvas().get_course(config.course_id).get_assignment(assignment_id).get_submissions(include=['submission_history'])
        # create the final dataframe
        rows = []
        headers = None
        for response in responses:
            user_id = getattr(response,'user_id')
            sortable_name = 'zzz test user'
            email = 'missing'
            sis_user_id = 'missing'
            if user_id in users.keys():
                sortable_name = users[user_id]['sortable_name'] if 'sortable_name' in users[user_id].keys() else 'missing'
                email = users[user_id]['email'] if 'email' in users[user_id].keys() else 'missing'
                sis_user_id = users[user_id]['sis_user_id'] if 'sis_user_id' in users[user_id].keys() else 'missing'
            new_row = [sortable_name,email,sis_user_id]
            new_header = ['sortable_name','email','sis_user_id/vid']
            if hasattr(response,'submission_history'):
                history = None
                id = None
                # capture the latest submission. There may be multiple submissions,
                # we'll use the last submission.
                for temp_id,temp_history in enumerate(getattr(response,'submission_history')):
                    history = temp_history
                    id = temp_id
                logger.trace(history)
                if 'submission_data' in history.keys():
                    # print submissions
                    for answer in history['submission_data']:
                        logger.trace(f"{quiz[answer['question_id']]['clean_text']}")
                        possible_answers = quiz[answer['question_id']]['answers'] 
                        for possible_answer in possible_answers:
                            logger.trace(f"{possible_answer['id']}::{possible_answer['text']}")
                        if 'answer_id' in answer.keys() and answer['text']==str(answer['answer_id']):
                            answer['text'] = quiz[answer['question_id']]['answer_dict'][answer['answer_id']]['text']
                        logger.trace(f"{getattr(response,'user_id')}::{quiz[answer['question_id']]['position']}::{quiz[answer['question_id']]['clean_text']}::{answer['question_id']}::{answer['text']}")
                        new_row.append(answer['text'])
                        new_header.append(quiz[answer['question_id']]['clean_text'])
                    if headers==None:
                        headers = new_header
                else:
                    logger.trace(f"{quiz_id}::{assignment_id}::{getattr(response,'user_id')}::'missing submission_data'")
            else:
                logger.trace(f"{quiz_id}::{assignment_id}::{getattr(response,'user_id')}::'missing submission_history'")
            rows.append( new_row )
        df = pd.DataFrame( rows, columns=headers )
        df["count"] = 1
        return df

    def get_users( self ):
        users = self.get_object("users")
        userdict = {}
        for user in users:
            userdict[user.id] = {}
            for field in vars(user):
                if not field in ['_requester']:
                    userdict[user.id][field] = getattr(user,field)
        return userdict

    def pull_from_canvas( self ):
        """ pull data from canvas and store in .cnvsapi """
        logger.debug("Pull from Canvas")

        # Update pages and page data, alerting if pages are:
        # - in Canvas but not in .cnvsapi (add them to .cnvsapi)
        # - in .cnvsapi but not in Canvas (delete from .cnvsapi)
        # If not done correctly, pages will be scattered across the world!

        # Update quizzes. Same logic as above.

    def push_to_canvas( self ):
        """ push cnvsapi data data to Canvas """
        logger.debug("Push to Canvas")





bridge = CanvasBridge()


if __name__ == "__main__":
    print( bridge )




