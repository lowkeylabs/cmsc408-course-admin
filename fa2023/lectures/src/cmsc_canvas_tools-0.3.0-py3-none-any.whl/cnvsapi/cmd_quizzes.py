""" docstring for cmd_update
"""
import os
import re
import json
import click

from loguru import logger
import markdown
import pandas as pd

from cnvsapi.config import config, DEFAULT_LOG_LEVEL,ENV_TOKEN_NAME
from cnvsapi.utils import edit_list_with_editor, update_modules, update_moduleitems
from cnvsapi.bridge import bridge


@click.group(invoke_without_command=True)
@click.option("--quiz-id",help="Display details for this quiz ID",default=None,type=int)
@click.pass_context
def cli(ctx,quiz_id):
    """ Update assets on Canvas
        
    """
    """ List assignments for a course
    """
    ctx.obj["QUIZ_ID"] = quiz_id

    if ctx.invoked_subcommand is None:
        if quiz_id is None:
            bridge.print_list("quizzes",ctx)
        else:
            bridge.print_item("quiz",quiz_id,ctx)

@cli.command()
@click.pass_context
def pull(ctx):
    """ Get quiz info and add it to cnvsapi. Canvas data overrides local .cnvsapi data."""
    qq = bridge.get_all_quizzes_and_questions()
    for quiz_id in qq.keys():
        for ques_id in qq[quiz_id].keys():
            print(f"{quiz_id}:{ques_id}:{qq[quiz_id][ques_id]['position']}:{qq[quiz_id][ques_id]['clean_text']}")

#    if ctx.obj["QUIZ_ID"] is None:
#        print("Pull command requires --quiz-id")
#    else:
#        quiz_id = ctx.obj["QUIZ_ID"]
#        print(f"responses for {quiz_id}")
#        submissions = config.get_canvas().get_course(config.course_id).get_quiz( quiz_id ).get_submissions()
#        logger.debug(f"quiz_id: {quiz_id}")
#        for submission in submissions:
#            print(f"user_id: {getattr(submission,'user_id')}; submission_id: {getattr(submission,'submission_id')}")
#            print(vars(submission))
#            if getattr(submission,"submission_id")==25546116:
#                answers = config.get_canvas().get_course(config.course_id).get_qui
#                print(f"{answers}")


@cli.command()
@click.option('--to-xlsx',help="Store responses to excel workbook")
@click.option('--to-gsheet-id',help="Store responses to google sheet")
@click.option('--to-gsheet-tab',default='Source data',help="Name of tab in gsheet for data")
@click.pass_context
def responses(ctx,to_xlsx,to_gsheet_id,to_gsheet_tab):
    """ Get responses for specific quiz """
    print(f"responses for {ctx.obj['QUIZ_ID']}")
    quiz_id = ctx.obj["QUIZ_ID"]
    if quiz_id is None:
        print('missing quiz_id')
    else:
        logger.debug(f"course: {config.course_id} :: assignment: {quiz_id} ")
        # get quiz questions and answers
        if not to_xlsx is None:
            df = bridge.get_quiz_responses( quiz_id )
            df.to_excel( to_xlsx )
        elif not to_gsheet_id is None:
            df = bridge.get_quiz_responses( quiz_id )
            bridge.write_df_to_gsheet( df, to_gsheet_id, to_gsheet_tab )
        else:
            print('needs a storage location')


@cli.command()
@click.option("--id",help="Display details for this question ID",default=None,type=int)
@click.pass_context
def questions(ctx,id):
    if ctx.obj["QUIZ_ID"] is None:
        qq = bridge.get_all_quizzes_and_questions()
        for quiz_id in qq.keys():
            for ques_id in qq[quiz_id].keys():
                print(f"{quiz_id}:{ques_id}:{qq[quiz_id][ques_id]['position']}:{qq[quiz_id][ques_id]['clean_text']}")
    else:
        quiz_id = ctx.obj["QUIZ_ID"]
        logger.debug(f"Gathering data for quiz {quiz_id}")
        quiz = bridge.get_quiz_questions( quiz_id )
        if id is None:
            for ques_id in quiz:
                print("-----")
                print(f"{quiz_id}:{ques_id}:{quiz[ques_id]['position']}:{quiz[ques_id]['question_type']}:{quiz[ques_id]['clean_text']}")
                for id,answer in enumerate(quiz[ques_id]['answers']):
                    print(f"{id}: {answer['id']}: {answer['text']}")
        else:
            ques_id = id
            logger.debug(f"{quiz.keys()}")
            for key in quiz[ques_id]:
                print(f"{quiz_id}:{ques_id}:{quiz[ques_id]['position']}:{key}:{quiz[ques_id][key]}")


if __name__ == '__main__':
    cli(obj={})


