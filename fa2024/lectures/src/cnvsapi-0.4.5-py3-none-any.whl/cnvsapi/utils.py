"""
"""
import json
from loguru import logger
from datetime import datetime

def custom_encoder(obj):
    """ A custom decoder for json.dumps """
    if isinstance(obj, datetime):
        return obj.strftime('%Y-%m-%d %H:%M:%S')  # Convert datetime to a string
    elif obj.__class__.__name__=="File":
        return "file"
    else:
        try:
            # Attempt to serialize the object, and if it raises a TypeError, catch it
            json.dumps(obj)
        except TypeError:
            raise TypeError(f"Object of type {obj.__class__.__name__} is not JSON serializable in custom encoder")
        return obj
    

def as_pretty_json( object,indent=3 ):
    """ Returns a formatted json representation of a python object """
    return json.dumps( object, indent=indent, default=custom_encoder)

