""" docstring for cmd_template
"""
import os
import re
import json
import click

from loguru import logger
import markdown
import pandas as pd

from cnvsapi.utils import as_pretty_json
from cnvsapi.config import config, DEFAULT_LOG_LEVEL,ENV_TOKEN_NAME


@click.group(invoke_without_command=True)
@click.option("--course-id",help="Set default course ID.  This overrides .cnvsapi",default=None,type=int)
@click.pass_context
def cli(ctx,course_id):
    """ Course management utilities
    """
    if not course_id is None:
        ctx.obj["COURSE_ID"] = course_id
        config.course_id = course_id
    if ctx.invoked_subcommand is None:
        print(f"Default course id: {config.course_id}")


@cli.command()
@click.pass_context
def dummy(ctx):
    pass

if __name__ == '__main__':
    cli(obj={})


