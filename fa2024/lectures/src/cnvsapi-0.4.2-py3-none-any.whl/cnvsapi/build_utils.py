"""
Utility files to support build command
"""
import os
import re
import sys
import json
import click
import shutil
import gspread
import datetime
import frontmatter
import pandas as pd

#import numpy as np
from loguru import logger
from tabulate import tabulate
from cnvsapi.config import config
from IPython.display import Markdown, HTML, display
from oauth2client.service_account import ServiceAccountCredentials


def get_list_of_local_lecture_files():
    """ retrieves list of local lecture files """
    lecture_files = [filename for filename in os.listdir(".") if os.path.isfile(filename) and re.match(r"lecture-\d\d", filename) and os.path.splitext(filename)[1]==".qmd" ]
    logger.debug( lecture_files )
    return lecture_files

def getClient():
    """ return hardcoded client. Get more crazy if you want. """
    # create credentials object
    credential_file = os.path.join(os.path.expanduser("~"), ".gsecrets", "gsheets-credentials.json")
    if not os.path.isfile( credential_file ):
      print("Missing credential file:",credential_file)
      sys.exit()

    # this isn't used, but is helpful if you want to look inside the json.
    with open(credential_file, 'r') as f:
      # Load the JSON data from the file into a Python object
      data = json.load(f)

    # authorize the client
    try:
        scope = config.config["application"]["google_scope"]
    except Exception as e:
        scope = ['https://spreadsheets.google.com/feeds', 'https://www.googleapis.com/auth/drive']
    creds = ServiceAccountCredentials.from_json_keyfile_name(credential_file, scope)
    client = gspread.authorize(creds)

    return client

def reformat_date(date_str):
    """ takes a date string line like "1/9" and returns with leading 0 like "01/09".
    Totally necessary for proper sorting and searching of dates.
    """
    [mon,day] = date_str.split("/")
    return f"{int(mon):02d}/{int(day):02d}"

def get_spreadsheet_key():
    return config.outline_gsheet_key

def load_course_outline_df():
    """ load course outline tab and return a dataframe """
    client = getClient()
    spreadsheet_key = get_spreadsheet_key()
    outline = client.open_by_key(spreadsheet_key).worksheet("Outline").get_all_values()
    outline = outline[3:len(outline)]
    outline_df = pd.DataFrame( outline[1:],columns=outline[0])
#    logger.debug(f"outline_df: {outline_df}")
    return outline_df

def load_course_summary():
    """Load course summary tab and return a data frame."""
    worksheet_name = "Course Summary"
    spreadsheet_key = get_spreadsheet_key()
    client = getClient()
    sheet = client.open_by_key(spreadsheet_key).worksheet(worksheet_name)
    all_rows = sheet.get_all_values()
    all_rows = all_rows[3:len(all_rows)]
    # now pick just the first 6 columns

    df = pd.DataFrame(all_rows)
    df = df.iloc[:, :6]
    df.columns=["Module","Week","Date","Day","Lectures","Deliverables/Notes"]
    df = df.reset_index(drop=True)
    logger.debug(df)
    return df

def retry_loop( max_retries, func ):
    """ Try/catch the load for three times """
    for retry in range(max_retries):
        try:
            result = func()  # Call the provided function
            return result    # Return the result if successful
        except Exception as e:
            logger.debug(f"Attempt {retry + 1} failed: {e}")
    
    logger.error("All attempts failed. Returning None.")
    sys.exit(1)

def load_calendar( lecture_id, n_rows = 8 ):
    """ load course outline, use this to pull n_rows starting with lecture_id from course summary """

    outline_df = retry_loop( 3, load_course_outline_df)

    logger.debug(f"outline_df: {outline_df}")
    lecture_date = reformat_date( outline_df[outline_df['Lecture ID']==str(lecture_id)]["Date"].to_list()[0] )

    df = retry_loop( 3, load_course_summary )

    cmp = df["Date"].apply(reformat_date)

    df = df[ cmp>=lecture_date ].head( n_rows )
    return df

def extract_lectures( week=None ):
    """ load course outline and extract lecture content """
    def to_int( s ):
        return None if s=='' else int(s)
    
    outline_df = retry_loop(3,load_course_outline_df)
    if week==None:
        lecture_df = outline_df[outline_df['Lecture ID'].apply(to_int)>0]
    else:
        lecture_df = outline_df[(outline_df['Lecture ID'].apply(to_int)>0) & (outline_df['WK'].apply(to_int)==week)]
    return lecture_df

def extract_quizzes( week=None):
    """ load course outline and extract quiz content """
    def to_int( s ):
        return None if s=='' else int(s)
    outline_df = retry_loop(3,load_course_outline_df)
    if week==None:
        df = outline_df[outline_df['Quiz ID'].apply(to_int)>0]
    else:
        df = outline_df[(outline_df['Quiz ID'].apply(to_int)>0) & (outline_df['WK'].apply(to_int)==week)]
    return df

def extract_homeworks( week=None):
    """ load course outline and extract homework content """
    def to_int( s ):
        return None if s=='' else int(s)
    outline_df = retry_loop(3,load_course_outline_df)
    if week==None:
        df = outline_df[outline_df['HW ID'].apply(to_int)>0]
    else:
        df = outline_df[(outline_df['HW ID'].apply(to_int)>0) & (outline_df['WK'].apply(to_int)==week)]
    return df

def extract_meetings( week=None):
    """ load course outline and extract class meeting content """
    def to_int( s ):
        return None if s=='' else int(s)
    outline_df = retry_loop(3,load_course_outline_df)
    if week==None:
        df = outline_df[outline_df['Meeting ID'].apply(to_int)>0]
    else:
        df = outline_df[(outline_df['Meeting ID'].apply(to_int)>0) & (outline_df["WK"].apply(to_int)==week)]
    return df

def extract_weeks():
    """ load course outline and extract class meeting content """
    def to_int( s ):
        return None if s=='' else int(s)
    outline_df = retry_loop(3,load_course_outline_df)
    df = outline_df[outline_df['WK'].apply(to_int)>0].groupby('WK').first().reset_index()
    df["WK"] = df["WK"].astype(int)
    df = df.sort_values(by="WK").reset_index()
    return df

def add_lecture_file_names( lecture_df ):
    """ Add lecture filename column to data frame"""
    def clean_title( s ):
        s = s.replace(' ', '-')
        s = re.sub(r'[^\w\s-]', '-', s)
        s = re.sub(r'-+', '-', s)
        return s.lower().rstrip("-")
    lecture_df["basename"] = "lecture-" + lecture_df["Lecture ID"].apply( lambda x:f"{int(x):02d}")
#    lecture_df["filename"] = lecture_df["basename"] + "-" + lecture_df["Lecture Title / Topics"].apply( clean_title ) + ".qmd"
    lecture_df["filename"] = lecture_df["basename"] + ".qmd"
    lecture_df["html_filename"] = lecture_df["basename"] + ".html"
    return lecture_df

def get_lecture_df():
    """ Filter out lecture rows from"""
    return add_lecture_file_names( extract_lectures())

def create_qmd_file( filename ):
    logger.info(f"Creating file: {filename}")
    try:
        template_qmd_file = config.lecture_slides_template
    except KeyError:
        click.echo(f"Missing [lecture][template_qmd_file]")
        sys.exit()
    except FileNotFoundError:
        click.echo(f"Missing template file: {template_qmd_file}")
        sys.exit()
    except Exception as e:
        click.echo(f"Exception: {e}")
        sys.exit()
    shutil.copy(template_qmd_file, filename)

def rename_qmd_file( oldname, filename ):
    logger.info(f"renaming from {oldname} to {filename}")
    os.rename( oldname, filename )

def sync_yaml_header( filename, row ):
    logger.info(f"syncing yaml header for: {filename}")
    # Load the file with front matter
    with open(filename, "r",encoding='utf-8') as file:
        content = frontmatter.loads(file.read())

    # Update the variables in the YAML header
    content['title'] = row['Lecture Title / Topics']
    content['lecture-id'] = int(row['Lecture ID'])
    content['date'] = row["Date"] + "/" + str(datetime.datetime.now().year)

    logger.debug(f"{content['title']} :: {content['lecture-id']} :: {content['date']}")

    content.content = re.sub(r'lecture_id = \d+',rf"lecture_id = {content['lecture-id']}",content.content)

    # Write the updated content back to the file
    with open(filename, "w", encoding='utf-8') as file:
        file.write(frontmatter.dumps(content))

def sync_canvas( row ):
    """ sync canvas lectures with lecture slides """
    logger.info(f"Syncing file to canvas lecture names. Lecture: {row['Lecture ID']}")
    logger.debug(f"course id: {config.course_id}")
    config.config["course"][str(config.course_id)]["pages_slideframe_root"] = "https://lowkeylabs.github.io/cmsc508-fa2023-admin/"
    pages = config.config["course"][str(config.course_id)]["pages"]
    for page in pages.keys():
        fields = page.lower().split("-")
        if row['Lecture ID']==str(fields[1]) and fields[0]=="lecture" and fields[2]=="slides":
            print(f"{os.path.splitext(row['filename'])[0]} :: {page}")
            pages[page]["slideframe"] = config.config["course"][str(config.course_id)]["pages_slideframe_root"]+os.path.splitext(row['filename'])[0]+".html"
    config.save()
    

def sync_files_and_lectures_and_canvas():
    # load lecture data frame
    logger.info(f"config file: {config.config_file_name}" )
    lecture_df = get_lecture_df()
    # Get a list of all filenames in the directory that match 
    lecture_files = [filename for filename in os.listdir(".") if os.path.isfile(filename) and re.match(r"lect\d\d", filename) and os.path.splitext(filename)[1]==".qmd" ]
    # merge old_lecture_file names into data frame
    lecture_df["oldname"] = None
    for filename in lecture_files:
        base = filename[:6]
        lecture_df.loc[lecture_df["basename"] == base, "oldname"] = filename
    # at this stage, we've got old and new filenames, or missing files. Loop and update
    logger.debug(lecture_df[["filename","oldname"]])
    for index,row in lecture_df.iterrows():
        if row['oldname'] is None:
            create_qmd_file( row['filename'])
        elif row["oldname"]==row["filename"]:
            pass
        else:
            rename_qmd_file(row['oldname'],row['filename'])
        sync_yaml_header( row['filename'],row )
#        sync_canvas( row )
    return 0


def build_lecture_files_from_outline():
    """ Build lecture files from google sheets outline """

    # Verify that all connections in config file are established.
    config.lecture_slides_template
    config.canvas_endpoint
    config.lecture_slides_endpoint
    config.outline_gsheet_key

    lectures_df = get_lecture_df()
    # build list of files to be created.
    for index,row in lectures_df.iterrows():
        if not os.path.exists( row["filename"]):
            click.echo(f"Adding {row['filename']}")
            create_qmd_file( row["filename"] )
        sync_yaml_header( row['filename'],row )
        click.echo(f"Syncing YAML header: {row['filename']} - Wk {row["WK"]} - {row["Date"]} - {row['Lecture Title / Topics']}")


def upcoming_calendar( lecture_id, n_rows=8 ):
    """ return snip from upcoming calendar.
    startWeek - the beginning week,
    nRows the number of rows to select.
    """
   
    # Load calendar from google sheets and select the appropriate rows.
    config.log_level="WARNING"
    table = load_calendar( lecture_id, n_rows )

    table_text = tabulate(
            table, 
            headers=["Module","Week","Date","Day","Lectures","Deliverables/Notes"],
            tablefmt="html",
            showindex=False,
            colalign=('center','center','center','center','left','left')
            )
    table_style = """
    <style></style>
    """
    table_html = f"{table_style}<div class='upcoming-calendar'>{table_text}</div>"
    # Display the styled table
    text = display(HTML(table_html))
    return text

def build_modules_from_outline( include_weeks=None, exclude_weeks=None):
    """ Build canvas modules from course outline
    """
    logger.debug("building canvas modules from outline")

    def add_module_page( m,title,**kwargs ):
        click.echo(f"\t{title}")
        page = config.create_page(title)
        return  config.create_module_item(m["id"],type="Page",title=page["title"],page_url=page["url"],indent=kwargs.get("indent",0))
    
    def add_module_subheader( m, title ):
        click.echo(f"\t{title}")
        return config.create_module_item(m["id"],type="SubHeader",title=title,indent=0)
    
    def create_slide_iframe( lecture_name ):
        src = os.path.join(config.lecture_slides_endpoint,lecture_name).replace(os.sep,"/")
        return f"""<p><iframe style="width: 900px; height: 500px;" 
        src="{src}" 
        allowfullscreen="allowfullscreen" allow="geolocation *; microphone *; camera *; midi *; 
        encrypted-media *; autoplay *; clipboard-write *; display-capture *"></iframe></p>
        """
    
    def create_assignment_iframe( sheet_id ):
        return f"""<p><iframe style="width: 900px; height: 750px;" 
        src="https://docs.google.com/document/d/{sheet_id}/preview" 
        allowfullscreen="allowfullscreen" allow="geolocation *; microphone *; camera *; midi *; 
        encrypted-media *; autoplay *; clipboard-write *; display-capture *"></iframe></p>
        """

    def add_module_slides_page(m,title,row,**kwargs):
        """ Add slides page """
        click.echo(f"\t{title}")
        page = config.create_page(title,body=create_slide_iframe( row["html_filename"]))
        return  config.create_module_item(m["id"],type="Page",title=page["title"],page_url=page["url"],indent=kwargs.get("indent",0))

    def add_module_video_page(m,title,row,**kwargs):
        click.echo(f"\t{title}")
        page = config.create_page(title)
        return  config.create_module_item(m["id"],type="Page",title=page["title"],page_url=page["url"],indent=kwargs.get("indent",0))

    def add_homework_page(m,title,row,**kwargs):
        click.echo(f"\t{title}")
        page = config.create_assignment(title,due_at=row["DateCanvas"],description=create_assignment_iframe( row["Homework doc ID"]))
        return  config.create_module_item(m["id"],type="Assignment",title=page["name"],content_id=page["id"],indent=kwargs.get("indent",0))

    def add_quiz_page(m,title,row,**kwargs):
        click.echo(f"\t{title}")
        page = config.create_quiz(title,due_at=row["DateCanvas"],description="title")
        return  config.create_module_item(m["id"],type="Quiz",title=page["title"],content_id=page["id"],indent=kwargs.get("indent",0))

    # Verify that all connections in config file are established.
    config.canvas_endpoint
    config.lecture_slides_endpoint
    config.outline_gsheet_key

    outline_df = retry_loop(3,load_course_outline_df)

    logger.debug(f"Including weeks: {include_weeks}")
    logger.debug(f"Excluding weeks: {exclude_weeks}")

    for wk in sorted( [int(i) for i in outline_df["WK"].unique() if i>''] ):

        add_week = True
        if not include_weeks is None:
            add_week = False
            add_week = wk in include_weeks
        if not exclude_weeks is None:
            add_week = not wk in exclude_weeks

        if add_week:

            rows = outline_df[ outline_df["WK"] == str(wk) ]
            
            week_id = f"Week {int(wk)}"
            week_name = f"{week_id} - {rows['Date'].iloc[0]} to {rows["Date"].iloc[-1]} - {rows["Topic"].iloc[0]}"

            if (1):
                click.echo(f"{week_name}")
                m = config.create_module( week_name )
                add_module_page( m,f'{week_id} - Getting started', indent=0 )

                add_module_subheader( m,f"{week_id} - Resources" )
                add_module_page( m,f"{week_id} - Resource 1",indent=1)

                # Add pages for weekly lectures (if necessary)

                lectures = add_lecture_file_names( extract_lectures( week=wk ) )
                if len(lectures)>0:
                    add_module_subheader(m,f"{week_id} - In-class activities")
                    for i,lecture in lectures.iterrows():
                        add_module_slides_page( m,f"Lecture {lecture['Lecture ID']} - slides",lecture,indent=1)
                        add_module_video_page( m,f"Lecture {lecture['Lecture ID']} - video",lecture,indent=1)

                # Add pages for weekly deliverables (if necessary)

                homeworks = extract_homeworks( week=wk )
                quizzes = extract_quizzes( week=wk )

                if len(homeworks)>0 or len(quizzes)>0:
                    add_module_subheader(m,f"{week_id} - Deliverables")
                    for i,quiz in quizzes.iterrows():
                        add_quiz_page( m,f"Quiz {quiz['Quiz ID']} - {quiz["Quiz description"]}",quiz,indent=1)
                    for i,homework in homeworks.iterrows():
                        add_homework_page( m,f"Homework {homework['HW ID']} - {homework["Homework description"]}",homework,indent=1)

                add_module_page( m,f"{week_id} - Complete!")


def build_canvas_events_from_outline( include_weeks=None, exclude_weeks=None ):
    """ Build class meeting events for calendar """

    logger.debug(f"Build canvas events from outline")
    config.canvas_endpoint
    config.outline_gsheet_key

    outline_df = retry_loop(3,load_course_outline_df)

    logger.debug(f"Including weeks: {include_weeks}")
    logger.debug(f"Excluding weeks: {exclude_weeks}")

    for wk in sorted( [int(i) for i in outline_df["WK"].unique() if i>''] ):

        add_week = True
        if not include_weeks is None:
            add_week = False
            add_week = wk in include_weeks
        if not exclude_weeks is None:
            add_week = not wk in exclude_weeks

        if add_week:
            meetings = extract_meetings( week=wk )
            for i,meeting in meetings.iterrows():
                title = f"CMSC 475 - Class meeting {meeting['Meeting ID']}"
                print(f"Adding: {title}")
                ce = dict(
                        context_code="course_"+str(config.course_id),
                        title=title,
                        description=title,
                        start_at=meeting["MTG Start"],
                        end_at=meeting["MTG End"],
                        location_name=meeting["MTG Location"] 
                )
                page = config.create_event( ce )
                logger.debug(f"{page}")
    return

def build_canvas_frontpages_from_modules( include_weeks=None, exclude_weeks=None ):
    """ build canvas frontpage from module items """

    def extract_week_number( name ):
        week_number = None
        match = re.search(r'Week (\d+)', name)
        if match:
            week_number = int(match.group(1))
        return week_number

    def use_week_number( week_number ):
        use_week = True
        if not include_weeks is None:
            use_week = False
            use_week = week_number in include_weeks
        if not exclude_weeks is None:
            use_week = not week_number in exclude_weeks
        return use_week

    def key_to_block_id( key ):
        ids = ["activities","deliverables","resources"]
        for id in ids:
            if id in key.lower():
                return id
        return "unclassified"
    
    def find_key_and_page( title ):
        page = None
        for key, value in pages.items():
            if ('title' in value) and (value['title'] == title):
                page = value
                break
        if page is None:
            key = None
        return key, page
    
    def get_current_week( outline_df ):
        """ given a outline dataframe determine the current week of the semester """
        outline_df["DateCanvas"] = pd.to_datetime( outline_df["DateCanvas"] )
        today_date = datetime.datetime.date(datetime.datetime.now())
        today_row = outline_df[outline_df['DateCanvas'].dt.date == today_date]
        logger.debug( today_row )
        wk = int(today_row["WK"].iloc[0])
        logger.debug(f"Current week: {wk}")
        return wk
    
    def bullets_to_html( week_id, bullets ):
        """ convert bullet dictionary into html page """

        block = {}
        for key in bullets.keys():
            logger.debug(key)
            if key=="getting started":
                block["overview"] = []
                block["overview"].append("<div style='margin-right:20px; word-wrap:break-word; width:280px;'>")
                block["overview"].append(f"<h2>Week {week_id} - Overview</h2>")

                gs_id, gs_page = find_key_and_page( f"Week {week_id} - Getting started")
                gs_text = "getting started text"
                if gs_id:
                    page = config.get_page( gs_page["page_id"])
                    gs_text = page["body"]
                block["overview"].append(f"<p>{gs_text}</p>")
                block["overview"].append("</div>")
            elif ("activities" in key.lower()) or ("deliverables" in key.lower()) or ("resources" in key.lower()):
                block_id = key_to_block_id( key )
                block[block_id] = ["<div style='margin-right:20px; width:320px'>"]
                h2 = key
                if block_id=="activities":
                    block[block_id] = ["<div style='margin-right:20px; width:180px'>"]
                    h2 = "Lectures"
                block[block_id].append(f"<h2>{h2}</h2>")
                block[block_id].append("<ul>")
#                logger.debug(bullets[key])
                for bullet in bullets[key]:
                    title = bullet["title"]
                    if block_id=="resources":
                        try:
                            title = title.split("-",3)[2].strip()
                        except:
                            title = bullet["title"]
                    block[block_id].append(f"<li><a href=\"{bullet["html_url"]}\" target=\"_blank\">{title}</a></li>")
                block[block_id].append("</ul>")
                block[block_id].append("</div>")
        lines = []
        lines.append("<div style='display:flex; flex-wrap:wrap'>")
        for block_id in ["overview","activities","deliverables","resources"]:
            if block_id in block.keys():
                lines.append( "\n".join(block[block_id]) )
        lines.append("</div>")
        lines.append("<hr/>")
        ## Here is where to add the flexbox containing links to previous weeks front pages
        ## And, links to future front pages.
        
        return "\n".join(lines)

    # verify canvas endponit
    config.canvas_endpoint
    outline_df = retry_loop(3,load_course_outline_df)
    current_week = get_current_week( outline_df )

    logger.debug(f"Including weeks: {include_weeks}")
    logger.debug(f"Excluding weeks: {exclude_weeks}")

    modules = config.get_modules()
    pages = config.get_pages()

    for module_id in modules.keys():

        week_number = extract_week_number( modules[module_id]["name"] )
        if week_number:
            logger.debug(week_number)
            if use_week_number( week_number ):
                click.echo(f"Assembling frontpage for week: {week_number}")
                logger.debug(f"Using week number: {week_number}, module_id: {module_id}")
                module_items = config.get_module_items( for_module_id=module_id )
                module = module_items[module_id]["module_items"]

                # build dictionary with elements representing subheaders
                subheader = "unclassified"
                bullets = {}
                bullets[subheader] = []

                for key in module.keys():
                    item = module[key]
                    logger.debug(f"type: {item["type"]}\ttitle:{item["title"]}")
                    
                    if "getting started" in item["title"].lower():
                        bullets["getting started"] = [ item ]
                    elif "complete" in item["title"].lower():
                        bullets["complete"] = [ item ]
                    elif item["type"]=="SubHeader":
                        try:
                            subheader = item["title"].split('-', 1)[1].strip()
                        except:
                            subheader = "unclassified"
                        logger.debug(f"*** {subheader}")
                        if not subheader in bullets.keys():
                            bullets[subheader] = []
                    else:
                        bullets[subheader].append( item )

                # process bullets into page

                html_page = bullets_to_html( week_number, bullets )
                title = f"Front page - Week {week_number}"

                key, page = find_key_and_page( title )
                logger.debug( page )
                if page:
                    page["body"] = html_page
                    page["front_page"] = current_week == week_number
                    page["published"] = True
                    pageobj = config.get_default_course_endpoint().get_page( key )
                    logger.debug( pageobj )
                    page = config.get_python_object( pageobj.edit( wiki_page=page ) )
                else:
                    page = config.create_page( title=title, body=html_page)
                    pass


if __name__=="__main__":
    build_lecture_files_from_outline()

