""" docstring for cmd_roster
"""
import os
import re
import json
import click

from loguru import logger
import markdown
import pandas as pd

from cnvsapi.utils import as_pretty_json
from cnvsapi.config import config, DEFAULT_LOG_LEVEL,ENV_TOKEN_NAME
from cnvsapi.build_utils import build_lecture_files_from_outline,build_modules_from_outline, build_canvas_events_from_outline

@click.group(invoke_without_command=True)
@click.option("--course-id",help="Display details for this outcome ID",default=None,type=int)
@click.option("--courses",help="Display courses and ids",is_flag=True, default=False)
@click.pass_context
def cli(ctx,course_id,courses):
    """ Roster generator
    """
    if courses:
        crses = config.get_courses()
        comments = ""
        for id in crses.keys():
            line = f"{'' if id==config.course_id else '# '}course_id={id:<8d} #  {crses[id]['name']}"
            print( line )
            comments = comments + "\n" + line
        return
    if not course_id is None:
        ctx.obj["COURSE_ID"] = course_id
        config.course_id = course_id
    
    course = config.get_default_course();

    if ctx.invoked_subcommand is None:
        print(f"Default course id: {config.course_id} / {course["sis_course_id"]}")
        print(f"Default plugin folder: {config.plugin_folder}")
        print(f"Default QMD template is: {config.config['roster']['default_qmd_template']}")
        click.echo(ctx.get_help())


@cli.command()
@click.option("--overwrite",help="Overwrite destination file",default=False, is_flag=True )
@click.pass_context
def rubric(ctx,overwrite):
    """ Testing - creating rubrics on the fly """    
#    rubric = config.get_default_course_endpoint().get_rubric(121219).delete()
    x = config.create_rubric("rubric 1")
    rubric = config.get_default_course_endpoint().get_rubric( 121220 )
    rubric


@cli.command()
@click.pass_context
def lecture_files_from_outline(ctx):
    """ Build lecture slide qmd files using data from google outline """
    build_lecture_files_from_outline()


@cli.command()
@click.pass_context
@click.option("--include-weeks",type=str,help="List of week numbers to include in build",default=None )
@click.option("--exclude-weeks",type=str,help="List of week numbers to exclude from build",default=None )
def canvas_events_from_outline(ctx,include_weeks,exclude_weeks):
    """ Build calendar events for course meetings using data from google outline """
    if include_weeks is None:
        include_list = None
    else:
        include_list = [int(x) for x in include_weeks.split(",")]
    if exclude_weeks is None:
        exclude_list = None
    else:
        exclude_list = [int(x) for x in exclude_weeks.split(",")]
    build_canvas_events_from_outline(include_weeks=include_list,exclude_weeks=exclude_list)


@cli.command()
@click.option("--include-weeks",type=str,help="List of week numbers to include in build",default=None )
@click.option("--exclude-weeks",type=str,help="List of week numbers to exclude from build",default=None )
@click.pass_context
def canvas_modules_from_outline(ctx,include_weeks, exclude_weeks):
    """ Create canvas modules from outline.  Adds quizzes, homeworks and lectures """
    if include_weeks is None:
        include_list = None
    else:
        include_list = [int(x) for x in include_weeks.split(",")]
    if exclude_weeks is None:
        exclude_list = None
    else:
        exclude_list = [int(x) for x in exclude_weeks.split(",")]
    build_modules_from_outline(include_weeks=include_list,exclude_weeks=exclude_list)

if __name__ == '__main__':
    cli(obj={})
