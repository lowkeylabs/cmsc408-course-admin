""" docstring for cmd_build
"""
import os
import re
import json
import click

from loguru import logger
import markdown
import pandas as pd

from cnvsapi.utils import as_pretty_json
from cnvsapi.config import config, DEFAULT_LOG_LEVEL,ENV_TOKEN_NAME
from cnvsapi.build_utils import build_lecture_files_from_outline, build_lecture_headers_from_outline, build_modules_from_outline, build_canvas_events_from_outline, build_canvas_frontpages_from_modules

@click.group(invoke_without_command=True)
@click.option("--course-id",help="Display details for this outcome ID",default=None,type=int)
@click.option("--courses",help="Display courses and ids",is_flag=True, default=False)
@click.pass_context
def cli(ctx,course_id,courses):
    """ Build command

    The build command provide utilities for directly modifying Canvas objects and creating
    custom Canvas pages.

    """
    if courses:
        crses = config.get_courses()
        comments = ""
        for id in crses.keys():
            line = f"{'' if id==config.course_id else '# '}course_id={id:<8d} #  {crses[id]['name']}"
            print( line )
            comments = comments + "\n" + line
        return
    if not course_id is None:
        ctx.obj["COURSE_ID"] = course_id
        config.course_id = course_id
    
    course = config.get_default_course();

    if ctx.invoked_subcommand is None:
        print(f"Default course id: {config.course_id} / {course["sis_course_id"]}")
        print(f"Default plugin folder: {config.plugin_folder}")
        print(f"Default QMD template is: {config.config['roster']['default_qmd_template']}")
        click.echo(ctx.get_help())


@cli.command()
@click.option("--overwrite",help="Overwrite destination file",default=False, is_flag=True )
@click.pass_context
def rubric(ctx,overwrite):
    """ Testing - creating rubrics on the fly """    
#    rubric = config.get_default_course_endpoint().get_rubric(121219).delete()
    x = config.create_rubric("rubric 1")
    rubric = config.get_default_course_endpoint().get_rubric( 121220 )
    rubric


@cli.command()
@click.pass_context
@click.option("--all",help="Create all missing lecture files",default=False, is_flag=True )
@click.option("--include-lectures",type=str,help="List of lectures to include",default=None )
@click.option("--exclude-lectures",type=str,help="List of lectures to exclude",default=None )
def lecture_files_from_outline(ctx,all,include_lectures,exclude_lectures):
    """ Build missing lecture slides and update all YAML headers
    
       qmd files using data from google outline
       
    """

    if include_lectures is None:
        include_list = None
    else:
        include_list = [int(x) for x in include_lectures.split(",")]
    if exclude_lectures is None:
        exclude_list = None
    else:
        exclude_list = [int(x) for x in exclude_lectures.split(",")]

    if (not all) and (include_list is None) and (exclude_list is None):
        click.echo(ctx.get_help())
    else:
        build_lecture_files_from_outline(include_lectures=include_list,exclude_lectures=exclude_list)

@cli.command()
@click.pass_context
@click.option("--all",help="Freshen all YAML lecture headers",default=False, is_flag=True )
@click.option("--include-lectures",type=str,help="List of lectures to include",default=None )
@click.option("--exclude-lectures",type=str,help="List of lectures to exclude",default=None )
def lecture_headers_from_outline(ctx,all,include_lectures,exclude_lectures):
    """ Freshen YAML headers for existing lecture files
    
       qmd files using data from google outline
       
    """

    if include_lectures is None:
        include_list = None
    else:
        include_list = [int(x) for x in include_lectures.split(",")]
    if exclude_lectures is None:
        exclude_list = None
    else:
        exclude_list = [int(x) for x in exclude_lectures.split(",")]

    if (not all) and (include_list is None) and (exclude_list is None):
        click.echo(ctx.get_help())
    else:
        build_lecture_headers_from_outline(include_lectures=include_list,exclude_lectures=exclude_list)


@cli.command()
@click.pass_context
@click.option("--all",help="Build calendar events for all lectures",default=False, is_flag=True )
@click.option("--include-weeks",type=str,help="List of week numbers to include in build",default=None )
@click.option("--exclude-weeks",type=str,help="List of week numbers to exclude from build",default=None )
def canvas_events_from_outline(ctx,all,include_weeks,exclude_weeks):
    """ Build calendar events for course meetings using data from google outline """
    if include_weeks is None:
        include_list = None
    else:
        include_list = [int(x) for x in include_weeks.split(",")]
    if exclude_weeks is None:
        exclude_list = None
    else:
        exclude_list = [int(x) for x in exclude_weeks.split(",")]
    if (not all) and (include_list is None) and (exclude_list is None):
        click.echo(ctx.get_help())
    else:
        build_canvas_events_from_outline(include_weeks=include_list,exclude_weeks=exclude_list)


@cli.command()
@click.option("--all",help="Build modules for all weeks in calendar",default=False, is_flag=True )
@click.option("--include-weeks",type=str,help="List of week numbers to include in build",default=None )
@click.option("--exclude-weeks",type=str,help="List of week numbers to exclude from build",default=None )
@click.pass_context
def canvas_modules_from_outline(ctx,all,include_weeks, exclude_weeks):
    """ Create canvas modules from outline.  Adds quizzes, homeworks and lectures """
    if include_weeks is None:
        include_list = None
    else:
        include_list = [int(x) for x in include_weeks.split(",")]
    if exclude_weeks is None:
        exclude_list = None
    else:
        exclude_list = [int(x) for x in exclude_weeks.split(",")]
    if (not all) and (include_list is None) and (exclude_list is None):
        click.echo(ctx.get_help())
    else:
        build_modules_from_outline(include_weeks=include_list,exclude_weeks=exclude_list)


@cli.command()
@click.option("--all",help="Build frontpages for all canvas modules",default=False, is_flag=True )
@click.option("--include-weeks",type=str,help="List of week numbers to include in build",default=None )
@click.option("--exclude-weeks",type=str,help="List of week numbers to exclude from build",default=None )
@click.pass_context
def canvas_frontpages_from_modules(ctx,all,include_weeks, exclude_weeks):
    """ Creates frontpages from canvas modules.
    
    Assumes format created by canvas_modules_from_outline
    """
    if include_weeks is None:
        include_list = None
    else:
        include_list = [int(x) for x in include_weeks.split(",")]
    if exclude_weeks is None:
        exclude_list = None
    else:
        exclude_list = [int(x) for x in exclude_weeks.split(",")]
    if (not all) and (include_list is None) and (exclude_list is None):
        click.echo(ctx.get_help())
    else:
        build_canvas_frontpages_from_modules(include_weeks=include_list,exclude_weeks=exclude_list)


if __name__ == '__main__':
    cli(obj={})
