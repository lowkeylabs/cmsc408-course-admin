""" docstring for cmd_explore
"""
import os
import re
import json
import click

from loguru import logger
import markdown
import pandas as pd

from cnvsapi.utils import as_pretty_json
from cnvsapi.config import config, DEFAULT_LOG_LEVEL,ENV_TOKEN_NAME


@click.group(invoke_without_command=True)
@click.option("--course-id",help="Display details for this outcome ID",default=None,type=int)
@click.option("--courses",help="Display course ID for selection", is_flag=True, default=False )
@click.pass_context
def cli(ctx,course_id,courses):
    """ Explore objects and endpoints
    """
    if courses:
        courses = config.get_courses()
        for id in courses.keys():
            line = f"{'' if id==config.course_id else '# '}course_id={id:<8d} #  {courses[id]['name']}"
            click.echo( line )

    if not course_id is None:
        ctx.obj["COURSE_ID"] = course_id
        config.course_id = course_id

    if ctx.invoked_subcommand is None:
        if not courses:
            click.echo( ctx.get_help() )
        click.echo(f"\nDefault course id: {config.course_id}")

@cli.command()
@click.pass_context
def course( ctx ):
    """ List course attributes
    """
    id = config.course_id 
    if not id is None:
        courses = config.get_courses()
        if id in courses.keys():
            print( as_pretty_json( courses[id] ) )
        else:
            print(f"Invalid course id.  Select from: \n{courses.keys()}")
    else:
        print(f"Missing course id.  Use --id or set default course in {config.config_file_name}")

@cli.command()
@click.option("--add-to-config",help="Add available courses to config file",default=False,is_flag=True,show_default=True )
@click.pass_context
def courses( ctx,add_to_config ):
    """ List available courses for a token/user
    """
    courses = config.get_courses()
    comments = ""
    for id in courses.keys():
        line = f"{'' if id==config.course_id and not add_to_config else '# '}course_id={id:<8d} #  {courses[id]['name']}"
        print( line )
        comments = comments + "\n" + line
    if add_to_config:
        config.addCourseComments( comments )
        click.echo("\nEdit config file and uncomment the desired course")

@cli.command()
@click.option("--id",help="User id to display",required=False,default=None,type=int)
@click.pass_context
def users( ctx, id ):
    """ List users for a course
    """
    users = config.get_users()
    if id is None:
        for key in users.keys():
            print(f"{key:8} : {users[key]['name']}")
    else:
        print( as_pretty_json(users[id]) )

@cli.command()
@click.option("--id",help="Assignment group id to display",required=False,default=None,type=int)
@click.pass_context
def assignment_groups( ctx,id ):
    """ List assignment groups for a course
    """
    assignment_groups = config.get_assignment_groups()
    if id is None:
        print( as_pretty_json( assignment_groups ))
    else:
        print( as_pretty_json( assignment_groups[id] ))

@cli.command()
@click.option("--id",help="Assignment id to display",required=False,default=None,type=int)
@click.pass_context
def assignments( ctx,id ):
    """ List assignment groups for a course
    """
    assignments = config.get_assignments()
    if id is None:
        print( as_pretty_json( assignments ))
    else:
        print( as_pretty_json( assignments[id] ))


@cli.command()
@click.option("--id",help="Quiz id to display",required=False,default=None,type=int)
@click.pass_context
def quizzes( ctx,id ):
    """ List quizzes for a course
    """
    quizzes = config.get_quizzes()
    if id is None:
        print( as_pretty_json( quizzes ))
    else:
        print( as_pretty_json( quizzes[id] ))


@cli.command()
@click.option("--id",help="Module id to display",required=False,default=None,type=int)
@click.pass_context
def modules( ctx,id ):
    """ List modules for a course
    """
    modules = config.get_modules()
    if id is None:
#        print( as_pretty_json([ f"{i:7} :{modules[i]['position']:3} : {modules[i]['name']}" for i in modules.keys()],0) )
        print( as_pretty_json( modules ))
    else:
        print( as_pretty_json( modules[id] ))

@cli.command()
@click.option("--id",help="id to display",required=False,default=None,type=int)
@click.pass_context
def enrollments( ctx,id ):
    """ List enrollments for a course
    """
    enrollments = config.get_enrollments()
    if id is None:
#        print( as_pretty_json([ f"{1+i:3} :{key:8} :{enrollments[key]['type']:21} : {enrollments[key]['user']['name']}" for i,key in enumerate(enrollments.keys())],0) )
        print( as_pretty_json( enrollments ) )
    else:
        print( as_pretty_json( enrollments[id] ) )

@cli.command()
@click.option("--id",help="id to display",required=False,default=None,type=int)
@click.pass_context
def rubrics( ctx,id ):
    """ List rubrics for a course
    """
    objects = config.get_rubrics()
    if id is None:
#        print( as_pretty_json([ f"{1+i:3} :{key:8} :{objects[key]['title']:21} " for i,key in enumerate(objects.keys())],0) )
        print( as_pretty_json( objects ) )
    else:
        print( as_pretty_json( objects[id] ) )

@cli.command()
@click.option("--id",help="id to display",required=False,default=None,type=int)
@click.pass_context
def pages( ctx,id ):
    """ List rubrics for a course
    """
    objects = config.get_pages()
    if id is None:
#        print( as_pretty_json([ f"{1+i:3} :{key:8} :{objects[key]['title']:21} " for i,key in enumerate(objects.keys())],0) )
        print( as_pretty_json( objects ) )
    else:
        print( as_pretty_json( objects[id] ) )

@cli.command()
@click.option("--id",help="id to display",required=False,default=None,type=int)
@click.pass_context
def module_items( ctx,id ):
    """ List modules and module items for a course
    """
    objects = config.get_module_items()
    if id is None:
#        print( as_pretty_json([ f"{1+i:3} : {key:8} : {objects[key]['name']}" for i,key in enumerate(objects.keys())],0) )
        print( as_pretty_json( objects ) )
    else:
        print( as_pretty_json( objects[id] ) )

@cli.command()
@click.option("--id",help="id to display",required=False,default=None,type=int)
@click.pass_context
def groups( ctx,id ):
    """ List groups for a course
    """
    objects = config.get_groups()
    if id is None:
        print( as_pretty_json( objects ) )
    else:
        print( as_pretty_json( objects[id] ) )

@cli.command()
@click.argument('command_name', type=str,default='list' )
@click.pass_context
def canvas_endpoint( ctx,command_name ):
    """ Explore endpoints on canvas object
    """
    if command_name=='list':
        print( as_pretty_json( config.get_callable_canvas_objects() ))
    else:
        print( as_pretty_json( config.get_canvas_object_by_name( command_name )))

@cli.command()
@click.argument('command_name', type=str,default='list' )
@click.pass_context
def course_endpoint( ctx,command_name ):
    """ Explore endpoints on the default course object
    """
    if command_name=='list':
        print( as_pretty_json( config.get_callable_course_objects() ))
    else:
        print( as_pretty_json( config.get_course_object_by_name( command_name )))


if __name__ == '__main__':
    cli(obj={})


