""" docstring for cmd_outline
"""
import os
import re
import json
import click

from loguru import logger
import markdown
import pandas as pd
from datetime import datetime

from cnvsapi.build_utils import extract_lectures,extract_quizzes,extract_homeworks, extract_meetings, extract_weeks
from cnvsapi.utils import as_pretty_json
from cnvsapi.config import config, DEFAULT_LOG_LEVEL,ENV_TOKEN_NAME

@click.group(invoke_without_command=True)
@click.option("--course-id",help="Display details for this outcome ID",default=None,type=int)
@click.option("--courses",help="Display courses and ids",is_flag=True, default=False)
@click.pass_context
def cli(ctx,course_id,courses):
    """ Gsheets Outline Query Tool 
    """
    if courses:
        crses = config.get_courses()
        comments = ""
        for id in crses.keys():
            line = f"{'' if id==config.course_id else '# '}course_id={id:<8d} #  {crses[id]['name']}"
            print( line )
            comments = comments + "\n" + line
        return
    elif not course_id is None:
        ctx.obj["COURSE_ID"] = course_id
        config.course_id = course_id
    if ctx.invoked_subcommand is None:
        print(f"Default course id: {config.course_id}")
        print(f"Default plugin folder: {config.plugin_folder}")
        print(f"Outline gsheet key: {config.outline_gsheet_key}")
        click.echo(ctx.get_help())


@cli.command()
@click.pass_context
def lectures(ctx):
    """ List lectures found in google sheet """
    df = extract_lectures()
    for i,row in df.iterrows():
        datetime_string = row["DateCanvas"]
        datetime_object = datetime.strptime(datetime_string, "%m/%d/%Y %H:%M:%S")
        formatted_date = datetime_object.strftime("%a, %b. %d")
        click.echo(f"Lecture {str(row['Lecture ID']):2}: {row['Lecture Title / Topics']}, {formatted_date}")

@cli.command()
@click.pass_context
def quizzes(ctx):
    """ List quizzes found in google sheet """
    df = extract_quizzes()
    for i,row in df.iterrows():
        datetime_string = row["DateCanvas"]
        datetime_object = datetime.strptime(datetime_string, "%m/%d/%Y %H:%M:%S")
        formatted_date = datetime_object.strftime("%a, %b. %d")
        click.echo(f"Quiz {str(row['Quiz ID']):2}: {row['Quiz description']}, due {formatted_date}")

@cli.command()
@click.pass_context
def homeworks(ctx):
    """ List homeworks found in google sheet """
    df = extract_homeworks()
    for i,row in df.iterrows():
        datetime_string = row["DateCanvas"]
        datetime_object = datetime.strptime(datetime_string, "%m/%d/%Y %H:%M:%S")
        formatted_date = datetime_object.strftime("%a, %b. %d")
        click.echo(f"Homework {str(row['HW ID']):2}: {row['Homework description']}, due {formatted_date}")

@cli.command()
@click.pass_context
def meetings(ctx):
    """ List class meetings found in google sheet """
    df = extract_meetings()
    for i,row in df.iterrows():
        datetime_string = row["DateCanvas"]
        datetime_object = datetime.strptime(datetime_string, "%m/%d/%Y %H:%M:%S")
        formatted_date = datetime_object.strftime("%a, %b. %d")
        click.echo(f"Meeting {str(row['Meeting ID']):2}: {row['Classroom Activity']} - {formatted_date}")

@cli.command()
@click.pass_context
def weeks(ctx):
    """ List weeks / modules found in google sheet """
    df = extract_weeks()
    for i,row in df.iterrows():
        datetime_string = row["DateCanvas"]
        datetime_object = datetime.strptime(datetime_string, "%m/%d/%Y %H:%M:%S")
        formatted_date = datetime_object.strftime("%Y-%m-%d")
        click.echo(f"Week {str(row['WK']):2}: {row['Module']} ({formatted_date})")


if __name__ == '__main__':
    cli(obj={})


