""" Config - module for configuration
"""
import os
import re
import sys
import click
import keyring
import tomlkit
import pandas as pd
import keyring.util.platform_ as keyring_platform

from loguru import logger
from canvasapi import Canvas
from datetime import date,datetime


program_name = os.path.splitext(os.path.basename( sys.argv[0] ))[0].lower()
program_name = "cnvsapi"

config_file_name = "." + (program_name).lower()

ENV_CONFIG = program_name.upper()
ENV_LOG_LEVEL = program_name+"_LOG_LEVEL"
ENV_TOKEN_NAME = "CANVAS_API_TOKEN"

DEFAULT_LOG_LEVEL = 'WARNING'
DEFAULT_SPLIT_CODE = "::"

logger.remove()
logger.add(sys.stderr, level=DEFAULT_LOG_LEVEL)

plugin_folder = os.path.join(os.path.dirname(__file__))

class Configuration:
    config = tomlkit.document()
    config_file = config_file_name

    def __init__( self ):
        self.config = tomlkit.document()

        if not os.path.exists( self.config_file ):
            logger.info(f"Creating internal configuration: {config_file_name}")
            self.config = tomlkit.loads(f"""# {program_name} config file ({config_file_name}). Auto-created: {date.today()}

# This is a strictly formatted TOML file. It contains configuration values for this 
# program. Highest level paramters control application run-time. Subsequent sections 
# contain parameters for services that interact with this program.
                                        
# Log_level: used for watching execution.  This tool uses loguru.
# Values: "TRACE", "DEBUG", "INFO", "SUCCESS", "WARNING", "ERROR", "CRITICAL"
# Default: "WARNING"
                                        
[application]
# Application configuration variables

log_level = "{DEFAULT_LOG_LEVEL}"
default_split_code = "{DEFAULT_SPLIT_CODE}"

[images]
# This is where VCU stores headshops.  Add a V###.jpg to complete the URL.
headshot_endpoint = "https://sasbimid2.vcu.edu/images"

[canvas]
# Campus default values for Canvas
# High level web address of campus canvas server

endpoint = "https://virginiacommonwealth.instructure.com"

[roster]
default_qmd_template = "template0"
template0 = "template-roster-0.qmd"

[assessment.rubric]
default = "report1"

[assessment.rubric.report1.assignment_group]
name = "ag_name"
[assessment.rubric.report1.assignment]
name = "assign_name"
[assessment.rubric.report1.user]
sortable_name = "sortable name"
sis_user_id = "VID"
[assessment.rubric.report1.rubric]
description = "Rubric description"
points = "total points"
[assessment.rubric.report1.rating]
description = "user description"
points = "user score"

[keyring]
# keyring is a local computer secure storage system leveraging tools from
# the local OS. Keyring works on windows, linux and mac.
# See: https://pypi.org/project/keyring/

# Namespace and entry are used with "keyring" to store canvas token in local
# computer secure password storage. Don't mess with these, they were carefully
# selected to work across all windows, linux, and mac platforms.

namespace = "cmsc-vcu-course-tools-api"
entry = "{ENV_TOKEN_NAME}"

""")
            courses = self.get_courses()
            comments = ""
            # hard code course ID check for this part of the config load.
            course_id=-1
            if "course" in self.config.keys():
                if "course_id" in self.config["course"].keys():
                    course_id=self.config["course"]["course_id"]
            for id in courses.keys():
                line = f"{'' if id==course_id else '# '}course_id={id:<8d} #  {courses[id]['name']}"
                comments = comments + "\n" + line
            self.addCourseComments( comments )
            click.echo(f"New configuration saved to: {self.config_file_name}")
            self.save()
#            if click.confirm(f"Create {config_file_name} config file in this folder?",err=True):
#                logger.info(f"User selected to save config file: {config_file_name}")
#                self.save()
#            else:
#                logger.info("User chose to NOT save config file.")
        else:
            logger.info(f"Loading config file: {self.config_file}")
            try:
                with open(self.config_file, 'r') as file:
                    self.config = tomlkit.loads(file.read())
            except Exception as e:
                print(f"\nError reading config file: \"{self.config_file}\" during startup.")
                print("-->",str(e))
                print("Edit the file and try again")
                sys.exit(1)
        
        # we've got a create self.config is is (or isn't) saved. Doesn't matter - it's in memory!

        if "application" not in self.config.keys():
            self["application"]["log_level"] = DEFAULT_LOG_LEVEL
        if "log_level" in self.config['application'].keys():
            logger.remove()
            logger.add(sys.stderr, level=self.config["application"]["log_level"])
            logger.info(f"Log level set to {self.config['application']['log_level']} by {self.config_file}")

        if self.token is None:
            print(f"""\nWARNING - {ENV_TOKEN_NAME} not found in environment or keyring.
You'll need a token from canvas to access the API using this program.
Visit: https://virginiacommonwealth.instructure.com/profile/settings  to get an API token.
Store the token using:
  cnvsapi token --canvas-api-token="<your token inside the double-quotes>"
""")

#            sys.exit(1)
    
    def serialize(self, file_path):
        with open(file_path, 'w') as file:
            file.write(tomlkit.dumps(self.config))

    def save( self ):
        self.serialize( self.config_file )

    def createOrReplace(self,key,item ):
        if key in self.config.keys():
            self.config[key] = item
        else:
            self.config.add(key,item)

    def addCourseComments(self,comments):
        tab = tomlkit.table()
        header = """
# Course contains a list of potential courses that this canvas user
# can connect.  Use "cnvsapi courses --add-to-config" to freshen this section.
# Once freshened, the user should uncomment one of the courses to serve
# as default for further operations.
        """
        tab.comment(f"{header}{comments}")
        self.createOrReplace("course",tab)
        self.save()

    @property
    def course_id( self ):
        missing_value_string = "<edit me, uncomment course_id above>"
        value = None
        if "course" in self.config.keys():
            if "course_id" in self.config["course"].keys():
                value = self.config["course"]["course_id"]
                if value==missing_value_string:
                    value = None
#        if value==None:
#            click.echo(f"Missing default course id. Edit {self.config_file_name}")
#            if not "course" in self.config.keys():
#                self.config["course"] = {}
#            if not "course_id" in self.config["course"].keys():
#                self.config["course"]["course_id"] = missing_value_string
#            self.save()
#            sys.exit(1)
        return value

    @course_id.setter
    def course_id( self, course_id ):
        if not "course" in self.config.keys():
            self.config["course"] = {}
        self.config["course"]["course_id"] = course_id

    def get_canvas( self ):
        namespace = self.namespace
        return Canvas( self.config["canvas"]["endpoint"],keyring.get_password( namespace, self.config["keyring"]["entry"] )  )

    def remove_html_tags(self,text):
        """ Clean a string of HTML chars from Canvas """
        clean_text = re.sub('<.*?>', '', text)  # Remove HTML tags using regex
        clean_text = re.sub(r'[\x00-\x08\x0B-\x0C\x0E-\x1F\x7F-\x9F]+', '', clean_text)  # Remove HTML tags using regex
        clean_text = re.sub(r'&nbsp;', ' ', clean_text, flags=re.IGNORECASE)
        clean_text = re.sub(r'  ', ' ', clean_text)
        return clean_text


    def get_python_object( self, objects ):

        if isinstance(objects,list):
            rlist = {}
            for object in objects:
                # some objects don't use "id" field.  Page uses "url" to connect with module-items
                logger.debug(object.__class__.__name__)
                if object.__class__.__name__=="Page":
                    id = object.url
                else:
                    id = object.id
                rlist[id] = { key:getattr(object,key) for key in vars(object) if not key in ["_requester"]}
        else:
            rlist = { key:getattr(objects,key) for key in vars(objects) if not key in ["_requester"]}
        return rlist

    def get_python_object_from( self, endpoint, *args, **kwargs ):
#        if not id1 is None:
#            objects = endpoint( id1 )
#        else:
#            objects = endpoint()
#        logger.debug(f"endpoint: {endpoint} :: args: {args} :: kwargs:{kwargs}")
        if len(args)==0 and len(kwargs.keys())==0:
            objects = endpoint()
        elif len(kwargs.keys())==0:
            objects = endpoint( *args )
        elif len(args)==0:
            objects = endpoint( **kwargs )
        else:
            objects = endpoint( *args, *kwargs )
        list = {}
        for object in objects:
            # some objects don't use "id" field.  Page uses "url" to connect with module-items
 #           logger.debug(object.__class__.__name__)
            if object.__class__.__name__=="Page":
                id = object.url
            else:
                id = object.id
            try:
                list[id] = { key:getattr(object,key) for key in vars(object) if not key in ["_requester"]}
            except:
                list = object
        return list
    
    def get_default_course_endpoint( self ):
        """ Returns the default course and an error if no default is set """
        logger.debug(f"default course: {self.course_id}")
        if self.course_id is None:
            print(f"No default course_id has been set.  Use --course-id or edit {config_file_name} ")
            sys.exit( 1 )
        return self.get_canvas().get_course( self.course_id )
    
    def get_default_course( self ):
        """ returns a dictionary of canvas courses and attributes """
        logger.debug(f"default course: {self.course_id}")
        if self.course_id is None:
            print(f"No default course_id has been set.  Use --course-id or edit {config_file_name} ")
            sys.exit( 1 )
        return self.get_courses()[self.course_id]

    def get_courses( self ):
        """ returns a dictionary of canvas courses and attributes """
        return self.get_python_object_from( self.get_canvas().get_courses )

    def get_users( self ):
        """ returns a dictionary of canvas users for the current course """
        return self.get_python_object_from( self.get_default_course_endpoint().get_users )
    
    def get_assignment_groups( self ):
        """ returns dictionary of assignment groups for the current course """
        return self.get_python_object_from( self.get_default_course_endpoint().get_assignment_groups )
    
    def get_assignments( self ):
        assignment_groups = self.get_python_object_from( self.get_default_course_endpoint().get_assignment_groups )
        for ag in assignment_groups.values():
            ag["assignments"] = {}
        assignments = self.get_python_object_from( self.get_default_course_endpoint().get_assignments )
        for as_id in assignments.keys():
            assignment_groups[assignments[as_id]["assignment_group_id"]]["assignments"][as_id] = assignments[as_id]
        return assignment_groups

    def get_quizzes( self ):
        return self.get_python_object_from( self.get_default_course_endpoint().get_quizzes )

    def get_quiz( self,quiz_id ):
        return self.get_python_object( self.get_default_course_endpoint().get_quiz( quiz_id ) )

    def get_modules( self ):
        return self.get_python_object_from( self.get_default_course_endpoint().get_modules )

    def get_pages( self ):
        return self.get_python_object_from( self.get_default_course_endpoint().get_pages )

    def get_page( self, page_id ):
        return self.get_python_object( self.get_default_course_endpoint().get_page( page_id ) )

    def get_module_items( self, for_module_id=None ):
        list = {}
        if for_module_id is None:
            modules = self.get_modules()
            for module_id in modules.keys():
                logger.debug(module_id)
                list[module_id] = modules[module_id]
                list[module_id]["module_items"] = self.get_python_object_from( self.get_default_course_endpoint().get_module( module_id ).get_module_items )
        else:
            logger.debug( for_module_id )
            list[for_module_id] = {}
            list[for_module_id]["module_items"] = self.get_python_object_from( self.get_default_course_endpoint().get_module( for_module_id ).get_module_items )

        return list

    def get_quiz_questions( self, quiz_id ):
        qq = {}
        logger.debug(f"retrieving data for quiz: {quiz_id}")
        questions = config.get_canvas().get_course(config.course_id).get_quiz( quiz_id ).get_questions()
        qq[quiz_id] = {}
        for question in questions:
            logger.trace(f"{question}")
            ques_id = getattr(question,"id")
            qq[quiz_id][ques_id] = {}
            q = qq[quiz_id][ques_id]
            for var in vars(question):
                q[var] = getattr(question,var)
                if var=="answers":
                    answers = q[var]
                    q['answer_dict'] = {}
                    for answer in answers:
                        q['answer_dict'][answer['id']] = answer
            q["clean_text"] = self.remove_html_tags(getattr(question,"question_text"))
        logger.trace(f"{qq}")
        return qq[quiz_id]

    def get_quiz_responses( self, quiz_id ):
        """ Return quiz questions and responses as a dataframe """
        # get quiz questions and answers
        quiz = self.get_quiz_questions( quiz_id )
        users = self.get_users()
        # get assignment_id that corresponds to current quiz. Note that
        # quiz responses are stored in the assignment structure.

#        logger.debug(f"{quiz}")

        assignment_id = getattr(config.get_canvas().get_course(config.course_id).get_quiz( quiz_id ),'assignment_id')
        logger.debug(f"Assignment id: {assignment_id}")
        # create the final dataframe
        rows = []
        headers = None
        if not assignment_id is None:
            responses = config.get_canvas().get_course(config.course_id).get_assignment(assignment_id).get_submissions(include=['submission_history'])
            for response in responses:
                user_id = getattr(response,'user_id')
                sortable_name = 'zzz test user'
                email = 'missing'
                sis_user_id = 'missing'
                if user_id in users.keys():
                    sortable_name = users[user_id]['sortable_name'] if 'sortable_name' in users[user_id].keys() else 'missing'
                    email = users[user_id]['email'] if 'email' in users[user_id].keys() else 'missing'
                    sis_user_id = users[user_id]['sis_user_id'] if 'sis_user_id' in users[user_id].keys() else 'missing'
                new_row = [sortable_name,email,sis_user_id]
                new_header = ['sortable_name','email','sis_user_id/vid']
                if hasattr(response,'submission_history'):
                    history = None
                    id = None
                    # capture the latest submission. There may be multiple submissions,
                    # we'll use the last submission.
                    for temp_id,temp_history in enumerate(getattr(response,'submission_history')):
                        history = temp_history
                        id = temp_id
                    logger.trace(history)
                    if 'submission_data' in history.keys():
                        # print submissions
                        for answer in history['submission_data']:
                            logger.trace(f"{quiz[answer['question_id']]['clean_text']}")
                            possible_answers = quiz[answer['question_id']]['answers'] 
                            for possible_answer in possible_answers:
                                if 'text' in possible_answer.keys():
                                    logger.trace(f"{possible_answer['id']}::{possible_answer['text']}")
                            if 'answer_id' in answer.keys() and answer['text']==str(answer['answer_id']):
                                answer['text'] = quiz[answer['question_id']]['answer_dict'][answer['answer_id']]['text']
                            logger.trace(f"{getattr(response,'user_id')}::{quiz[answer['question_id']]['position']}::{quiz[answer['question_id']]['clean_text']}::{answer['question_id']}::{answer['text']}")
                            new_row.append(answer['text'])
                            new_header.append(quiz[answer['question_id']]['clean_text'])
                        if headers==None:
                            headers = new_header
                    else:
                        logger.trace(f"{quiz_id}::{assignment_id}::{getattr(response,'user_id')}::'missing submission_data'")
                else:
                    logger.trace(f"{quiz_id}::{assignment_id}::{getattr(response,'user_id')}::'missing submission_history'")
                rows.append( new_row )
        df = pd.DataFrame( rows, columns=headers )
        df["count"] = 1
        return df


    
    def create_page(self,title,**kwargs):
        """ create a page using defaults """
        defaults = {"title":title,"published":False,"notify_of_update":False,"editing_roles":"teachers","front_page":False,"body":title}
        wiki_page = defaults
        wiki_page["title"] = title
        for key in defaults.keys():
            wiki_page[key] = kwargs.get(key,defaults[key])
        page = self.get_default_course_endpoint().create_page( wiki_page )
        return self.get_python_object( page )
    
    
    def create_event(self,ce,**kwargs):
        return self.get_python_object( self.get_canvas().create_calendar_event( ce ) )

    def create_assignment(self,title,**kwargs):
        """ create an assignment using defaults """
        defaults = {"name":title,"published":False,"notify_of_update":False,"submission_types":["online_upload"],
                    "allowed_extensions":["html"],"grading_type":"points","points_possible":10,
                    "description":title,"allowed_attempts":-1}
        assignment = defaults
        for key in defaults.keys():
            assignment[key] = kwargs.get(key,defaults[key])

        if "due_at" in kwargs.keys():
            datetime_string = kwargs["due_at"]
            datetime_object = datetime.strptime(datetime_string, "%m/%d/%Y %H:%M:%S")
            assignment["due_at"] = datetime_object

        # Create the assignment and return it.
        page = self.get_default_course_endpoint().create_assignment( assignment )
        return self.get_python_object( page )

    def create_quiz(self,title,**kwargs):
        """ create a quiz using defaults """
        defaults = {"title":title,"quiz_type":"assignment","shuffle_answers":True,
                    "description":title+" has not been developed.",
                    "allowed_attempts":-1,"scoring_policy":"keep_highest","published":False}
        quiz = defaults
        for key in defaults.keys():
            quiz[key] = kwargs.get(key,defaults[key])

        if "due_at" in kwargs.keys():
            datetime_string = kwargs["due_at"]
            datetime_object = datetime.strptime(datetime_string, "%m/%d/%Y %H:%M:%S")
            quiz["due_at"] = datetime_object
            
        # Create the assignment and return it.
        page = self.get_default_course_endpoint().create_quiz( quiz )
        return self.get_python_object( page )


    def create_module( self, name,**kwargs ):
        defaults = {"name":name,"unlock_at":datetime(2024,6,1),"position":999,"requires_sequential_progress":False,"prerequisite_module_ids":[],"publish_final_grade":False}
        modules = self.get_modules()
        if len(modules)==0:
            last_position = 0
        else:
            last_position = max([modules[id]["position"] for id in modules.keys() ] )
        module = defaults
        module["position"] = last_position + 1
        for key in defaults.keys():
            module[key] = kwargs.get(key,defaults[key])
        return self.get_python_object( self.get_default_course_endpoint().create_module(module) )

    def create_module_item( self, module_id, **kwargs ):
        defaults = {"title":"new module item","type":"Page","content_id":None,"position":0,"indent":0,"page_url":"","external_url":"","new_tab":False,
                    "completion_requirement":[],"width":640,"height":480}
        module = self.get_default_course_endpoint().get_module( module_id )
        module_items = self.get_python_object_from( module.get_module_items )
        if len(module_items)==0:
            last_position = 0
        else:
            last_position = max( [module_items[id]["position"] for id in module_items.keys()] )
        module_item = defaults
        module_item["position"] = last_position + 1
        for key in defaults.keys():
            module_item[key] = kwargs.get(key,defaults[key])
        return self.get_python_object( module.create_module_item(module_item) )
    
    def delete_rubric( self, rubric_id ):
        return self.get_python_object_from( self.get_default_course_endpoint().delete_rubric( rubric_id ))
    
    def create_rubric( self, title, **kwargs ):
        default = {"rubric":{
                "title":title,
                "free_form_criterion_comments":False,
                "criteria":{
                "1":{
                    "description":"Criterion 1",
                    "ratings":{
                    "1":{
                        "description":"Full credit",
                        "points":1.0},
                    "2":{
                        "description":"No credit",
                        "points":0.0}
                    }},
                "2":{
                    "description":"Criterion 2",
                    "ratings":{
                    "1":{
                        "description":"Full credit",
                        "points":1.0},
                    "2":{
                        "description":"No credit",
                        "points":0.0}
                    }}

                    }},
            "rubric_association":{
                "association_type":"Course",
                "association_id":self.course_id,
                "use_for_grading": True,
                "hide_score_from_total":False}
                }
        rv = self.get_default_course_endpoint().create_rubric( rubric=default["rubric"],rubric_association=default["rubric_association"] )
    

    def roster_qmd_from_template( self, template=None, dest_folder=None,overwrite=False ):
        """ Create a roster qmd file from a template """
        if template is None:
            template = config.config['roster']['default_qmd_template']
        src_file_name = os.path.join(self.plugin_folder, config.config['roster'][template])
        course = self.get_default_course()
        # logger.debug( course )
        dest_name = course['sis_course_id']+'-roster.qmd'
        if dest_folder is None:
            dest_folder = os.getcwd()
        dest_file_name = os.path.join(dest_folder,dest_name)
        if not os.path.exists(src_file_name):
            return(f"Error: template src file does not exist. {src_file_name}")
        if os.path.exists(dest_file_name) and not overwrite:
            return f"Error: dest exists. Try overwrite flag."
        
        search_strings = ['title: REPLACE_ME', 'config.course_id = REPLACE_ME']
        replace_strings = [f"title: Roster for {course['sis_course_id']}",f"config.course_id = {course['id']}"]

        modified_lines = []
        # Open the input file in read mode
        with open(src_file_name, 'r') as input_file:
            for line in input_file:
                # Check if any of the search strings are present in the line
                if any(search_string in line for search_string in search_strings):
                    # Replace the line with the corresponding replacement string
                    for search_string, replace_string in zip(search_strings, replace_strings):
                        line = line.replace(search_string,replace_string)
                # Append the modified or unmodified line to the list
                modified_lines.append(line)

        # Open the destination file in write mode and write the modified lines
        with open(dest_file_name, 'w') as destination_file:
            destination_file.writelines(modified_lines)        
        msg = f"QMD written to: {os.path.basename( dest_file_name)}"
        return msg

    def get_enrollments( self ):
        return self.get_python_object_from( self.get_default_course_endpoint().get_enrollments )
    
    def get_rubrics( self ):
        return self.get_python_object_from( self.get_default_course_endpoint().get_rubrics )

    def get_groups( self ):
        categories = self.get_python_object_from( self.get_default_course_endpoint().get_group_categories )
        groups = self.get_python_object_from( self.get_default_course_endpoint().get_groups )
        for cat_id in categories.keys():
            categories[cat_id]["groups"] = {}
            for group_id in groups.keys():
                if groups[group_id]["group_category_id"]==cat_id:
                    categories[cat_id]["groups"][group_id] = groups[group_id]
        for cat_id in categories.keys():
            for group_id in categories[cat_id]["groups"].keys():
                categories[cat_id]["groups"][group_id]["members"] = self.get_python_object_from( self.get_canvas().get_group( group_id ).get_users )
        return categories
    
    def get_callable_course_objects( self ):
        """ return list of canvas callable objects.  Used primarly by explore """
        dir_methods = dir(self.get_default_course_endpoint())
        var_methods = vars(self.get_default_course_endpoint())
        list = [method for method in dir_methods if (not method in var_methods) and (method[:2] != "__") ]
        return list

    def get_callable_canvas_objects( self ):
        """ return list of canvas callable objects.  Used primarly by explore """
        dir_methods = dir(self.get_canvas())
        var_methods = vars(self.get_canvas())
        list = [method for method in dir_methods if (not method in var_methods) and (method[:2] != "__") ]
        return list

    def get_course_object_by_name( self, method_name ):
        """ Call method by name """
        list = None
        if hasattr(self.get_default_course_endpoint(), method_name ):
            method = getattr(self.get_default_course_endpoint(), method_name)
            if callable(method):
                try:
                    list = self.get_python_object_from( method )
                except Exception as e:
                    list = f"Exception: {e}"
            else:
                logger.warning(f"{method_name} is not callable.")
        else:
            logger.warning(f"{method_name} does not exist in the class.")
        return list

    def get_canvas_object_by_name( self, method_name ):
        """ Call method by name """
        list = None
        if hasattr(self.get_canvas(), method_name ):
            method = getattr(self.get_canvas(), method_name)
            if callable(method):
                try:
                    list = self.get_python_object_from( method )
                except Exception as e:
                    list = f"Exception: {e}"
            else:
                logger.warning(f"{method_name} is not callable.")
        else:
            logger.warning(f"{method_name} does not exist in the class.")
        return list
    
    def get_status( self ):
        """ return string contain status of config """
        msg = f"{program_name} status".upper()
        for key in ["course_id","config_file","log_level","canvas_endpoint","headshot_endpoint",
                    "program_name","plugin_folder","gsecrets","outline_gsheet_key","lecture_slides_endpoint"]:
            msg = msg + f"\n{key}\t{getattr(self,key)}"
#           msg = msg + f"\n{vars(self)}"
        return msg
    
  
    @property
    def outline_gsheet_key( self ):
        missing_key_string = "<add outline gsheet key>"
        value = None
        if "course" in self.config.keys():
            if str(config.course_id) in self.config["course"].keys():
                if "outline_gsheet_key" in self.config["course"][str(config.course_id)].keys():
                    value = self.config["course"][str(config.course_id)]["outline_gsheet_key"]
                    if value==missing_key_string:
                        click.echo( f"Edit outline_gsheet_key with appropriate value")
                        sys.exit(1)
        if value==None:
            click.echo( f"Missing outline_gsheet_key in {self.config_file_name}")
            if not "course" in self.config.keys():
                self.config["course"] = {}
            if not str(config.course_id) in self.config["course"].keys():
                self.config["course"][str(config.course_id)] = {}
            if not "outline_gsheet_key" in self.config["course"][str(config.course_id)].keys():
                self.config["course"][str(config.course_id)]["outline_gsheet_key"] = missing_key_string
            self.save()
            sys.exit(1)
        return value

    @property
    def lecture_slides_endpoint( self ):
        missing_key_string = "<add root URL to lecture slides>"
        value = None
        if "course" in self.config.keys():
            if str(config.course_id) in self.config["course"].keys():
                if "lecture_slides_endpoint" in self.config["course"][str(config.course_id)].keys():
                    value = self.config["course"][str(config.course_id)]["lecture_slides_endpoint"]
                    if value==missing_key_string:
                        value=None
        if value==None:
            click.echo( f"Missing lecture_slide_endpoint. Edit {self.config_file_name}")
            if not "course" in self.config.keys():
                self.config["course"] = {}
            if not str(config.course_id) in self.config["course"].keys():
                self.config["course"][str(config.course_id)] = {}
            if not "lecture_slides_endpoint" in self.config["course"][str(config.course_id)].keys():
                self.config["course"][str(config.course_id)]["lecture_slides_endpoint"] = missing_key_string
            self.save()
            sys.exit(1)
        return value
    
    @property
    def default_split_code( self ):
        return self.config["application"]["default_split_code"]

    @property
    def log_level( self ):
        value = None
        if "application" in self.config.keys():
            if "log_level" in self.config["application"].keys():
                value = self.config["application"]["log_level"]
        return value
    
    @log_level.setter
    def log_level( self, log_level ):
        self.config["log_level"] = log_level            
        logger.remove()
        logger.add(sys.stderr, level=log_level)

    @property
    def headshot_endpoint( self ):
        """ returns headshot_endpoint from configuration """
        value = None
        if "images" in self.config.keys():
            if "headshot_endpoint" in self.config["images"].keys():
                value = self.config["images"]["headshot_endpoint"]
        return value

    @property
    def namespace( self ):
        return self.config["keyring"]["namespace"] + "/" + self.config["keyring"]["entry"]

    @property
    def token( self ):
        namespace = self.config["keyring"]["namespace"] + "/" + self.config["keyring"]["entry"]
        logger.info(f"Retriving token using: {namespace}" )
        return keyring.get_password( namespace, self.config["keyring"]["entry"] )

    @token.setter
    def token( self, token ):
        namespace = self.config["keyring"]["namespace"] + "/" + self.config["keyring"]["entry"]
        keyring.set_password( namespace, self.config["keyring"]["entry"], token )
        logger.info(f"Token stored in local secure storage: {namespace}")
        return keyring.get_password( namespace, self.config["keyring"]["entry"] )
    
    @property
    def program_name( self ):
        return program_name
    
    @property
    def config_file_name( self ):
        return self.config_file
    
    @property
    def canvas_endpoint(self):
        return self.config["canvas"]["endpoint"]
    
    @property
    def plugin_folder( self ):
        value = plugin_folder; #from global in this file
        if "application" in self.config.keys():
            if "plugin_folder" in self.config["application"].keys():
                value = self.config["application"]["plugin_folder"]
        return value
    
    @property
    def gsecrets( self ):
        value = os.path.expanduser("~/.gsecrets/gsheets-credentials.json")
        if "application" in self.config.keys():
            if "gsecrets" in self.config["application"].keys():
                value = os.path.expanduser(self.config["application"]["gsecrets"])
        return value
    
    @property
    def lecture_slides_template( self ):

##           template_key = config.config["lecture"]["default_qmd_template"]
##        template_qmd_file = os.path.join(config.plugin_folder, config.config["lecture"][template_key] )

        missing_key_string = "<add template file for lecture slides>"
        value = None
        if "course" in self.config.keys():
            if str(config.course_id) in self.config["course"].keys():
                if "lecture_slides_template" in self.config["course"][str(config.course_id)].keys():
                    value = self.config["course"][str(config.course_id)]["lecture_slides_template"]
                    if value==missing_key_string:
                        value=None
                    elif not os.path.exists( value ):
                        value=None
        if value==None:
            click.echo( f"Missing lecture_slide_template. Edit {self.config_file_name}")
            if not "course" in self.config.keys():
                self.config["course"] = {}
            if not str(config.course_id) in self.config["course"].keys():
                self.config["course"][str(config.course_id)] = {}
            if not "lecture_slides_template" in self.config["course"][str(config.course_id)].keys():
                self.config["course"][str(config.course_id)]["lecture_slides_template"] = missing_key_string
            self.save()
            sys.exit(1)
        return value

    
class ExternalCommandClass(click.MultiCommand):
    """ ExternalCommandClass docstring """
    def __init__( self, plugin_folder, **kwargs ):
        super().__init__( **kwargs )
        self.plugin_folder = plugin_folder

    def list_commands(self, ctx):
        rv = []
        for filename in os.listdir(self.plugin_folder):
            if filename.startswith("cmd_") and filename.endswith('.py'):
                rv.append(filename[4:-3])
        rv.sort()
        return rv

    def get_command(self, ctx, name):
        ns = {}
        fn = os.path.join(self.plugin_folder, "cmd_"+ name + '.py')
        logger.debug(f"fn:{fn}")
        if os.path.exists(fn):
            with open(fn) as f:
                code = compile(f.read(), fn, 'exec')
                eval(code, ns, ns)
            ns = ns['cli']
        else:
            ns = None
        return ns

config = Configuration()

